'use client';

import { useEffect, useState } from 'react';
import ProductCard from './ProductCard';

export default function ShopProductGrid() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/products')
      .then(res => res.json())
      .then(data => {
        setProducts(data);
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return (
      <div className="w-full py-20 flex justify-center items-center text-on-surface-variant font-body-md">
        Loading products...
      </div>
    );
  }

  if (products.length === 0) {
    return (
      <div className="w-full py-20 flex justify-center items-center text-on-surface-variant font-body-md">
        No products found.
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-gutter">
      {products.map((product: any) => (
        <ProductCard key={product.id} product={product} />
      ))}
    </div>
  );
}
