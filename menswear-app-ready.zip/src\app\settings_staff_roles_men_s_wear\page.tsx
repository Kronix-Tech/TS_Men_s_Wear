export default function SettingsStaffRolesMenSWear() {
  return (
    <main className="pt-24 pb-xxl px-margin-mobile md:px-margin-desktop md:ml-[240px] max-w-container-max mx-auto">

<div className="mb-xxl">
<h2 className="font-headline-lg text-headline-lg text-primary mb-lg uppercase tracking-widest">Settings</h2>
<div className="flex flex-wrap gap-sm">
<a className="px-lg py-2 rounded-full border border-primary text-primary font-label-lg text-label-lg hover:bg-surface-container-highest transition-colors inline-block" href="#">Store</a>
<a className="px-lg py-2 rounded-full border border-primary text-primary font-label-lg text-label-lg hover:bg-surface-container-highest transition-colors inline-block" href="#">Shipping &amp; Payment</a>
<div className="px-lg py-2 rounded-full bg-primary text-on-primary font-label-lg text-label-lg inline-block cursor-default">Staff &amp; Roles</div>
</div>
</div>

<div className="grid grid-cols-1 lg:grid-cols-12 gap-gutter">

<div className="lg:col-span-8 flex flex-col gap-xxl">

<section className="bg-surface-container-lowest rounded-[24px] overflow-hidden">
<div className="p-lg flex justify-between items-center border-b border-outline-variant/10">
<h3 className="font-headline-md text-headline-md text-primary">Staff Management</h3>
<button className="bg-primary text-on-primary px-lg py-3 rounded-full font-label-lg text-label-lg flex items-center gap-2 hover:bg-primary/90 transition-colors active:scale-95">
                            ADD STAFF <span className="material-symbols-outlined text-[18px]">arrow_forward</span>
</button>
</div>
<div className="overflow-x-auto">
<table className="w-full text-left border-collapse min-w-[700px]">
<thead>
<tr className="border-b border-outline-variant/10">
<th className="p-md pl-lg font-label-lg text-label-lg text-on-surface-variant uppercase tracking-widest bg-[#F5F4F8]/50">Staff</th>
<th className="p-md font-label-lg text-label-lg text-on-surface-variant uppercase tracking-widest bg-[#F5F4F8]/50">Email</th>
<th className="p-md font-label-lg text-label-lg text-on-surface-variant uppercase tracking-widest bg-[#F5F4F8]/50">Role</th>
<th className="p-md font-label-lg text-label-lg text-on-surface-variant uppercase tracking-widest bg-[#F5F4F8]/50">Status</th>
<th className="p-md font-label-lg text-label-lg text-on-surface-variant uppercase tracking-widest bg-[#F5F4F8]/50">Last Active</th>
<th className="p-md pr-lg font-label-lg text-label-lg text-on-surface-variant uppercase tracking-widest text-right bg-[#F5F4F8]/50">ACTIONS</th>
</tr>
</thead>
<tbody className="divide-y divide-outline-variant/10">

<tr className="hover:bg-surface-container-lowest/50 transition-colors group">
<td className="p-md pl-lg">
<div className="flex items-center gap-sm">
<div className="w-10 h-10 rounded-full overflow-hidden border border-outline-variant/20">
<img alt="James Wilson" className="w-full h-full object-cover" data-alt="A close-up portrait of a sharply dressed young man with dark wavy hair in a tailored grey vest, bright white background, crisp modern fashion photography aesthetic, high key lighting." src="https://lh3.googleusercontent.com/aida-public/AB6AXuB_efUMfOGZevG5QhPCLdVzfgSsSHf6vKwJjS5yucfqcWujcCrzlc3R3Vy-a5POtwqcAcNl0LSpSo1S-JTaTE7-yAVgP8jncC6nZV2EKYi3S7tVHHtWbJdosqFeLMdWlmgRgy4D6vmGJMFBqQtvCm6xoT1SKMG6wv_Bjflk0j75MCz96qLfVTJbKK_1ze4v9rXBjty-Jv5mE9d5DVXi2jDr_FB1TQO480m2Eq5GlRBzownQaBqSsE0l" />
</div>
<span className="font-body-md text-body-md text-primary font-medium">James Wilson</span>
</div>
</td>
<td className="p-md text-body-sm text-on-surface-variant">james@menswear.com</td>
<td className="p-md">
<span className="inline-block px-3 py-1 rounded-full bg-primary text-on-primary font-label-sm text-label-sm uppercase">Super Admin</span>
</td>
<td className="p-md">

<div className="relative inline-block w-10 mr-2 align-middle select-none transition duration-200 ease-in cursor-pointer">
<input defaultChecked={true} className="toggle-checkbox absolute block w-5 h-5 rounded-full bg-white border-4 appearance-none cursor-pointer border-[#8FB0A4] transition-transform duration-200 ease-in-out translate-x-5 checked:bg-[#8FB0A4]" id="toggle1" name="toggle1" style={{"top": "2px","left": "2px"}} type="checkbox" />
<label className="toggle-label block overflow-hidden h-6 rounded-full bg-[#8FB0A4] cursor-pointer" htmlFor="toggle1"></label>
</div>
</td>
<td className="p-md text-body-sm text-on-surface-variant">Aug 14, 2026</td>
<td className="p-md pr-lg text-right">
<button className="text-on-surface-variant hover:text-primary transition-colors p-2 rounded-full hover:bg-surface-container-high inline-flex items-center justify-center">
<span className="material-symbols-outlined text-[20px]">edit</span>
</button>
</td>
</tr>

<tr className="hover:bg-surface-container-lowest/50 transition-colors group">
<td className="p-md pl-lg">
<div className="flex items-center gap-sm">
<div className="w-10 h-10 rounded-full bg-surface-container-highest flex items-center justify-center text-primary font-label-lg">
                                                RC
                                            </div>
<span className="font-body-md text-body-md text-primary font-medium">Robert Chen</span>
</div>
</td>
<td className="p-md text-body-sm text-on-surface-variant">robert@menswear.com</td>
<td className="p-md">
<span className="inline-block px-3 py-1 rounded-full bg-[#8FB0A4] text-white font-label-sm text-label-sm uppercase">Manager</span>
</td>
<td className="p-md">
<div className="relative inline-block w-10 mr-2 align-middle select-none transition duration-200 ease-in cursor-pointer">
<input defaultChecked={true} className="toggle-checkbox absolute block w-5 h-5 rounded-full bg-white border-4 appearance-none cursor-pointer border-[#8FB0A4] transition-transform duration-200 ease-in-out translate-x-5 checked:bg-[#8FB0A4]" id="toggle2" name="toggle2" style={{"top": "2px","left": "2px"}} type="checkbox" />
<label className="toggle-label block overflow-hidden h-6 rounded-full bg-[#8FB0A4] cursor-pointer" htmlFor="toggle2"></label>
</div>
</td>
<td className="p-md text-body-sm text-on-surface-variant">Aug 12, 2026</td>
<td className="p-md pr-lg text-right">
<button className="text-on-surface-variant hover:text-primary transition-colors p-2 rounded-full hover:bg-surface-container-high inline-flex items-center justify-center">
<span className="material-symbols-outlined text-[20px]">edit</span>
</button>
</td>
</tr>

<tr className="hover:bg-surface-container-lowest/50 transition-colors group bg-[#F5F4F8]/20">
<td className="p-md pl-lg">
<div className="flex items-center gap-sm">
<div className="w-10 h-10 rounded-full bg-surface-container-highest flex items-center justify-center text-primary font-label-lg">
                                                DM
                                            </div>
<span className="font-body-md text-body-md text-primary font-medium">David Miller</span>
</div>
</td>
<td className="p-md text-body-sm text-on-surface-variant">david@menswear.com</td>
<td className="p-md">
<span className="inline-block px-3 py-1 rounded-full bg-surface-container-highest text-on-surface-variant font-label-sm text-label-sm uppercase">Support</span>
</td>
<td className="p-md">
<div className="relative inline-block w-10 mr-2 align-middle select-none transition duration-200 ease-in cursor-pointer">
<input className="toggle-checkbox absolute block w-5 h-5 rounded-full bg-white border-4 appearance-none cursor-pointer border-outline-variant transition-transform duration-200 ease-in-out" id="toggle3" name="toggle3" style={{"top": "2px","left": "2px"}} type="checkbox" />
<label className="toggle-label block overflow-hidden h-6 rounded-full bg-surface-container-highest cursor-pointer" htmlFor="toggle3"></label>
</div>
</td>
<td className="p-md text-body-sm text-on-surface-variant">Jul 28, 2026</td>
<td className="p-md pr-lg text-right">
<button className="text-on-surface-variant hover:text-primary transition-colors p-2 rounded-full hover:bg-surface-container-high inline-flex items-center justify-center">
<span className="material-symbols-outlined text-[20px]">edit</span>
</button>
</td>
</tr>

<tr className="hover:bg-surface-container-lowest/50 transition-colors group">
<td className="p-md pl-lg">
<div className="flex items-center gap-sm">
<div className="w-10 h-10 rounded-full bg-surface-container-highest flex items-center justify-center text-primary font-label-lg">
                                                SJ
                                            </div>
<span className="font-body-md text-body-md text-primary font-medium">Sarah Jones</span>
</div>
</td>
<td className="p-md text-body-sm text-on-surface-variant">sarah@menswear.com</td>
<td className="p-md">
<span className="inline-block px-3 py-1 rounded-full bg-surface-container-highest text-on-surface-variant font-label-sm text-label-sm uppercase">Warehouse</span>
</td>
<td className="p-md">
<div className="relative inline-block w-10 mr-2 align-middle select-none transition duration-200 ease-in cursor-pointer">
<input defaultChecked={true} className="toggle-checkbox absolute block w-5 h-5 rounded-full bg-white border-4 appearance-none cursor-pointer border-[#8FB0A4] transition-transform duration-200 ease-in-out translate-x-5 checked:bg-[#8FB0A4]" id="toggle4" name="toggle4" style={{"top": "2px","left": "2px"}} type="checkbox" />
<label className="toggle-label block overflow-hidden h-6 rounded-full bg-[#8FB0A4] cursor-pointer" htmlFor="toggle4"></label>
</div>
</td>
<td className="p-md text-body-sm text-on-surface-variant">Aug 10, 2026</td>
<td className="p-md pr-lg text-right">
<button className="text-on-surface-variant hover:text-primary transition-colors p-2 rounded-full hover:bg-surface-container-high inline-flex items-center justify-center">
<span className="material-symbols-outlined text-[20px]">edit</span>
</button>
</td>
</tr>
</tbody>
</table>
</div>
</section>

<section className="bg-surface-container-lowest rounded-[24px] p-lg">
<div className="border-b border-outline-variant/10 pb-md mb-lg">
<h3 className="font-headline-md text-headline-md text-primary">Add / Edit Staff Details</h3>
</div>
<form className="space-y-xl">

<div className="grid grid-cols-1 md:grid-cols-3 gap-gutter">
<div className="space-y-2">
<label className="block font-label-lg text-label-lg text-on-surface-variant uppercase tracking-widest">Name</label>
<input className="w-full px-4 py-3 bg-surface-container-lowest border border-outline-variant/30 rounded-lg text-body-md focus:outline-none focus:border-[#8FB0A4] focus:ring-1 focus:ring-[#8FB0A4] transition-colors placeholder:text-outline" placeholder="Full Name" type="text" />
</div>
<div className="space-y-2">
<label className="block font-label-lg text-label-lg text-on-surface-variant uppercase tracking-widest">Email</label>
<input className="w-full px-4 py-3 bg-surface-container-lowest border border-outline-variant/30 rounded-lg text-body-md focus:outline-none focus:border-[#8FB0A4] focus:ring-1 focus:ring-[#8FB0A4] transition-colors placeholder:text-outline" placeholder="email@menswear.com" type="email" />
</div>
<div className="space-y-2">
<label className="block font-label-lg text-label-lg text-on-surface-variant uppercase tracking-widest">Role</label>
<div className="relative">
<select className="w-full pl-4 pr-10 py-3 bg-surface-container-lowest border border-outline-variant/30 rounded-lg text-body-md appearance-none focus:outline-none focus:border-[#8FB0A4] focus:ring-1 focus:ring-[#8FB0A4] transition-colors text-primary">
<option disabled={true} value="">Select Role</option>
<option value="super">Super Admin</option>
<option value="manager">Manager</option>
<option value="support">Support</option>
<option value="warehouse">Warehouse</option>
</select>
<span className="material-symbols-outlined absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-on-surface-variant">expand_more</span>
</div>
</div>
</div>

<div className="bg-[#F5F4F8] rounded-xl p-lg border border-outline-variant/10">
<h4 className="font-label-lg text-label-lg text-primary uppercase tracking-widest mb-md">Custom Permissions</h4>
<div className="grid grid-cols-2 md:grid-cols-3 gap-md">
<label className="flex items-center gap-3 cursor-pointer group">
<input className="w-5 h-5 rounded border-outline-variant text-primary focus:ring-primary bg-surface-container-lowest cursor-pointer" type="checkbox" />
<span className="font-body-md text-body-md text-on-surface-variant group-hover:text-primary transition-colors">Products</span>
</label>
<label className="flex items-center gap-3 cursor-pointer group">
<input className="w-5 h-5 rounded border-outline-variant text-primary focus:ring-primary bg-surface-container-lowest cursor-pointer" type="checkbox" />
<span className="font-body-md text-body-md text-on-surface-variant group-hover:text-primary transition-colors">Orders</span>
</label>
<label className="flex items-center gap-3 cursor-pointer group">
<input className="w-5 h-5 rounded border-outline-variant text-primary focus:ring-primary bg-surface-container-lowest cursor-pointer" type="checkbox" />
<span className="font-body-md text-body-md text-on-surface-variant group-hover:text-primary transition-colors">Refunds</span>
</label>
<label className="flex items-center gap-3 cursor-pointer group">
<input className="w-5 h-5 rounded border-outline-variant text-primary focus:ring-primary bg-surface-container-lowest cursor-pointer" type="checkbox" />
<span className="font-body-md text-body-md text-on-surface-variant group-hover:text-primary transition-colors">Coupons</span>
</label>
<label className="flex items-center gap-3 cursor-pointer group">
<input className="w-5 h-5 rounded border-outline-variant text-primary focus:ring-primary bg-surface-container-lowest cursor-pointer" type="checkbox" />
<span className="font-body-md text-body-md text-on-surface-variant group-hover:text-primary transition-colors">Banners</span>
</label>
<label className="flex items-center gap-3 cursor-pointer group">
<input className="w-5 h-5 rounded border-outline-variant text-primary focus:ring-primary bg-surface-container-lowest cursor-pointer" type="checkbox" />
<span className="font-body-md text-body-md text-on-surface-variant group-hover:text-primary transition-colors">Settings</span>
</label>
</div>
</div>

<div className="flex items-center gap-md pt-sm">
<button className="bg-primary text-on-primary h-12 px-xl rounded-full font-label-lg text-label-lg hover:bg-primary/90 transition-colors active:scale-95" type="button">
                                SAVE STAFF
                            </button>
<button className="border border-primary text-primary h-12 px-xl rounded-full font-label-lg text-label-lg hover:bg-surface-container-highest transition-colors active:scale-95" type="button">
                                CANCEL
                            </button>
</div>
</form>
</section>
</div>

<div className="lg:col-span-4">
<div className="bg-surface-container-lowest rounded-[24px] p-lg sticky top-[100px]">
<div className="border-b border-outline-variant/10 pb-md mb-lg">
<h3 className="font-headline-md text-headline-md text-primary">Role Summary</h3>
</div>
<div className="space-y-lg">

<div>
<div className="flex justify-between items-end mb-2">
<span className="font-label-lg text-label-lg text-primary uppercase">Super Admin</span>
<span className="font-body-sm text-body-sm text-on-surface-variant">1 User</span>
</div>
<div className="w-full bg-[#F5F4F8] rounded-full h-2 overflow-hidden">
<div className="bg-[#8FB0A4] h-2 rounded-full" style={{"width": "10%"}}></div>
</div>
</div>

<div>
<div className="flex justify-between items-end mb-2">
<span className="font-label-lg text-label-lg text-primary uppercase">Manager</span>
<span className="font-body-sm text-body-sm text-on-surface-variant">2 Users</span>
</div>
<div className="w-full bg-[#F5F4F8] rounded-full h-2 overflow-hidden">
<div className="bg-[#8FB0A4] h-2 rounded-full" style={{"width": "20%"}}></div>
</div>
</div>

<div>
<div className="flex justify-between items-end mb-2">
<span className="font-label-lg text-label-lg text-primary uppercase">Support</span>
<span className="font-body-sm text-body-sm text-on-surface-variant">4 Users</span>
</div>
<div className="w-full bg-[#F5F4F8] rounded-full h-2 overflow-hidden">
<div className="bg-[#8FB0A4] h-2 rounded-full" style={{"width": "40%"}}></div>
</div>
</div>

<div>
<div className="flex justify-between items-end mb-2">
<span className="font-label-lg text-label-lg text-primary uppercase">Warehouse</span>
<span className="font-body-sm text-body-sm text-on-surface-variant">3 Users</span>
</div>
<div className="w-full bg-[#F5F4F8] rounded-full h-2 overflow-hidden">
<div className="bg-[#8FB0A4] h-2 rounded-full" style={{"width": "30%"}}></div>
</div>
</div>
</div>

<div className="mt-xl pt-lg border-t border-outline-variant/10 text-center">
<span className="material-symbols-outlined text-outline-variant/30 text-[48px]">admin_panel_settings</span>
<p className="font-body-sm text-body-sm text-on-surface-variant/60 mt-2 max-w-[200px] mx-auto">Maintain strict access control to protect customer data.</p>
</div>
</div>
</div>
</div>
</main>
  );
}