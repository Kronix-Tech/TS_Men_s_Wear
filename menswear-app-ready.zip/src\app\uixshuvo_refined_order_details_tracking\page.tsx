export default function UixshuvoRefinedOrderDetailsTracking() {
  return (
    <main className="flex-grow w-full max-w-container-max mx-auto px-margin-mobile md:px-margin-desktop py-stack-md md:py-stack-lg">

<nav aria-label="Breadcrumb" className="mb-8">
<ol className="flex items-center space-x-2 text-on-surface-variant font-label-sm text-label-sm uppercase tracking-widest">
<li className=""><a className="hover:text-primary transition-colors" href="#">Home</a></li>
<li className=""><span className="mx-1">/</span></li>
<li className=""><a className="hover:text-primary transition-colors" href="#">Account</a></li>
<li className=""><span className="mx-1">/</span></li>
<li className=""><a className="hover:text-primary transition-colors" href="#">My Orders</a></li>
<li className=""><span className="mx-1">/</span></li>
<li aria-current="page" className="text-primary">#MW-2481</li>
</ol>
</nav>

<div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16">
<div>
<h1 className="font-headline-lg-mobile md:font-headline-lg text-headline-lg-mobile md:text-headline-lg text-primary mb-4">ORDER #MW-2481</h1>
<div className="flex flex-wrap items-center gap-4">
<span className="inline-flex items-center px-4 py-2 rounded-full bg-surface-variant text-on-surface font-label-sm text-label-sm uppercase tracking-widest">
                        Shipped
                    </span>
<span className="text-on-surface-variant font-body-md text-body-md">Aug 17, 2026</span>
</div>
</div>
<div className="flex gap-4">
<button className="px-6 py-3 rounded-full border border-outline text-primary font-label-sm text-label-sm uppercase tracking-widest hover:bg-surface-variant transition-colors flex items-center gap-2">
                    DOWNLOAD INVOICE
                </button>
<button className="px-6 py-3 rounded-full bg-primary text-on-primary font-label-sm text-label-sm uppercase tracking-widest hover:opacity-90 transition-opacity flex items-center gap-2">
                    NEED HELP? CONTACT US
                    <span className="material-symbols-outlined text-sm">arrow_forward</span>
</button>
</div>
</div>

<section className="mb-16 bg-surface rounded-xl p-8 md:p-12 ambient-shadow">
<h2 className="font-headline-md text-headline-md mb-10 text-center">Tracking Status</h2>
<div className="relative max-w-4xl mx-auto">

<div className="absolute top-6 left-0 w-full h-[2px] bg-surface-variant -z-10"></div>

<div className="absolute top-6 left-0 w-1/2 h-[2px] bg-secondary -z-10"></div>
<div className="flex justify-between items-start">

<div className="flex flex-col items-center text-center w-24">
<div className="w-12 h-12 rounded-full bg-secondary text-on-primary flex items-center justify-center mb-4">
<span className="material-symbols-outlined">shopping_cart_checkout</span>
</div>
<span className="font-label-sm text-label-sm uppercase tracking-widest mb-1">Ordered</span>
<span className="text-xs text-on-surface-variant">Aug 15</span>
</div>

<div className="flex flex-col items-center text-center w-24">
<div className="w-12 h-12 rounded-full bg-secondary text-on-primary flex items-center justify-center mb-4">
<span className="material-symbols-outlined">inventory_2</span>
</div>
<span className="font-label-sm text-label-sm uppercase tracking-widest mb-1">Packed</span>
<span className="text-xs text-on-surface-variant">Aug 16</span>
</div>

<div className="flex flex-col items-center text-center w-24">
<div className="w-12 h-12 rounded-full bg-secondary text-on-primary flex items-center justify-center mb-4 ring-4 ring-secondary/20">
<span className="material-symbols-outlined">local_shipping</span>
</div>
<span className="font-label-sm text-label-sm uppercase tracking-widest mb-1 text-primary">Shipped</span>
<span className="text-xs text-on-surface-variant">Aug 17</span>
</div>

<div className="flex flex-col items-center text-center w-24">
<div className="w-12 h-12 rounded-full bg-surface-variant text-on-surface-variant flex items-center justify-center mb-4">
<span className="material-symbols-outlined">directions_car</span>
</div>
<span className="font-label-sm text-label-sm uppercase tracking-widest mb-1 text-on-surface-variant">Out for Delivery</span>
<span className="text-xs text-on-surface-variant opacity-50">Pending</span>
</div>

<div className="flex flex-col items-center text-center w-24">
<div className="w-12 h-12 rounded-full bg-surface-variant text-on-surface-variant flex items-center justify-center mb-4">
<span className="material-symbols-outlined">home</span>
</div>
<span className="font-label-sm text-label-sm uppercase tracking-widest mb-1 text-on-surface-variant">Delivered</span>
<span className="text-xs text-on-surface-variant opacity-50">Pending</span>
</div>
</div>
</div>
</section>

<div className="grid grid-cols-1 lg:grid-cols-3 gap-8">

<section className="lg:col-span-2 bg-surface rounded-xl p-8 ambient-shadow flex flex-col">
<h2 className="font-headline-md text-headline-md mb-8 pb-4 border-b border-surface-variant">Order Items</h2>
<div className="flex flex-col gap-8 flex-grow">

<div className="flex items-center gap-6">
<div className="w-24 h-32 rounded-lg overflow-hidden bg-surface-variant flex-shrink-0">
<img className="w-full h-full object-cover" data-alt="A minimalist, high-end editorial product shot of a light sage green linen men's shirt neatly folded against a stark white studio background. The lighting is soft and diffused, emphasizing the premium texture of the natural fibers. The mood is calm and sophisticated, aligning perfectly with a quiet luxury fashion aesthetic. Minimal shadows and crisp edges." src="https://lh3.googleusercontent.com/aida-public/AB6AXuArKNBcQTMYrd1ECAmmVHu_kTiOzYUsXW9rTJEwm8Qv03TmJXjOn0V6xEBbuZb-z3z8GnpSX6EQhPuJ1MTRMpfzI-TtRhXnMXfDRfKkbDJTAcdzwF0BrwQMp3KZUng0ghMCVVsuetahUbgDgK87QjT5wD0JMQM0T3one0hNimP_3WKU9psZtlQZj1XRjCSWFWG4OAMcXSH0BT4BX9czJvwWlr5Ni1NmlOKHhhDbnnOcFl1gRKfi8_PxLg" />
</div>
<div className="flex-grow">
<h3 className="font-headline-md text-lg mb-1">Sage Linen Shirt</h3>
<p className="text-on-surface-variant mb-2">Sage / L</p>
<p className="font-body-lg mb-4">$85.00</p>
<a className="font-label-sm text-label-sm uppercase tracking-widest text-on-surface-variant underline underline-offset-4 hover:text-primary transition-colors" href="#">Return / Exchange</a>
</div>
</div>

<div className="flex items-center gap-6">
<div className="w-24 h-32 rounded-lg overflow-hidden bg-surface-variant flex-shrink-0">
<img alt="Selvedge Jeans" className="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida/AP1WRLusg0K3F_ypapeR-272hJjPMps24n77A4kcPO74u-PepPjQP4xrArAaPmx4HXF98zzF5aAmM4D8qoeN8BcnDKlMvYdJesslyusGwmRzHS2_FOKrlg15n79XDPqmRW-NwZ1653jIjsfJlU6zJANjLCafr_Qn9maNoxpNsi69yRpxdOB2cfe0am1n-TCXVZvvZl9fsxf9zZr0_wIiK0k4DEXruFKixWhYViVDldPeG2GGbsOc2Ag1mm-peK1b" />
</div>
<div className="flex-grow">
<h3 className="font-headline-md text-lg mb-1">Selvedge Jeans</h3>
<p className="text-on-surface-variant mb-2">Indigo / 32</p>
<p className="font-body-lg mb-4">$145.00</p>
<a className="font-label-sm text-label-sm uppercase tracking-widest text-on-surface-variant underline underline-offset-4 hover:text-primary transition-colors" href="#">Return / Exchange</a>
</div>
</div>

<div className="flex items-center gap-6">
<div className="w-24 h-32 rounded-lg overflow-hidden bg-surface-variant flex-shrink-0">
<img className="w-full h-full object-cover" data-alt="A premium, minimalist editorial product shot of a heavyweight grey men's t-shirt, perfectly folded flat on a pristine white background. High-key lighting highlights the substantial thickness and smooth drape of the cotton. The aesthetic is clean, modern, and understated, perfectly matching a luxury menswear brand's visual identity. Very soft ambient shadows." src="https://lh3.googleusercontent.com/aida-public/AB6AXuAPeJ8yXJhtPXutn6swpEtIpHDsdg1TqTqhAGHvZPGB4M8St7Ohbd7P-NhmdSleFH_fQDh3PtcULUtlySAUdOg6jfMRzh1kz_CFSaJiIXYKyVYT2xVdk2pUvluNY4teVTlafp3J8BozwmMxW3nFosbX45GefF6LP4_d06-58XK97GfBM1d04Ol1ykLfWaYjJXLcL443epNZREEbgokH1Ugv9fhO34K2_QL6cyR8o4UBMKDn2Y72gQ1fzA" />
</div>
<div className="flex-grow">
<h3 className="font-headline-md text-lg mb-1">Heavyweight Tee</h3>
<p className="text-on-surface-variant mb-2">Grey / L</p>
<p className="font-body-lg mb-4">$45.00</p>
<a className="font-label-sm text-label-sm uppercase tracking-widest text-on-surface-variant underline underline-offset-4 hover:text-primary transition-colors" href="#">Return / Exchange</a>
</div>
</div>
</div>
</section>

<div className="flex flex-col gap-8">

<section className="bg-surface rounded-xl p-8 ambient-shadow">
<h2 className="font-headline-md text-headline-md mb-6 pb-4 border-b border-surface-variant">Delivery Details</h2>
<div className="mb-6">
<h3 className="font-label-sm text-label-sm uppercase tracking-widest text-on-surface-variant mb-2">Shipping Address</h3>
<p className="font-body-md text-on-surface">
                            John Doe<br />
                            123 Maple St, Apt 4B<br />
                            New York, NY 10001
                        </p>
</div>
<div>
<h3 className="font-label-sm text-label-sm uppercase tracking-widest text-on-surface-variant mb-2">Courier Information</h3>
<p className="font-body-md text-on-surface mb-4">BlueDart — AWB 123456789</p>
<button className="w-full py-3 rounded-full border border-outline text-primary font-label-sm text-label-sm uppercase tracking-widest hover:bg-surface-variant transition-colors flex items-center justify-center gap-2">
                            TRACK ON COURIER SITE
                            <span className="material-symbols-outlined text-sm">open_in_new</span>
</button>
</div>
</section>

<section className="bg-surface rounded-xl p-8 ambient-shadow">
<h2 className="font-headline-md text-headline-md mb-6 pb-4 border-b border-surface-variant">Payment Summary</h2>
<div className="flex flex-col gap-3 mb-6">
<div className="flex justify-between items-center text-on-surface-variant">
<span className="">Subtotal</span>
<span className="">$275.00</span>
</div>
<div className="flex justify-between items-center text-secondary">
<span className="">Discount</span>
<span className="">-$40.00</span>
</div>
<div className="flex justify-between items-center text-secondary">
<span className="">Shipping</span>
<span className="">FREE</span>
</div>
</div>
<div className="border-t border-surface-variant pt-4 mb-6">
<div className="flex justify-between items-center font-headline-md text-xl">
<span className="">Total</span>
<span className="">$235.00</span>
</div>
</div>
<div>
<h3 className="font-label-sm text-label-sm uppercase tracking-widest text-on-surface-variant mb-2">Payment Method</h3>
<div className="flex items-center gap-3">
<span className="material-symbols-outlined text-on-surface-variant">credit_card</span>
<span className="font-body-md">Credit/Debit Card</span>
</div>
</div>
</section>
</div>
</div>
</main>
  );
}