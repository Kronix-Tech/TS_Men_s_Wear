export default function AdminLoginMenSWear() {
  return (
    <main className="w-full max-w-[440px] px-margin-mobile md:px-0 relative z-10">

<div className="bg-surface-container-lowest rounded-xxl p-xl flex flex-col items-center text-center shadow-[0px_4px_20px_rgba(20,20,20,0.02)]">

<div className="mb-lg w-full">
<p className="font-headline-md text-headline-md text-primary tracking-widest uppercase mb-sm">MEN'S WEAR</p>
<h1 className="font-headline-lg text-headline-lg text-primary mb-sm">ADMIN LOGIN</h1>
<p className="font-body-md text-body-md text-on-surface-variant">Manage your store from one place.</p>
</div>

<form className="w-full flex flex-col gap-md">

<div className="flex flex-col text-left">
<label className="font-label-lg text-label-lg text-on-surface mb-sm uppercase tracking-widest" htmlFor="email">Email</label>
<div className="relative custom-focus rounded-lg transition-colors duration-200">
<input className="w-full bg-surface-container-lowest border border-outline-variant/30 text-on-surface placeholder:text-outline rounded-lg px-md py-3 outline-none focus:ring-0 focus:border-brand-accent font-body-md text-body-md transition-all duration-200" id="email" name="email" placeholder="Email address" required={true} type="email"/>
</div>
</div>

<div className="flex flex-col text-left mb-sm">
<label className="font-label-lg text-label-lg text-on-surface mb-sm uppercase tracking-widest" htmlFor="password">Password</label>
<div className="relative custom-focus rounded-lg transition-colors duration-200 flex items-center bg-surface-container-lowest border border-outline-variant/30 focus-within:border-brand-accent">
<input className="w-full bg-transparent border-none text-on-surface placeholder:text-outline rounded-lg px-md py-3 outline-none focus:ring-0 font-body-md text-body-md" id="password" name="password" placeholder="Password" required={true} type="password"/>
<button aria-label="Toggle password visibility" className="px-md text-outline hover:text-on-surface transition-colors focus:outline-none" type="button">
<span className="material-symbols-outlined" data-icon="visibility">visibility</span>
</button>
</div>
</div>

<div className="flex items-center justify-between w-full mb-lg">
<label className="flex items-center cursor-pointer group">
<input className="w-4 h-4 rounded-sm border-outline-variant/50 text-primary focus:ring-primary focus:ring-offset-surface-container-lowest transition-colors bg-surface-container-lowest cursor-pointer" type="checkbox"/>
<span className="ml-sm font-body-sm text-body-sm text-on-surface-variant group-hover:text-on-surface transition-colors">Remember me</span>
</label>
<a className="font-body-sm text-body-sm text-on-surface-variant hover:text-primary underline decoration-transparent hover:decoration-primary transition-all duration-200" href="#">Forgot password?</a>
</div>

<button className="w-full h-12 bg-primary text-on-primary rounded-full font-label-lg text-label-lg uppercase tracking-widest hover:bg-on-surface transition-colors duration-200 flex items-center justify-center gap-sm active:scale-[0.98]" type="submit">
                    SIGN IN
                    <span className="material-symbols-outlined text-[18px]" data-icon="arrow_forward">arrow_forward</span>
</button>
</form>

<div className="w-full h-px bg-primary/5 my-xl"></div>

<a className="w-full h-12 border border-primary text-primary rounded-full font-label-lg text-label-lg uppercase tracking-widest hover:bg-surface-variant/20 transition-colors duration-200 flex items-center justify-center gap-sm mb-lg active:scale-[0.98]" href="#">
<span className="material-symbols-outlined text-[18px]" data-icon="arrow_back">arrow_back</span>
                Back to store
            </a>

<p className="font-body-sm text-body-sm text-on-surface-variant/60">For staff accounts only</p>
</div>
</main>
  );
}