export default function CategoriesMenSWear() {
  return (
    <main className="ml-64 pt-24 px-margin-desktop pb-xxl min-h-screen max-w-container-max mx-auto">

<div className="flex justify-between items-end mb-xl border-b border-outline-variant/10 pb-lg">
<div>
<h2 className="font-headline-lg text-headline-lg text-primary">Categories</h2>
<p className="font-body-sm text-body-sm text-on-surface-variant mt-2">Manage product categories, status, and organization.</p>
</div>
<button className="bg-primary text-on-primary font-label-lg text-label-lg px-6 py-3 rounded-full flex items-center gap-2 hover:bg-opacity-90 transition-opacity">
                ADD CATEGORY
                <span className="material-symbols-outlined text-sm">arrow_forward</span>
</button>
</div>

<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-gutter mb-xxl">

<div className="bg-surface-container-lowest rounded-xl p-lg flex flex-col hover:shadow-[0px_4px_20px_rgba(20,20,20,0.04)] transition-shadow duration-300 group">
<div className="relative w-full h-48 rounded-lg mb-lg overflow-hidden border-[0.5px] border-tertiary/5 bg-surface-container-low">
<img className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" data-alt="A clean, flat-lay photography shot of a meticulously folded crisp white men's dress shirt on a stark white background. Soft, diffused lighting highlights the fine cotton texture and collar details. Modern e-commerce minimalist aesthetic, light mode palette." src="https://lh3.googleusercontent.com/aida-public/AB6AXuA8WLG31lRJTGnd-4oWUdmNMgT8OnUp7kLA_QskvAHX9qWkSfnL-IYsx5SuuoMvzhJl8qw2_3wm3lTS_H7_TM4cl0C18zuj5c3-jeTx194aHuL7gMatigCse00PeFAHZJOqTMuBYqkciGF3vyf40IQF_pU-Jgc0ht3yCF3yYS2bvPhCJZwc_OSHruIt8PpCdx3Ia2oCz11id55jRcTU_aY4ADXBiPGz-RCWkNXkeXncaZVRrs1DlEVk" />
<div className="absolute top-3 left-3 bg-surface-container-lowest/90 backdrop-blur-sm px-3 py-1 rounded-full border border-outline-variant/20">
<span className="font-label-sm text-label-sm text-primary">120 Products</span>
</div>
</div>
<div className="flex justify-between items-center mb-md">
<h3 className="font-headline-md text-headline-md text-primary">Shirts</h3>

<label className="relative inline-flex items-center cursor-pointer">
<input defaultChecked={true} className="sr-only peer" type="checkbox" value="" />
<div className="w-11 h-6 bg-surface-variant peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-secondary"></div>
</label>
</div>
<div className="flex justify-end gap-sm mt-auto pt-4 border-t border-outline-variant/10">
<button className="p-2 text-on-surface-variant hover:text-secondary hover:bg-secondary-container/20 rounded-full transition-colors">
<span className="material-symbols-outlined text-xl">edit</span>
</button>
<button className="p-2 text-on-surface-variant hover:text-error hover:bg-error-container/30 rounded-full transition-colors">
<span className="material-symbols-outlined text-xl">delete</span>
</button>
</div>
</div>

<div className="bg-surface-container-lowest rounded-xl p-lg flex flex-col hover:shadow-[0px_4px_20px_rgba(20,20,20,0.04)] transition-shadow duration-300 group">
<div className="relative w-full h-48 rounded-lg mb-lg overflow-hidden border-[0.5px] border-tertiary/5 bg-surface-container-low">
<img className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" data-alt="A premium quality, heavy cotton men's t-shirt in a muted sage green color, laid flat on a pristine white surface. The lighting is soft and natural, emphasizing the fabric drape and minimalist modern design. High-end retail aesthetic, clean composition." src="https://lh3.googleusercontent.com/aida-public/AB6AXuDzvguNmnIxZzW-WROOCmedm6sz9h6r_gFVB2dParxEj5KJzwOlIa53f-oYdhODtSXRVPqhP1lWpgVxQJi4IZrOAJgArECsmIOUoESa8VTDw59659zENssh3K25-c-Z8gP29oJPFzb_WxM9G5Uyg3WUWrbvdGC6AWUK8jvhlpANEV8kTm_jB-xeDIWIbIap4nSOuODsYpI5ch0Ey4L4OEyEe3KztB0RMHsuJEO7MQrPue2mJfjj-OY-" />
<div className="absolute top-3 left-3 bg-surface-container-lowest/90 backdrop-blur-sm px-3 py-1 rounded-full border border-outline-variant/20">
<span className="font-label-sm text-label-sm text-primary">85 Products</span>
</div>
</div>
<div className="flex justify-between items-center mb-md">
<h3 className="font-headline-md text-headline-md text-primary">T-Shirts</h3>

<label className="relative inline-flex items-center cursor-pointer">
<input defaultChecked={true} className="sr-only peer" type="checkbox" value="" />
<div className="w-11 h-6 bg-surface-variant peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-secondary"></div>
</label>
</div>
<div className="flex justify-end gap-sm mt-auto pt-4 border-t border-outline-variant/10">
<button className="p-2 text-on-surface-variant hover:text-secondary hover:bg-secondary-container/20 rounded-full transition-colors">
<span className="material-symbols-outlined text-xl">edit</span>
</button>
<button className="p-2 text-on-surface-variant hover:text-error hover:bg-error-container/30 rounded-full transition-colors">
<span className="material-symbols-outlined text-xl">delete</span>
</button>
</div>
</div>

<div className="bg-surface-container-lowest rounded-xl p-lg flex flex-col hover:shadow-[0px_4px_20px_rgba(20,20,20,0.04)] transition-shadow duration-300 group">
<div className="relative w-full h-48 rounded-lg mb-lg overflow-hidden border-[0.5px] border-tertiary/5 bg-surface-container-low">
<img className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" data-alt="A neatly folded pair of premium dark wash men's denim jeans resting on a minimalist white backdrop. Sharp focus on the texture of the denim fabric and brass rivet details. The lighting is studio-quality, casting subtle shadows for depth. Elegant e-commerce style." src="https://lh3.googleusercontent.com/aida-public/AB6AXuBxt_4jqEq1Xl2TY62C4P1WNE5iUfk7xEU9KvCw8Xskf0_cKghk5rjltAtBW8V5MD_pqilLhuN0Iz1gDK3Xv8xUIVJlHnwimIHZYa3DCP-W4IG_QJheqo2nkSl2XYK609xH0NV9SteMN5cUdChSYE55dMbLOkyp6eolgPyrelIOVBefVNfKijab6OZlZ0zwWYtj8U2imop38KE2o9u-lbnJJbHMbTNEPM02RrsdLn5vrfZfOxfwLThA" />
<div className="absolute top-3 left-3 bg-surface-container-lowest/90 backdrop-blur-sm px-3 py-1 rounded-full border border-outline-variant/20">
<span className="font-label-sm text-label-sm text-primary">64 Products</span>
</div>
</div>
<div className="flex justify-between items-center mb-md">
<h3 className="font-headline-md text-headline-md text-primary">Jeans</h3>

<label className="relative inline-flex items-center cursor-pointer">
<input defaultChecked={true} className="sr-only peer" type="checkbox" value="" />
<div className="w-11 h-6 bg-surface-variant peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-secondary"></div>
</label>
</div>
<div className="flex justify-end gap-sm mt-auto pt-4 border-t border-outline-variant/10">
<button className="p-2 text-on-surface-variant hover:text-secondary hover:bg-secondary-container/20 rounded-full transition-colors">
<span className="material-symbols-outlined text-xl">edit</span>
</button>
<button className="p-2 text-on-surface-variant hover:text-error hover:bg-error-container/30 rounded-full transition-colors">
<span className="material-symbols-outlined text-xl">delete</span>
</button>
</div>
</div>

<div className="bg-surface-container-lowest rounded-xl p-lg flex flex-col hover:shadow-[0px_4px_20px_rgba(20,20,20,0.04)] transition-shadow duration-300 group">
<div className="relative w-full h-48 rounded-lg mb-lg overflow-hidden border-[0.5px] border-tertiary/5 bg-surface-container-low">
<img className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" data-alt="A pair of impeccably tailored men's dress trousers in charcoal grey, folded elegantly on a bright white studio surface. The image emphasizes the refined wool texture and clean creases. Minimalist, sophisticated aesthetic suitable for a high-end luxury menswear digital storefront." src="https://lh3.googleusercontent.com/aida-public/AB6AXuDcXX2UR1sj-NVPs7uWH53W9looaM5Pk5b5IuGH88-kBS-kI4lhuSILQ4V69NOSSUMqO993Y6jXsIRpVmqrL7OHmH_YUG37jStqhs14W5J65DxHIu0_2OfiTqNXPtgZCGuIeORHgjvsK9Y3gPaGrwscsQg7b5WfsW3VSvU9NdFLzgtSRiDIeLbBzwWrvXFIRC8-94dDRsnxB5Gx2R-xN8xcu3qPlzl-QEdJ5wDqb5-Vfoi6u0Ew5EUc" />
<div className="absolute top-3 left-3 bg-surface-container-lowest/90 backdrop-blur-sm px-3 py-1 rounded-full border border-outline-variant/20">
<span className="font-label-sm text-label-sm text-primary">42 Products</span>
</div>
</div>
<div className="flex justify-between items-center mb-md">
<h3 className="font-headline-md text-headline-md text-primary">Trousers</h3>

<label className="relative inline-flex items-center cursor-pointer">
<input defaultChecked={true} className="sr-only peer" type="checkbox" value="" />
<div className="w-11 h-6 bg-surface-variant peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-secondary"></div>
</label>
</div>
<div className="flex justify-end gap-sm mt-auto pt-4 border-t border-outline-variant/10">
<button className="p-2 text-on-surface-variant hover:text-secondary hover:bg-secondary-container/20 rounded-full transition-colors">
<span className="material-symbols-outlined text-xl">edit</span>
</button>
<button className="p-2 text-on-surface-variant hover:text-error hover:bg-error-container/30 rounded-full transition-colors">
<span className="material-symbols-outlined text-xl">delete</span>
</button>
</div>
</div>

<div className="bg-surface-container-lowest rounded-xl p-lg flex flex-col hover:shadow-[0px_4px_20px_rgba(20,20,20,0.04)] transition-shadow duration-300 group opacity-75">
<div className="relative w-full h-48 rounded-lg mb-lg overflow-hidden border-[0.5px] border-tertiary/5 bg-surface-container-low">
<img className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 grayscale-[0.2]" data-alt="A luxurious men's ethnic silk kurta in deep navy blue with subtle embroidery, presented flat against a clean, warm-toned neutral background. High-key lighting highlights the sheen of the fabric and intricate details. Elegant and culturally rich, yet modern and minimalist in presentation." src="https://lh3.googleusercontent.com/aida-public/AB6AXuC_s8wcITvVF9zzS0ku8Odmw6UnkzVl6tooh6CnEXQkorTI9FydwI4lizEvvuFFQlMyqHbfMgZhhbMpm3so_1dsSIuBxX8mD34SdUwYn1A7LKpRTQQ0Jz72QzfiRQzG5lsBXxlP36rnFRiOaQvH1BcYhMgXL1pKq0GDvsVOc2nd-EX27pbT53-p9fz9FlH-21aJqMKXi1eQh38e5o22SAsYwnCTpP-D7wFDVni6uzU3_EadQLkbiUOT" />
<div className="absolute top-3 left-3 bg-surface-container-lowest/90 backdrop-blur-sm px-3 py-1 rounded-full border border-outline-variant/20">
<span className="font-label-sm text-label-sm text-primary">18 Products</span>
</div>
</div>
<div className="flex justify-between items-center mb-md">
<h3 className="font-headline-md text-headline-md text-primary">Ethnic Wear</h3>

<label className="relative inline-flex items-center cursor-pointer">
<input className="sr-only peer" type="checkbox" value="" />
<div className="w-11 h-6 bg-surface-variant peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-secondary"></div>
</label>
</div>
<div className="flex justify-end gap-sm mt-auto pt-4 border-t border-outline-variant/10">
<button className="p-2 text-on-surface-variant hover:text-secondary hover:bg-secondary-container/20 rounded-full transition-colors">
<span className="material-symbols-outlined text-xl">edit</span>
</button>
<button className="p-2 text-on-surface-variant hover:text-error hover:bg-error-container/30 rounded-full transition-colors">
<span className="material-symbols-outlined text-xl">delete</span>
</button>
</div>
</div>

<div className="bg-surface-container-lowest rounded-xl p-lg flex flex-col hover:shadow-[0px_4px_20px_rgba(20,20,20,0.04)] transition-shadow duration-300 group">
<div className="relative w-full h-48 rounded-lg mb-lg overflow-hidden border-[0.5px] border-tertiary/5 bg-surface-container-low">
<img className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" alt="Winter Wear Overcoat" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBruxVkR7kSjwfVYVVdpY6vPCrAdR8L149RHER2_kihib7TfR14yfXR71NRaIwWehUrdD6hgVwHJlT5FKqqXo9AMnfeVq9es4xnmc_zZNf7is-eirYw8NcpNQ_Lm1ViJUFHS9HzXeOO-gmrp0ZNpnbSMQp8dVd6CGv_lSc9paigK5q7kyLd4CTtpXvSPR0yjosEtXbX3KTUva_iNJzXV1JrqxijvLGCEpXiee_1qSSQDJes002PIUkZ" />
<div className="absolute top-3 left-3 bg-surface-container-lowest/90 backdrop-blur-sm px-3 py-1 rounded-full border border-outline-variant/20">
<span className="font-label-sm text-label-sm text-primary">30 Products</span>
</div>
</div>
<div className="flex justify-between items-center mb-md">
<h3 className="font-headline-md text-headline-md text-primary">Winter Wear</h3>
<label className="relative inline-flex items-center cursor-pointer">
<input defaultChecked={true} className="sr-only peer" type="checkbox" value="" />
<div className="w-11 h-6 bg-surface-variant peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-secondary"></div>
</label>
</div>
<div className="flex justify-end gap-sm mt-auto pt-4 border-t border-outline-variant/10">
<button className="p-2 text-on-surface-variant hover:text-secondary hover:bg-secondary-container/20 rounded-full transition-colors">
<span className="material-symbols-outlined text-xl">edit</span>
</button>
<button className="p-2 text-on-surface-variant hover:text-error hover:bg-error-container/30 rounded-full transition-colors">
<span className="material-symbols-outlined text-xl">delete</span>
</button>
</div>
</div><button className="border-2 border-dashed border-outline-variant/30 rounded-xl p-lg flex flex-col items-center justify-center min-h-[300px] hover:bg-surface-container-low hover:border-primary/30 transition-all duration-300 group cursor-pointer bg-transparent">
<div className="w-16 h-16 rounded-full bg-surface-container-high flex items-center justify-center mb-md group-hover:bg-secondary-container/50 transition-colors">
<span className="material-symbols-outlined text-3xl text-on-surface-variant group-hover:text-secondary transition-colors">add</span>
</div>
<span className="font-label-lg text-label-lg text-primary tracking-widest">ADD NEW CATEGORY</span>
</button>
</div>

<div className="bg-surface-container-lowest rounded-xl p-xl border border-outline-variant/10 max-w-4xl mx-auto shadow-[0px_4px_20px_rgba(20,20,20,0.02)]">
<h2 className="font-headline-lg text-headline-lg text-primary mb-xl border-b border-outline-variant/10 pb-sm">Edit Category</h2>
<form className="grid grid-cols-1 md:grid-cols-12 gap-xl">

<div className="md:col-span-4 flex flex-col gap-md">
<label className="font-label-lg text-label-lg text-primary uppercase">Category Image</label>
<div className="aspect-square w-full rounded-lg border-2 border-dashed border-outline-variant/40 bg-background flex flex-col items-center justify-center cursor-pointer hover:bg-surface-container-low transition-colors relative overflow-hidden group">


<div className="z-10 flex flex-col items-center text-on-surface-variant group-hover:text-primary transition-colors">
<span className="material-symbols-outlined text-4xl mb-2">cloud_upload</span>
<span className="font-body-sm text-body-sm text-center px-4">Drag and drop or<br />click to upload</span>
</div>
</div>
<p className="font-body-sm text-body-sm text-on-surface-variant/70 text-center">Recommended: 800x800px (JPG/PNG)</p>
</div>

<div className="md:col-span-8 flex flex-col gap-lg">
<div className="flex flex-col gap-sm">
<label className="font-label-lg text-label-lg text-primary uppercase tracking-wider" htmlFor="cat-name">Category Name</label>
<input className="w-full p-4 rounded-lg bg-surface-container-lowest border border-outline-variant/30 font-body-md text-body-md text-primary focus:ring-1 focus:ring-secondary focus:border-secondary outline-none transition-all" id="cat-name" type="text" value="Shirts" />
</div>
<div className="flex flex-col gap-sm">
<label className="font-label-lg text-label-lg text-primary uppercase tracking-wider" htmlFor="cat-desc">Description <span className="text-on-surface-variant font-normal text-xs">(Optional)</span></label>
<textarea className="w-full p-4 rounded-lg bg-surface-container-lowest border border-outline-variant/30 font-body-md text-body-md text-primary focus:ring-1 focus:ring-secondary focus:border-secondary outline-none transition-all resize-none" id="cat-desc" rows={3}>Premium cotton and linen blend shirts for formal and casual wear.</textarea>
</div>
<div className="grid grid-cols-2 gap-md">
<div className="flex flex-col gap-sm">
<label className="font-label-lg text-label-lg text-primary uppercase tracking-wider" htmlFor="cat-sort">Sort Order</label>
<input className="w-full p-4 rounded-lg bg-surface-container-lowest border border-outline-variant/30 font-body-md text-body-md text-primary focus:ring-1 focus:ring-secondary focus:border-secondary outline-none transition-all" id="cat-sort" type="number" value="1" />
</div>
<div className="flex flex-col gap-sm justify-center pt-6">
<div className="flex items-center justify-between p-4 rounded-lg border border-outline-variant/20 bg-background">
<span className="font-label-lg text-label-lg text-primary">Active Status</span>
<label className="relative inline-flex items-center cursor-pointer">
<input defaultChecked={true} className="sr-only peer" type="checkbox" value="" />
<div className="w-11 h-6 bg-surface-variant peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-secondary"></div>
</label>
</div>
</div>
</div>
<div className="mt-xl flex justify-end gap-md pt-lg border-t border-outline-variant/10">
<button className="px-8 py-3 rounded-full font-label-lg text-label-lg text-primary hover:bg-surface-container-low transition-colors" type="button">
                            CANCEL
                        </button>
<button className="bg-primary text-on-primary font-label-lg text-label-lg px-8 py-3 rounded-full hover:bg-opacity-90 transition-opacity" type="button">
                            SAVE CATEGORY
                        </button>
</div>
</div>
</form>
</div>
</main>
  );
}