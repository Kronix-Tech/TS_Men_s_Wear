export default function AdminDashboardMenSWear() {
  return (
    <main className="pt-24 pb-xxl px-margin-mobile md:px-margin-desktop md:ml-[240px] max-w-container-max mx-auto">

<div className="flex flex-col md:flex-row md:items-center justify-between gap-md mb-xl">
<h2 className="font-display-lg text-display-lg text-primary tracking-tight">DASHBOARD</h2>
<div className="flex flex-wrap gap-sm">
<button className="px-4 py-2 rounded-full bg-[#8FB0A4] text-on-primary font-label-sm text-label-sm transition-colors">Today</button>
<button className="px-4 py-2 rounded-full bg-surface-container-lowest border border-outline-variant/20 text-on-surface-variant font-label-sm text-label-sm hover:border-[#141414]/30 transition-colors">7 Days</button>
<button className="px-4 py-2 rounded-full bg-surface-container-lowest border border-outline-variant/20 text-on-surface-variant font-label-sm text-label-sm hover:border-[#141414]/30 transition-colors">30 Days</button>
<button className="px-4 py-2 rounded-full bg-surface-container-lowest border border-outline-variant/20 text-on-surface-variant font-label-sm text-label-sm hover:border-[#141414]/30 transition-colors">Year</button>
</div>
</div>

<div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-gutter mb-xxl">

<div className="bg-surface-container-lowest rounded-[24px] p-lg flex flex-col gap-sm relative overflow-hidden group">
<div className="absolute -right-12 -top-12 w-32 h-32 bg-[#8FB0A4]/5 rounded-full blur-2xl group-hover:bg-[#8FB0A4]/10 transition-colors"></div>
<div className="flex justify-between items-start z-10">
<p className="font-label-lg text-label-lg text-on-surface-variant uppercase tracking-widest">Total Revenue</p>
<span className="material-symbols-outlined text-outline-variant">attach_money</span>
</div>
<div className="flex items-baseline gap-sm z-10">
<h3 className="font-headline-lg text-headline-lg text-primary">$12,480</h3>
<span className="inline-flex items-center gap-xs px-2 py-1 rounded-full bg-[#8FB0A4]/10 text-[#4a695f] font-label-sm text-[10px]">
<span className="material-symbols-outlined text-[14px]">trending_up</span> +12%
                    </span>
</div>
</div>

<div className="bg-surface-container-lowest rounded-[24px] p-lg flex flex-col gap-sm">
<div className="flex justify-between items-start">
<p className="font-label-lg text-label-lg text-on-surface-variant uppercase tracking-widest">Orders</p>
<span className="material-symbols-outlined text-outline-variant">local_shipping</span>
</div>
<div className="flex items-baseline gap-sm mt-auto">
<h3 className="font-headline-lg text-headline-lg text-primary">156</h3>
</div>
</div>

<div className="bg-surface-container-lowest rounded-[24px] p-lg flex flex-col gap-sm">
<div className="flex justify-between items-start">
<p className="font-label-lg text-label-lg text-on-surface-variant uppercase tracking-widest">Customers</p>
<span className="material-symbols-outlined text-outline-variant">group</span>
</div>
<div className="flex items-baseline gap-sm mt-auto">
<h3 className="font-headline-lg text-headline-lg text-primary">89</h3>
</div>
</div>

<div className="bg-surface-container-lowest rounded-[24px] p-lg flex flex-col gap-sm">
<div className="flex justify-between items-start">
<p className="font-label-lg text-label-lg text-on-surface-variant uppercase tracking-widest">Avg Order Value</p>
<span className="material-symbols-outlined text-outline-variant">shopping_bag</span>
</div>
<div className="flex items-baseline gap-sm mt-auto">
<h3 className="font-headline-lg text-headline-lg text-primary">$80</h3>
</div>
</div>
</div>

<div className="grid grid-cols-1 lg:grid-cols-3 gap-gutter mb-xxl">

<div className="lg:col-span-2 bg-surface-container-lowest rounded-[24px] p-lg flex flex-col">
<div className="flex justify-between items-center mb-xl">
<h3 className="font-headline-md text-headline-md text-primary">Sales Overview</h3>
<button className="p-2 rounded-full hover:bg-surface-container transition-colors">
<span className="material-symbols-outlined text-on-surface-variant">more_horiz</span>
</button>
</div>

<div className="relative w-full h-64 flex-1 flex items-end border-b border-l border-outline-variant/20 pb-2 pl-2">

<div className="absolute left-[-30px] h-full flex flex-col justify-between font-label-sm text-label-sm text-on-surface-variant/50 py-2">
<span className="">$5k</span>
<span className="">$2.5k</span>
<span className="">$0</span>
</div>

<div className="w-full h-full relative overflow-hidden">

<div className="absolute inset-0 flex flex-col justify-between pointer-events-none">
<div className="w-full border-b border-outline-variant/10"></div>
<div className="w-full border-b border-outline-variant/10"></div>
<div className="w-full border-b border-outline-variant/10"></div>
</div>

<svg className="absolute inset-0 w-full h-full" preserveAspectRatio="none" viewBox="0 0 100 100">
<path d="M0,80 C10,75 20,90 30,60 C40,30 50,70 60,40 C70,10 80,50 90,20 L100,10 L100,100 L0,100 Z" fill="url(#gradient)" opacity="0.1"></path>
<path d="M0,80 C10,75 20,90 30,60 C40,30 50,70 60,40 C70,10 80,50 90,20 L100,10" fill="none" stroke="#8FB0A4" stroke-width="2" vector-effect="non-scaling-stroke"></path>
<defs>
<linearGradient id="gradient" x1="0%" x2="0%" y1="0%" y2="100%">
<stop offset="0%" stop-color="#8FB0A4" stop-opacity="1"></stop>
<stop offset="100%" stop-color="#8FB0A4" stop-opacity="0"></stop>
</linearGradient>
</defs>
</svg>
</div>

<div className="absolute bottom-[-24px] w-full flex justify-between font-label-sm text-label-sm text-on-surface-variant/50 px-2">
<span className="">Mon</span>
<span className="">Wed</span>
<span className="">Fri</span>
<span className="">Sun</span>
</div>
</div>
</div>

<div className="bg-surface-container-lowest rounded-[24px] p-lg flex flex-col">
<h3 className="font-headline-md text-headline-md text-primary mb-xl">Category Distribution</h3>
<div className="flex-1 flex flex-col items-center justify-center">
<div className="relative w-48 h-48 rounded-full border-[16px] border-[#8FB0A4] border-t-[#141414] border-r-outline-variant/20 border-b-[#8FB0A4]/40 flex items-center justify-center">
<div className="text-center">
<span className="block font-headline-md text-headline-md text-primary leading-none">156</span>
<span className="font-label-sm text-label-sm text-on-surface-variant">Total Items</span>
</div>
</div>
<div className="w-full mt-xl flex flex-col gap-sm">
<div className="flex justify-between items-center font-body-sm text-body-sm">
<div className="flex items-center gap-xs"><span className="w-3 h-3 rounded-full bg-[#141414]"></span> Shirts</div>
<span className="font-medium">45%</span>
</div>
<div className="flex justify-between items-center font-body-sm text-body-sm">
<div className="flex items-center gap-xs"><span className="w-3 h-3 rounded-full bg-[#8FB0A4]"></span> Trousers</div>
<span className="font-medium">35%</span>
</div>
<div className="flex justify-between items-center font-body-sm text-body-sm">
<div className="flex items-center gap-xs"><span className="w-3 h-3 rounded-full bg-outline-variant/50"></span> Jeans</div>
<span className="font-medium">20%</span>
</div>
</div>
</div>
</div>
</div>

<div className="grid grid-cols-1 lg:grid-cols-3 gap-gutter">

<div className="lg:col-span-2 bg-surface-container-lowest rounded-[24px] p-lg flex flex-col">
<div className="flex justify-between items-center mb-lg">
<h3 className="font-headline-md text-headline-md text-primary">Recent Orders</h3>
<a className="font-label-sm text-label-sm text-on-surface-variant hover:text-primary transition-colors underline decoration-1 underline-offset-4" href="#">View all</a>
</div>
<div className="overflow-x-auto">
<table className="w-full text-left border-collapse">
<thead>
<tr className="border-b border-outline-variant/10">
<th className="py-3 font-label-lg text-label-lg text-on-surface-variant uppercase tracking-widest font-normal">Order ID</th>
<th className="py-3 font-label-lg text-label-lg text-on-surface-variant uppercase tracking-widest font-normal">Customer</th>
<th className="py-3 font-label-lg text-label-lg text-on-surface-variant uppercase tracking-widest font-normal">Date</th>
<th className="py-3 font-label-lg text-label-lg text-on-surface-variant uppercase tracking-widest font-normal">Status</th>
<th className="py-3 font-label-lg text-label-lg text-on-surface-variant uppercase tracking-widest font-normal text-right">Total</th>
</tr>
</thead>
<tbody className="font-body-sm text-body-sm text-on-surface">
<tr className="border-b border-outline-variant/5 hover:bg-surface-container/30 transition-colors">
<td className="py-4 font-medium">#ORD-092</td>
<td className="py-4">Alexander Pierce</td>
<td className="py-4 text-on-surface-variant">Today, 10:42 AM</td>
<td className="py-4">
<span className="inline-flex items-center px-2 py-1 rounded-md bg-[#8FB0A4]/10 text-[#4a695f] font-label-sm text-[11px] uppercase tracking-wider">Processing</span>
</td>
<td className="py-4 text-right font-medium">$450.00</td>
</tr>
<tr className="border-b border-outline-variant/5 hover:bg-surface-container/30 transition-colors">
<td className="py-4 font-medium">#ORD-091</td>
<td className="py-4">Jameson Wright</td>
<td className="py-4 text-on-surface-variant">Yesterday</td>
<td className="py-4">
<span className="inline-flex items-center px-2 py-1 rounded-md bg-outline-variant/20 text-on-surface-variant font-label-sm text-[11px] uppercase tracking-wider">Shipped</span>
</td>
<td className="py-4 text-right font-medium">$1,200.00</td>
</tr>
<tr className="border-b border-outline-variant/5 hover:bg-surface-container/30 transition-colors">
<td className="py-4 font-medium">#ORD-090</td>
<td className="py-4">Marcus Cole</td>
<td className="py-4 text-on-surface-variant">Oct 24, 2026</td>
<td className="py-4">
<span className="inline-flex items-center px-2 py-1 rounded-md bg-[#141414] text-white font-label-sm text-[11px] uppercase tracking-wider">Delivered</span>
</td>
<td className="py-4 text-right font-medium">$85.00</td>
</tr>
<tr className="hover:bg-surface-container/30 transition-colors">
<td className="py-4 font-medium">#ORD-089</td>
<td className="py-4">Nathaniel Reed</td>
<td className="py-4 text-on-surface-variant">Oct 23, 2026</td>
<td className="py-4">
<span className="inline-flex items-center px-2 py-1 rounded-md bg-[#141414] text-white font-label-sm text-[11px] uppercase tracking-wider">Delivered</span>
</td>
<td className="py-4 text-right font-medium">$320.00</td>
</tr>
<tr className="border-b border-outline-variant/5 hover:bg-surface-container/30 transition-colors"><td className="py-4 font-medium">#ORD-088</td><td className="py-4">Jameson Wright</td><td className="py-4 text-on-surface-variant">Oct 22, 2026</td><td className="py-4"><span className="inline-flex items-center px-2 py-1 rounded-md bg-[#141414] text-white font-label-sm text-[11px] uppercase tracking-wider">Delivered</span></td><td className="py-4 text-right font-medium">$145.00</td></tr><tr className="hover:bg-surface-container/30 transition-colors"><td className="py-4 font-medium">#ORD-087</td><td className="py-4">Marcus Cole</td><td className="py-4 text-on-surface-variant">Oct 21, 2026</td><td className="py-4"><span className="inline-flex items-center px-2 py-1 rounded-md bg-outline-variant/20 text-on-surface-variant font-label-sm text-[11px] uppercase tracking-wider">Shipped</span></td><td className="py-4 text-right font-medium">$210.00</td></tr></tbody>
</table>
</div>
</div>

<div className="flex flex-col gap-gutter">

<div className="bg-surface-container-lowest rounded-[24px] p-lg">
<div className="flex items-center gap-sm mb-md text-error">
<span className="material-symbols-outlined">warning</span>
<h3 className="font-headline-md text-headline-md text-primary">Low Stock Alerts</h3>
</div>
<ul className="flex flex-col gap-md">
<li className="flex items-center justify-between pb-md border-b border-outline-variant/10">
<div className="flex flex-col">
<span className="font-body-sm text-body-sm font-medium">Selvedge Jeans</span>
<span className="font-label-sm text-label-sm text-error">3 left in stock</span>
</div>
<button className="px-4 py-2 rounded-full border border-[#141414] text-[#141414] font-label-sm text-label-sm hover:bg-[#141414] hover:text-white transition-colors">Restock</button>
</li>
<li className="flex items-center justify-between">
<div className="flex flex-col">
<span className="font-body-sm text-body-sm font-medium">Wool Trousers</span>
<span className="font-label-sm text-label-sm text-error">5 left in stock</span>
</div>
<button className="px-4 py-2 rounded-full border border-[#141414] text-[#141414] font-label-sm text-label-sm hover:bg-[#141414] hover:text-white transition-colors">Restock</button>
</li>
</ul>
</div>

<div className="bg-surface-container-lowest rounded-[24px] p-lg">
<h3 className="font-headline-md text-headline-md text-primary mb-md">Pending Tasks</h3>
<div className="flex flex-col gap-sm">
<a className="flex items-center gap-md p-md rounded-xl bg-surface hover:bg-surface-container transition-colors group" href="#">
<div className="w-10 h-10 rounded-full bg-[#8FB0A4]/10 flex items-center justify-center text-[#4a695f]">
<span className="material-symbols-outlined">local_shipping</span>
</div>
<div className="flex flex-col">
<span className="font-body-sm text-body-sm font-medium">5 orders to ship</span>
<span className="font-label-sm text-label-sm text-on-surface-variant">Requires attention today</span>
</div>
<span className="material-symbols-outlined ml-auto text-outline-variant group-hover:translate-x-1 transition-transform">arrow_forward</span>
</a>
<a className="flex items-center gap-md p-md rounded-xl bg-surface hover:bg-surface-container transition-colors group" href="#">
<div className="w-10 h-10 rounded-full bg-outline-variant/20 flex items-center justify-center text-on-surface-variant">
<span className="material-symbols-outlined">assignment_return</span>
</div>
<div className="flex flex-col">
<span className="font-body-sm text-body-sm font-medium">2 returns to approve</span>
<span className="font-label-sm text-label-sm text-on-surface-variant">Waiting for inspection</span>
</div>
<span className="material-symbols-outlined ml-auto text-outline-variant group-hover:translate-x-1 transition-transform">arrow_forward</span>
</a>
</div>
</div>

<div className="bg-surface-container-lowest rounded-[24px] p-lg">
<h3 className="font-headline-md text-headline-md text-primary mb-md">Top Products</h3>
<ul className="flex flex-col gap-sm">
<li className="flex items-center gap-md">
<div className="w-12 h-12 rounded-lg overflow-hidden bg-surface-dim border border-outline-variant/10">
<img className="w-full h-full object-cover" data-alt="A meticulously folded crisp white men's dress shirt laid flat on a clean minimalist surface. High quality luxury menswear product photography, soft even lighting, highlighting the fabric texture." src="https://lh3.googleusercontent.com/aida-public/AB6AXuD7RuXAqCF-12YCwyVlbUuLly_QKMRjl_iu_b-duhbQjwiGNOnQUx4FSBj7hDX80nmSu-UYa2Vg41I-DQo6RojOSQOrBPFWnpKT8wcKJN5ZSpKgziZyg7yE9gENXZFgK79M4CAeNCOlqkYPeQ5oX0UdpHOMsvtVPtTHIkuhTQLwkAJGMUp7tQxo04FzkJDxfWOK79KMPaEuT4Xjt-AS2sTo9Ui7PuVT2qDEWoh6XAzSRoxKTmJ3SVYX" />
</div>
<div className="flex flex-col flex-1">
<span className="font-body-sm text-body-sm font-medium">Oxford Cloth Button Down</span>
<span className="font-label-sm text-label-sm text-on-surface-variant">42 sold this week</span>
</div>
</li>
<li className="flex items-center gap-md">
<div className="w-12 h-12 rounded-lg overflow-hidden bg-surface-dim border border-outline-variant/10">
<img className="w-full h-full object-cover" data-alt="A pair of beautifully crafted dark brown leather men's dress shoes, polished and elegant, presented against a soft light grey background. Premium high-end retail photography aesthetic, sharp focus." src="https://lh3.googleusercontent.com/aida-public/AB6AXuD-qcvS7v3IDc2QdhVzH57IpEnEBW76gC1tVlDt6d5RKTY7Dpw2WsUhtD2_WbW6019lQVuQkW4E-5nqcdDHsQMX2zI_PMIuXXuZa5Hu5wkigTPfx37Uo2FDJWWE8nCm_wa0wvylJL2YtruBCV4KxxhIOMl5BhaeQAZVG6UFuEUA7zvHmFS84_C9ZgIWL_uoZlfMorChNk-aMp_3eQuG1-6yzUZ5DEYR5khQAbJQIJFofGdtaXbANKJ0" />
</div>
<div className="flex flex-col flex-1">
<span className="font-body-sm text-body-sm font-medium">Selvedge Jeans</span>
<span className="font-label-sm text-label-sm text-on-surface-variant">28 sold this week</span>
</div>
</li>
</ul>
</div>
</div>
</div>
</main>
  );
}