export default function ReturnsRefundsRefinedTableMenSWear() {
  return (
    <main className="flex-1 ml-0 md:ml-64 flex flex-col h-screen overflow-hidden bg-background">

<header className="hidden md:flex justify-between items-center h-16 px-xl w-full bg-surface shadow-sm sticky top-0 z-30">
<div className="flex-1 flex items-center">

<div className="relative w-64">
<span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-on-surface-variant text-[20px]">search</span>
<input className="w-full h-10 pl-10 pr-4 rounded-lg bg-surface-container-low border border-outline-variant focus:border-secondary focus:ring-1 focus:ring-secondary text-body-sm font-body-sm placeholder:text-on-surface-variant transition-colors" placeholder="Search returns..." type="text"/>
</div>
</div>
<div className="flex items-center gap-md">
<button className="relative text-on-surface-variant hover:text-primary transition-colors p-2 rounded-full hover:bg-surface-variant/50">
<span className="material-symbols-outlined" data-icon="notifications">notifications</span>
<span className="absolute top-1.5 right-1.5 w-2 h-2 bg-error rounded-full"></span>
</button>
<div className="w-8 h-8 rounded-full overflow-hidden bg-surface-variant border border-outline-variant/30 ml-sm cursor-pointer">
<img alt="Admin User Avatar" className="w-full h-full object-cover" data-alt="A close up, high quality photograph of a professional man wearing a tailored navy suit. Clean, minimal, neutral grey background. Modern lighting, sharp focus on face." src="https://lh3.googleusercontent.com/aida-public/AB6AXuDA_1tIfzLqa_Gwws8wteRzoyo-97-f5DzlLFaQEqLenGMKrWemtKmvb27z4BoXFP0pKoS81Trbods5dxi0zNrlVPY2Yax085dQzSt8XRivh5_HyjuSvdDVyCW5InZn8KJ56HCHH95grg55JR3YhrHcZIHLbG9MfkJvfdgZ1HLLaI1E8OYjG4h_xVHI-cjaUywfHc0DAWOC5kWHqHkIM_2TDLSmE1lsWYO-bXd2W8S_eMKJMxMAclFZ"/>
</div>
</div>
</header>

<div className="flex-1 overflow-y-auto p-margin-mobile md:p-margin-desktop no-scrollbar pt-20 md:pt-margin-desktop">
<div className="max-w-container-max mx-auto">

<div className="flex flex-col xl:flex-row gap-lg">

<div className="flex-1 xl:w-3/4 flex flex-col gap-lg">

<div>
<h1 className="font-display-lg-mobile md:font-display-lg text-display-lg-mobile md:text-display-lg text-primary uppercase tracking-tight">RETURNS</h1>
<p className="font-body-md text-body-md text-on-surface-variant mt-xs">Manage customer return requests and issue refunds.</p>
</div>

<div className="flex flex-wrap items-center gap-sm">
<button className="px-4 py-2 rounded-full font-label-sm text-label-sm uppercase tracking-wider bg-[#8FB0A4] text-[#002019] transition-colors border border-transparent shadow-[0px_4px_20px_rgba(20,20,20,0.04)]">
                                Requested 4
                            </button>
<button className="px-4 py-2 rounded-full font-label-sm text-label-sm uppercase tracking-wider bg-surface-container-lowest text-on-surface-variant hover:bg-surface-variant transition-colors border border-outline-variant/30">
                                Approved 2
                            </button>
<button className="px-4 py-2 rounded-full font-label-sm text-label-sm uppercase tracking-wider bg-surface-container-lowest text-on-surface-variant hover:bg-surface-variant transition-colors border border-outline-variant/30">
                                Picked Up 1
                            </button>
<button className="px-4 py-2 rounded-full font-label-sm text-label-sm uppercase tracking-wider bg-surface-container-lowest text-on-surface-variant hover:bg-surface-variant transition-colors border border-outline-variant/30">
                                Refunded 12
                            </button>
<button className="px-4 py-2 rounded-full font-label-sm text-label-sm uppercase tracking-wider bg-surface-container-lowest text-on-surface-variant hover:bg-surface-variant transition-colors border border-outline-variant/30">
                                Rejected 3
                            </button>
</div>

<div className="bg-surface-container-lowest rounded-xl overflow-x-auto flex flex-col">

<div className="grid grid-cols-[80px_90px_1fr_2fr_100px_120px_100px_70px] min-w-[800px] gap-sm px-lg py-md border-b border-primary/5 bg-surface-container-low hidden lg:grid">
<span className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider">Return ID</span>
<span className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider">Order ID</span>
<span className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider">Customer</span>
<span className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider">Item</span>
<span className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider">Reason</span>
<span className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider">Requested</span>
<span className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider">Method</span>
<span className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider">Status</span>
<span className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider text-right">Actions</span>
</div>

<div className="flex flex-col min-w-[800px] divide-y divide-primary/5">

<div className="grid grid-cols-1 lg:grid-cols-[80px_90px_1fr_2fr_100px_120px_100px_70px] gap-sm lg:items-center px-md lg:px-lg py-md lg:py-sm hover:bg-surface/50 transition-colors"><div className="font-body-sm text-body-sm text-primary font-medium">#RET-101</div><div className="font-body-sm text-body-sm text-on-surface-variant">#MW-2481</div><div className="font-body-sm text-body-sm text-primary">James Wilson</div><div className="flex items-center gap-3"><div className="w-10 h-10 rounded overflow-hidden bg-surface-variant flex-shrink-0 border border-black/5"><img className="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCi4Ystl6t3nNL-fKa5ZT3uyajKYVf-CrjZ4Iu3gRg4tC2kuzoxn4etRSrjvNSleB-QFILkF4K8iUg7BHG2t2ezTQsR8Qa07b71p9E_fy9dSbpiM--2hx5fo6e0VSZmSo99dImMZwEO_ILAmRyMtZIAF52qxBOvj9h81STAltJDJWTmlRo7JW50lZ_GFqHQQRCkO8QGNO_M7fdRhPjQGQ-0ped_iHAPdEqQDkTli5veBxzWkTUhoj6M"/></div><div className="flex flex-col"><span className="font-body-sm text-body-sm text-primary truncate max-w-[150px]">Oxford Cotton Shirt</span><span className="font-label-sm text-label-sm text-on-surface-variant">Size: M</span></div></div><div><span className="px-2 py-1 rounded bg-surface-variant text-on-surface-variant font-label-sm text-[11px] uppercase tracking-wider">Size Issue</span></div><div className="flex flex-col"><span className="font-body-sm text-body-sm text-primary">Aug 22, 2026</span><span className="font-label-sm text-[10px] text-on-surface-variant uppercase tracking-wider">Bank</span></div><div><span className="px-2 py-1 rounded bg-[#c5e7da] text-[#2e4d43] font-label-sm text-[11px] uppercase tracking-wider flex items-center w-fit gap-1"><span className="w-1.5 h-1.5 rounded-full bg-[#2e4d43]"></span> Requested</span></div><div className="flex items-center justify-end gap-1"><button className="w-8 h-8 rounded-full flex items-center justify-center text-primary hover:bg-surface-variant transition-colors" title="Approve"><span className="material-symbols-outlined text-[18px]">check</span></button><button className="w-8 h-8 rounded-full flex items-center justify-center text-error hover:bg-error-container hover:text-on-error-container transition-colors" title="Reject"><span className="material-symbols-outlined text-[18px]">close</span></button></div></div>

<div className="grid grid-cols-1 lg:grid-cols-[80px_90px_1fr_2fr_100px_120px_100px_70px] gap-sm lg:items-center px-md lg:px-lg py-md lg:py-sm hover:bg-surface/50 transition-colors"><div className="font-body-sm text-body-sm text-primary font-medium">#RET-102</div><div className="font-body-sm text-body-sm text-on-surface-variant">#MW-2489</div><div className="font-body-sm text-body-sm text-primary">Michael Chang</div><div className="flex items-center gap-3"><div className="w-10 h-10 rounded overflow-hidden bg-surface-variant flex-shrink-0 border border-black/5"><img className="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCk5hLiPzcbYohfKYW9QWPW0YyE59FwbHw4wZLKFRCgILyp9taNF9HFF9kPaYsT1wbKv3la8mecTrNF2GlMLjeikKVAp6q1trYCo-bOvXu5ohwGw7yFJ5s3YIsg_RNIWNLOuPKwHBvKo6P6IC78YRdnnOT9KHHHDVFnXGECC7tvGrWzYHgD4C2seX5AN4QYWNreTkD734_WZeRpLySwwGF3ty3fEUleVo-RsQ77BBWMS0GLoJCtGk7W"/></div><div className="flex flex-col"><span className="font-body-sm text-body-sm text-primary truncate max-w-[150px]">Wool Blend Blazer</span><span className="font-label-sm text-label-sm text-on-surface-variant">Size: 42R</span></div></div><div><span className="px-2 py-1 rounded bg-surface-variant text-on-surface-variant font-label-sm text-[11px] uppercase tracking-wider">Quality</span></div><div className="flex flex-col"><span className="font-body-sm text-body-sm text-primary">Aug 21, 2026</span><span className="font-label-sm text-[10px] text-on-surface-variant uppercase tracking-wider">Wallet</span></div><div><span className="px-2 py-1 rounded bg-[#c5e7da] text-[#2e4d43] font-label-sm text-[11px] uppercase tracking-wider flex items-center w-fit gap-1"><span className="w-1.5 h-1.5 rounded-full bg-[#2e4d43]"></span> Requested</span></div><div className="flex items-center justify-end gap-1"><button className="w-8 h-8 rounded-full flex items-center justify-center text-primary hover:bg-surface-variant transition-colors" title="Approve"><span className="material-symbols-outlined text-[18px]">check</span></button><button className="w-8 h-8 rounded-full flex items-center justify-center text-error hover:bg-error-container hover:text-on-error-container transition-colors" title="Reject"><span className="material-symbols-outlined text-[18px]">close</span></button></div></div>

<div className="grid grid-cols-1 lg:grid-cols-[80px_90px_1fr_2fr_100px_120px_100px_70px] gap-sm lg:items-center px-md lg:px-lg py-md lg:py-sm hover:bg-surface/50 transition-colors"><div className="font-body-sm text-body-sm text-primary font-medium">#RET-098</div><div className="font-body-sm text-body-sm text-on-surface-variant">#MW-2470</div><div className="font-body-sm text-body-sm text-primary">David Miller</div><div className="flex items-center gap-3"><div className="w-10 h-10 rounded overflow-hidden bg-surface-variant flex-shrink-0 border border-black/5"><img className="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCx7zv8tAfN2foOktQSSyuUFchEna1N1b3PsePSPfmcNnHH6uvmf0Tz3kI1EjiXD3qddZ6uMMDDthRFG-cc1il9X20LQyPOapfa7XBllxAUWgpC3BPFzs-59ICYQbYXklHubSJ7hF0mqZ61gD2A0-V5wIHib-HMUP3mny5JJlU7l-93Eu7Ehn_7OARR1OBXSxv7w4hLoJ9gcii3QsJ8gKp4Z25T7xAHNv4GDVUbTnlZZbe4RYKBnmNg"/></div><div className="flex flex-col"><span className="font-body-sm text-body-sm text-primary truncate max-w-[150px]">Raw Denim Jeans</span><span className="font-label-sm text-label-sm text-on-surface-variant">Size: 32x32</span></div></div><div><span className="px-2 py-1 rounded bg-surface-variant text-on-surface-variant font-label-sm text-[11px] uppercase tracking-wider">Size Issue</span></div><div className="flex flex-col"><span className="font-body-sm text-body-sm text-primary">Aug 20, 2026</span><span className="font-label-sm text-[10px] text-on-surface-variant uppercase tracking-wider">UPI</span></div><div><span className="px-2 py-1 rounded bg-surface-container-highest text-on-surface font-label-sm text-[11px] uppercase tracking-wider flex items-center w-fit gap-1"><span className="w-1.5 h-1.5 rounded-full bg-outline"></span> Approved</span></div><div className="flex items-center justify-end"><a className="font-label-sm text-label-sm text-primary hover:underline uppercase tracking-wider" href="#">View</a></div></div>

<div className="grid grid-cols-1 lg:grid-cols-[80px_90px_1fr_2fr_100px_120px_100px_70px] gap-sm lg:items-center px-md lg:px-lg py-md lg:py-sm hover:bg-surface/50 transition-colors opacity-70 hover:opacity-100"><div className="font-body-sm text-body-sm text-primary font-medium">#RET-095</div><div className="font-body-sm text-body-sm text-on-surface-variant">#MW-2412</div><div className="font-body-sm text-body-sm text-primary">Robert Chen</div><div className="flex items-center gap-3"><div className="w-10 h-10 rounded overflow-hidden bg-surface-variant flex-shrink-0 border border-black/5"><img className="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCVsV7r_MUdiKD-IPv8ieGzxY23g_ibc43u_Sv5ZV4p2-cuB6UBLLplxgO_JnEhKqp_NDj_wEvn9yP2rGqJNu5Vxwuti-riY-wAtRnBlVps0IQM9Mns_cZ3DlTzbYCyokww9e6714Mnv81J48dalhWg6P4PugNIUIuGeZvb6cA2qBFHro8pAsJBeArQFMt7eX8-SszcdZlDgCVjgR2CpQ7LUtLP5dCOw58HLnPxNlN61K3ZqHQqMBUn"/></div><div className="flex flex-col"><span className="font-body-sm text-body-sm text-primary truncate max-w-[150px]">Heavyweight Tee</span><span className="font-label-sm text-label-sm text-on-surface-variant">Size: L</span></div></div><div><span className="px-2 py-1 rounded bg-surface-variant text-on-surface-variant font-label-sm text-[11px] uppercase tracking-wider">Wrong Item</span></div><div className="flex flex-col"><span className="font-body-sm text-body-sm text-primary">Aug 15, 2026</span><span className="font-label-sm text-[10px] text-on-surface-variant uppercase tracking-wider">Bank</span></div><div><span className="px-2 py-1 rounded bg-surface-container text-outline font-label-sm text-[11px] uppercase tracking-wider flex items-center w-fit gap-1"><span className="w-1.5 h-1.5 rounded-full bg-outline-variant"></span> Refunded</span></div><div className="flex items-center justify-end"><a className="font-label-sm text-label-sm text-primary hover:underline uppercase tracking-wider" href="#">View</a></div></div>
</div>
</div>

<div className="flex justify-center items-center gap-2 mt-md">
<button className="w-8 h-8 rounded flex items-center justify-center text-on-surface-variant hover:bg-surface-variant transition-colors" disabled={true}>
<span className="material-symbols-outlined text-[20px]">chevron_left</span>
</button>
<button className="w-8 h-8 rounded flex items-center justify-center bg-primary text-on-primary font-label-sm transition-colors">1</button>
<button className="w-8 h-8 rounded flex items-center justify-center text-on-surface-variant hover:bg-surface-variant transition-colors font-label-sm">2</button>
<button className="w-8 h-8 rounded flex items-center justify-center text-on-surface-variant hover:bg-surface-variant transition-colors font-label-sm">3</button>
<span className="text-on-surface-variant mx-1">...</span>
<button className="w-8 h-8 rounded flex items-center justify-center text-on-surface-variant hover:bg-surface-variant transition-colors font-label-sm">12</button>
<button className="w-8 h-8 rounded flex items-center justify-center text-on-surface-variant hover:bg-surface-variant transition-colors">
<span className="material-symbols-outlined text-[20px]">chevron_right</span>
</button>
</div>
</div>

<div className="w-full xl:w-1/4 flex-shrink-0">
<div className="bg-surface-container-lowest rounded-xl p-lg flex flex-col gap-md sticky top-[104px]">
<h2 className="font-headline-md text-headline-md text-primary font-medium tracking-tight">Refund Summary</h2>
<div className="bg-surface-container-low rounded-lg p-md border border-primary/5">
<span className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider block mb-1">Refunded This Month</span>
<span className="font-display-lg text-display-lg text-primary block tracking-tighter">$480</span>
</div>
<div className="flex flex-col gap-2 mt-sm">
<div className="flex justify-between items-center">
<span className="font-body-sm text-body-sm text-on-surface-variant">Pending refunds</span>
<span className="font-label-lg text-label-lg text-primary">3</span>
</div>

<div className="w-full h-1.5 bg-surface-variant rounded-full overflow-hidden">
<div className="h-full bg-[#8F9B8F] w-[15%] rounded-full"></div>
</div>
<span className="font-label-sm text-label-sm text-on-surface-variant text-right mt-1">~ $320 Est. Value</span>
</div>
<div className="mt-md pt-md border-t border-primary/5 flex flex-col gap-3">
<button className="w-full h-12 rounded-full border border-primary text-primary font-label-lg text-label-lg uppercase tracking-wider hover:bg-surface-variant/50 transition-colors">
                                    Export CSV
                                </button>
</div>
</div>
</div>
</div>
</div>

<div className="h-xxl"></div>
</div>
</main>
  );
}