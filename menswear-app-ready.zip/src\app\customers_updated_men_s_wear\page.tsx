export default function CustomersUpdatedMenSWear() {
  return (
    <main className="flex-1 md:ml-64 flex flex-col min-h-screen pb-xxl">

<header className="bg-surface dark:bg-surface-dim flex justify-between items-center px-margin-desktop w-full border-b border-primary/5 h-16 sticky top-0 z-10">
<div className="flex items-center flex-1">

<div className="relative w-full max-w-md hidden md:block">
<span className="material-symbols-outlined absolute left-sm top-1/2 transform -translate-y-1/2 text-outline">search</span>
<input className="w-full pl-xl pr-md py-sm rounded-lg bg-surface-container-lowest border border-outline-variant/30 focus:border-secondary focus:ring-0 font-body-sm text-body-sm shadow-elevation-2 transition-shadow placeholder:text-outline/50" placeholder="Search name or email" type="text" />
</div>
</div>
<div className="flex items-center space-x-md">
<button className="text-on-surface-variant hover:text-primary transition-colors">
<span className="material-symbols-outlined">notifications</span>
</button>
<div className="w-8 h-8 rounded-full bg-surface-container-high overflow-hidden border border-outline-variant/20">
<img alt="Administrator profile photo" className="w-full h-full object-cover" data-alt="A detailed, high-resolution headshot of a professional male model in a tailored suit, representing a premium menswear brand administrator profile photo. The lighting is soft and flattering, creating a sophisticated light-mode aesthetic with neutral backgrounds." src="https://lh3.googleusercontent.com/aida-public/AB6AXuBfxHKrM-HJOqV1CMCi1GsdzG6JIJttNnC8lOVbtHxG8PoPgbnoVydiS2hjmGkLlEVTolEbKHRYDa5O42-M_vSPIQwJ0d4-JfbLGg28Y2FqZpFKYwZFgpITs9a1wCsUdGtBvnDpH0rXZj8D9M51_mT6QThWiclnCi067prb465Uc2bpBPEIcN9FhajGK9gO94Azm6LfpwKWzWAYiEZIrgTkh8RfLQ9Ve8-Qwzmou3TcnGI0zyeTf578" />
</div>
</div>
</header>
<div className="px-margin-mobile md:px-margin-desktop pt-xl">

<div className="mb-lg">
<h2 className="font-display-lg text-display-lg text-primary">CUSTOMERS</h2>
</div>

<div className="relative w-full mb-lg md:hidden">
<span className="material-symbols-outlined absolute left-sm top-1/2 transform -translate-y-1/2 text-outline">search</span>
<input className="w-full pl-xl pr-md py-sm rounded-lg bg-surface-container-lowest border border-outline-variant/30 focus:border-secondary focus:ring-0 font-body-sm text-body-sm shadow-elevation-2 transition-shadow placeholder:text-outline/50" placeholder="Search name or email" type="text" />
</div>

<div className="flex flex-wrap gap-sm mb-lg">
<button className="px-md py-sm rounded-full bg-secondary text-on-secondary font-label-sm text-label-sm flex items-center space-x-2 transition-colors">
<span className="">All</span>
<span className="bg-surface-container-lowest/20 px-2 py-0.5 rounded-full text-xs">89</span>
</button>
<button className="px-md py-sm rounded-full bg-surface-container-lowest text-on-surface border border-outline-variant/30 font-label-sm text-label-sm flex items-center space-x-2 hover:bg-surface-container-low transition-colors">
<span className="">New This Month</span>
<span className="bg-surface-container-high px-2 py-0.5 rounded-full text-xs">12</span>
</button>
<button className="px-md py-sm rounded-full bg-surface-container-lowest text-on-surface border border-outline-variant/30 font-label-sm text-label-sm flex items-center space-x-2 hover:bg-surface-container-low transition-colors">
<span className="">Repeat</span>
<span className="bg-surface-container-high px-2 py-0.5 rounded-full text-xs">34</span>
</button>
<button className="px-md py-sm rounded-full bg-surface-container-lowest text-on-surface border border-outline-variant/30 font-label-sm text-label-sm flex items-center space-x-2 hover:bg-surface-container-low transition-colors">
<span className="">Blocked</span>
<span className="bg-surface-container-high px-2 py-0.5 rounded-full text-xs">2</span>
</button>
</div>

<div className="bg-surface-container-lowest rounded-[24px] border border-outline-variant/20 mb-xl">
<div className="overflow-x-auto w-full">
<table className="w-full text-left font-body-sm text-body-sm">
<thead className="bg-surface-container-low border-b border-primary/5">
<tr>
<th className="py-md px-lg font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider">Customer</th>
<th className="py-md px-lg font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider hidden sm:table-cell">Email</th>
<th className="py-md px-lg font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider hidden lg:table-cell">Phone</th>
<th className="py-md px-lg font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider text-right hidden md:table-cell">Orders</th>
<th className="py-md px-lg font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider text-right">Total Spent</th>
<th className="py-md px-lg font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider hidden xl:table-cell">Joined</th>
<th className="py-md px-lg font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider text-center">Status</th>
<th className="py-md px-lg font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider text-right">Actions</th>
</tr>
</thead>
<tbody className="divide-y divide-primary/5">

<tr className="hover:bg-surface-container-low transition-colors group">
<td className="py-md px-lg">
<div className="flex items-center space-x-md">
<div className="w-10 h-10 rounded-full bg-surface-container-high flex items-center justify-center text-primary font-headline-md text-headline-md">JH</div>
<div className="font-medium text-primary">James Harrison</div>
</div>
</td>
<td className="py-md px-lg text-on-surface-variant hidden sm:table-cell">james.h@example.com</td>
<td className="py-md px-lg text-on-surface-variant hidden lg:table-cell whitespace-nowrap">+1 (555) 019-2834</td>
<td className="py-md px-lg text-right hidden md:table-cell">14</td>
<td className="py-md px-lg text-right font-medium">$4,250.00</td>
<td className="py-md px-lg text-on-surface-variant hidden xl:table-cell">Aug 12, 2026</td>
<td className="py-md px-lg text-center">
<span className="inline-flex items-center px-2 py-1 rounded-full bg-secondary-fixed text-on-secondary-fixed font-label-sm text-[10px] uppercase tracking-wider">Active</span>
</td>
<td className="py-md px-lg text-right">
<div className="flex items-center justify-end space-x-sm transition-opacity">
<button className="p-1 text-on-surface-variant hover:text-primary transition-colors" title="View">
<span className="material-symbols-outlined text-[20px]">visibility</span>
</button>
<button className="p-1 text-on-surface-variant hover:text-error transition-colors" title="Block">
<span className="material-symbols-outlined text-[20px]">block</span>
</button>
</div>
</td>
</tr>

<tr className="hover:bg-surface-container-low transition-colors group">
<td className="py-md px-lg">
<div className="flex items-center space-x-md">
<div className="w-10 h-10 rounded-full bg-surface-container-high flex items-center justify-center text-primary font-headline-md text-headline-md">MC</div>
<div className="font-medium text-primary">Michael Chen</div>
</div>
</td>
<td className="py-md px-lg text-on-surface-variant hidden sm:table-cell">m.chen@example.com</td>
<td className="py-md px-lg text-on-surface-variant hidden lg:table-cell whitespace-nowrap">+1 (555) 837-9921</td>
<td className="py-md px-lg text-right hidden md:table-cell">8</td>
<td className="py-md px-lg text-right font-medium">$1,890.50</td>
<td className="py-md px-lg text-on-surface-variant hidden xl:table-cell">Aug 05, 2026</td>
<td className="py-md px-lg text-center">
<span className="inline-flex items-center px-2 py-1 rounded-full bg-secondary-fixed text-on-secondary-fixed font-label-sm text-[10px] uppercase tracking-wider">Active</span>
</td>
<td className="py-md px-lg text-right">
<div className="flex items-center justify-end space-x-sm transition-opacity">
<button className="p-1 text-on-surface-variant hover:text-primary transition-colors" title="View">
<span className="material-symbols-outlined text-[20px]">visibility</span>
</button>
<button className="p-1 text-on-surface-variant hover:text-error transition-colors" title="Block">
<span className="material-symbols-outlined text-[20px]">block</span>
</button>
</div>
</td>
</tr>

<tr className="hover:bg-surface-container-low transition-colors group">
<td className="py-md px-lg">
<div className="flex items-center space-x-md">
<div className="w-10 h-10 rounded-full bg-surface-container-high flex items-center justify-center text-primary font-headline-md text-headline-md">RF</div>
<div className="font-medium text-primary">Robert Foster</div>
</div>
</td>
<td className="py-md px-lg text-on-surface-variant hidden sm:table-cell">rfoster@example.com</td>
<td className="py-md px-lg text-on-surface-variant hidden lg:table-cell whitespace-nowrap">+1 (555) 231-4456</td>
<td className="py-md px-lg text-right hidden md:table-cell">2</td>
<td className="py-md px-lg text-right font-medium">$450.00</td>
<td className="py-md px-lg text-on-surface-variant hidden xl:table-cell">Aug 02, 2026</td>
<td className="py-md px-lg text-center">
<span className="inline-flex items-center px-2 py-1 rounded-full bg-error-container text-on-error-container font-label-sm text-[10px] uppercase tracking-wider">Blocked</span>
</td>
<td className="py-md px-lg text-right">
<div className="flex items-center justify-end space-x-sm transition-opacity">
<button className="p-1 text-on-surface-variant hover:text-primary transition-colors" title="View">
<span className="material-symbols-outlined text-[20px]">visibility</span>
</button>
<button className="p-1 text-error hover:text-error transition-colors" title="Unblock">
<span className="material-symbols-outlined text-[20px]">check_circle</span>
</button>
</div>
</td>
</tr>

<tr className="hover:bg-surface-container-low transition-colors group">
<td className="py-md px-lg">
<div className="flex items-center space-x-md">
<div className="w-10 h-10 rounded-full bg-surface-container-high flex items-center justify-center text-primary font-headline-md text-headline-md">WD</div>
<div className="font-medium text-primary">William Davis</div>
</div>
</td>
<td className="py-md px-lg text-on-surface-variant hidden sm:table-cell">will.d@example.com</td>
<td className="py-md px-lg text-on-surface-variant hidden lg:table-cell whitespace-nowrap">+1 (555) 778-1122</td>
<td className="py-md px-lg text-right hidden md:table-cell">5</td>
<td className="py-md px-lg text-right font-medium">$1,205.75</td>
<td className="py-md px-lg text-on-surface-variant hidden xl:table-cell">Aug 01, 2026</td>
<td className="py-md px-lg text-center">
<span className="inline-flex items-center px-2 py-1 rounded-full bg-secondary-fixed text-on-secondary-fixed font-label-sm text-[10px] uppercase tracking-wider">Active</span>
</td>
<td className="py-md px-lg text-right">
<div className="flex items-center justify-end space-x-sm transition-opacity">
<button className="p-1 text-on-surface-variant hover:text-primary transition-colors" title="View">
<span className="material-symbols-outlined text-[20px]">visibility</span>
</button>
<button className="p-1 text-on-surface-variant hover:text-error transition-colors" title="Block">
<span className="material-symbols-outlined text-[20px]">block</span>
</button>
</div>
</td>
</tr>

<tr className="hover:bg-surface-container-low transition-colors group">
<td className="py-md px-lg">
<div className="flex items-center space-x-md">
<div className="w-10 h-10 rounded-full bg-surface-container-high flex items-center justify-center text-primary font-headline-md text-headline-md">TW</div>
<div className="font-medium text-primary">Thomas Wright</div>
</div>
</td>
<td className="py-md px-lg text-on-surface-variant hidden sm:table-cell">twright@example.com</td>
<td className="py-md px-lg text-on-surface-variant hidden lg:table-cell whitespace-nowrap">+1 (555) 901-3344</td>
<td className="py-md px-lg text-right hidden md:table-cell">1</td>
<td className="py-md px-lg text-right font-medium">$125.00</td>
<td className="py-md px-lg text-on-surface-variant hidden xl:table-cell">Aug 01, 2026</td>
<td className="py-md px-lg text-center">
<span className="inline-flex items-center px-2 py-1 rounded-full bg-secondary-fixed text-on-secondary-fixed font-label-sm text-[10px] uppercase tracking-wider">Active</span>
</td>
<td className="py-md px-lg text-right">
<div className="flex items-center justify-end space-x-sm transition-opacity">
<button className="p-1 text-on-surface-variant hover:text-primary transition-colors" title="View">
<span className="material-symbols-outlined text-[20px]">visibility</span>
</button>
<button className="p-1 text-on-surface-variant hover:text-error transition-colors" title="Block">
<span className="material-symbols-outlined text-[20px]">block</span>
</button>
</div>
</td>
</tr>

<tr className="hover:bg-surface-container-low transition-colors group">
<td className="py-md px-lg">
<div className="flex items-center space-x-md">
<div className="w-10 h-10 rounded-full bg-surface-container-high flex items-center justify-center text-primary font-headline-md text-headline-md">DM</div>
<div className="font-medium text-primary">David Miller</div>
</div>
</td>
<td className="py-md px-lg text-on-surface-variant hidden sm:table-cell">david.m@example.com</td>
<td className="py-md px-lg text-on-surface-variant hidden lg:table-cell whitespace-nowrap">+1 (555) 654-0987</td>
<td className="py-md px-lg text-right hidden md:table-cell">22</td>
<td className="py-md px-lg text-right font-medium">$8,900.00</td>
<td className="py-md px-lg text-on-surface-variant hidden xl:table-cell">Aug 01, 2026</td>
<td className="py-md px-lg text-center">
<span className="inline-flex items-center px-2 py-1 rounded-full bg-secondary-fixed text-on-secondary-fixed font-label-sm text-[10px] uppercase tracking-wider">Active</span>
</td>
<td className="py-md px-lg text-right">
<div className="flex items-center justify-end space-x-sm transition-opacity">
<button className="p-1 text-on-surface-variant hover:text-primary transition-colors" title="View">
<span className="material-symbols-outlined text-[20px]">visibility</span>
</button>
<button className="p-1 text-on-surface-variant hover:text-error transition-colors" title="Block">
<span className="material-symbols-outlined text-[20px]">block</span>
</button>
</div>
</td>
</tr>
</tbody>
</table>
</div>
</div>

<div className="flex flex-col sm:flex-row justify-between items-center gap-md w-full">

<div className="flex items-center space-x-unit">
<button className="w-10 h-10 flex items-center justify-center rounded-full border border-outline-variant/30 text-on-surface hover:bg-surface-container-low transition-colors disabled:opacity-50" disabled={true}>
<span className="material-symbols-outlined text-[20px]">chevron_left</span>
</button>
<button className="w-10 h-10 flex items-center justify-center rounded-full bg-primary text-on-primary font-label-sm">1</button>
<button className="w-10 h-10 flex items-center justify-center rounded-full border border-outline-variant/30 text-on-surface hover:bg-surface-container-low transition-colors font-label-sm">2</button>
<button className="w-10 h-10 flex items-center justify-center rounded-full border border-outline-variant/30 text-on-surface hover:bg-surface-container-low transition-colors font-label-sm">3</button>
<span className="text-outline mx-unit">...</span>
<button className="w-10 h-10 flex items-center justify-center rounded-full border border-outline-variant/30 text-on-surface hover:bg-surface-container-low transition-colors font-label-sm">8</button>
<button className="w-10 h-10 flex items-center justify-center rounded-full border border-outline-variant/30 text-on-surface hover:bg-surface-container-low transition-colors">
<span className="material-symbols-outlined text-[20px]">chevron_right</span>
</button>
</div>

<button className="px-lg h-12 rounded-full border border-primary text-primary font-label-lg hover:bg-surface-container-low transition-colors flex items-center justify-center w-full sm:w-auto">
                    Export CSV
                </button>
</div>
</div>
</main>
  );
}