export default function CouponsManagementMenSWear() {
  return (
    <main className="flex-1 flex flex-col h-screen overflow-hidden bg-background">

<header className="h-16 w-full px-margin-mobile md:px-margin-desktop bg-surface flex justify-between items-center flex-shrink-0 z-10 sticky top-0 border-b border-surface-dim">
<div className="flex items-center md:hidden">
<button className="p-2 text-primary hover:bg-surface-container-high rounded-full transition-colors">
<span className="material-symbols-outlined">menu</span>
</button>
<span className="ml-3 font-headline-md text-headline-md text-primary font-bold">MEN'S WEAR</span>
</div>
<div className="flex-1 max-w-md hidden md:flex items-center bg-surface-container-low rounded-full px-4 py-2 focus-within:ring-1 focus-within:ring-outline-variant transition-all">
<span className="material-symbols-outlined text-on-surface-variant mr-2">search</span>
<input className="bg-transparent border-none outline-none text-body-md w-full text-on-surface placeholder-on-surface-variant/50 focus:ring-0 p-0" placeholder="Search..." type="text" />
</div>
<div className="flex items-center space-x-4">
<button className="p-2 text-on-surface-variant hover:bg-surface-container-high rounded-full transition-colors relative">
<span className="material-symbols-outlined">notifications</span>
<span className="absolute top-1 right-1 w-2 h-2 bg-error rounded-full"></span>
</button>
</div>
</header>

<div className="flex-1 overflow-y-auto custom-scrollbar p-margin-mobile md:p-margin-desktop pb-xxl">
<div className="max-w-container-max mx-auto space-y-xxl">

<div className="flex flex-col md:flex-row md:items-end justify-between space-y-6 md:space-y-0">
<div>
<h2 className="font-headline-lg text-headline-lg text-primary">COUPONS</h2>
<div className="flex flex-wrap gap-3 mt-6">
<button className="px-4 py-1.5 rounded-full font-label-lg text-label-lg bg-primary text-on-primary transition-colors">All 12</button>
<button className="px-4 py-1.5 rounded-full font-label-lg text-label-lg bg-surface-container hover:bg-surface-container-high text-on-surface transition-colors">Active 8</button>
<button className="px-4 py-1.5 rounded-full font-label-lg text-label-lg bg-surface-container hover:bg-surface-container-high text-on-surface transition-colors">Expired 3</button>
<button className="px-4 py-1.5 rounded-full font-label-lg text-label-lg bg-surface-container hover:bg-surface-container-high text-on-surface transition-colors">Scheduled 1</button>
</div>
</div>
<button className="h-14 px-8 rounded-full bg-primary text-on-primary font-label-lg text-label-lg flex items-center justify-center hover:bg-primary/90 transition-colors shrink-0">
                        CREATE COUPON <span className="material-symbols-outlined ml-2 text-sm">arrow_forward</span>
</button>
</div>

<div className="bg-surface-container-lowest rounded-card overflow-hidden">
<div className="overflow-x-auto custom-scrollbar">
<table className="w-full text-left border-collapse">
<thead>
<tr className="border-b border-surface-dim/30">
<th className="py-4 px-lg font-label-lg text-label-lg text-on-surface-variant font-medium tracking-wider uppercase">Code</th>
<th className="py-4 px-lg font-label-lg text-label-lg text-on-surface-variant font-medium tracking-wider uppercase">Type</th>
<th className="py-4 px-lg font-label-lg text-label-lg text-on-surface-variant font-medium tracking-wider uppercase">Value</th>
<th className="py-4 px-lg font-label-lg text-label-lg text-on-surface-variant font-medium tracking-wider uppercase">Min Order</th>
<th className="py-4 px-lg font-label-lg text-label-lg text-on-surface-variant font-medium tracking-wider uppercase">Usage</th>
<th className="py-4 px-lg font-label-lg text-label-lg text-on-surface-variant font-medium tracking-wider uppercase">Expiry</th>
<th className="py-4 px-lg font-label-lg text-label-lg text-on-surface-variant font-medium tracking-wider uppercase">Status</th>
<th className="py-4 px-lg font-label-lg text-label-lg text-on-surface-variant font-medium tracking-wider uppercase text-right">Actions</th>
</tr>
</thead>
<tbody className="divide-y divide-surface-dim/20 font-body-sm text-body-sm">
<tr className="hover:bg-surface-container-low transition-colors group">
<td className="py-4 px-lg"><span className="bg-surface-container px-2 py-1 rounded font-mono text-xs text-primary">WELCOME10</span></td>
<td className="py-4 px-lg text-on-surface">Percentage</td>
<td className="py-4 px-lg font-medium">10%</td>
<td className="py-4 px-lg text-on-surface-variant">$0</td>
<td className="py-4 px-lg text-on-surface-variant">45/100</td>
<td className="py-4 px-lg text-on-surface-variant">Dec 31, 2026</td>
<td className="py-4 px-lg">
<div className="w-10 h-6 bg-sage-green rounded-full relative cursor-pointer">
<div className="absolute right-1 top-1 w-4 h-4 bg-white rounded-full shadow-sm"></div>
</div>
</td>
<td className="py-4 px-lg text-right group-hover:opacity-100 transition-opacity">
<button className="text-on-surface-variant hover:text-primary p-1"><span className="material-symbols-outlined text-[20px]">edit</span></button>
<button className="text-on-surface-variant hover:text-error p-1 ml-2"><span className="material-symbols-outlined text-[20px]">delete</span></button>
</td>
</tr>
<tr className="hover:bg-surface-container-low transition-colors group">
<td className="py-4 px-lg"><span className="bg-surface-container px-2 py-1 rounded font-mono text-xs text-primary">FREESHIP</span></td>
<td className="py-4 px-lg text-on-surface">Free Shipping</td>
<td className="py-4 px-lg font-medium">FREE</td>
<td className="py-4 px-lg text-on-surface-variant">$150</td>
<td className="py-4 px-lg text-on-surface-variant">120/∞</td>
<td className="py-4 px-lg text-on-surface-variant">Aug 30, 2026</td>
<td className="py-4 px-lg">
<div className="w-10 h-6 bg-sage-green rounded-full relative cursor-pointer">
<div className="absolute right-1 top-1 w-4 h-4 bg-white rounded-full shadow-sm"></div>
</div>
</td>
<td className="py-4 px-lg text-right group-hover:opacity-100 transition-opacity">
<button className="text-on-surface-variant hover:text-primary p-1"><span className="material-symbols-outlined text-[20px]">edit</span></button>
<button className="text-on-surface-variant hover:text-error p-1 ml-2"><span className="material-symbols-outlined text-[20px]">delete</span></button>
</td>
</tr>
<tr className="hover:bg-surface-container-low transition-colors group">
<td className="py-4 px-lg"><span className="bg-surface-container px-2 py-1 rounded font-mono text-xs text-primary">ARUN20</span></td>
<td className="py-4 px-lg text-on-surface">Fixed Amount</td>
<td className="py-4 px-lg font-medium">$20</td>
<td className="py-4 px-lg text-on-surface-variant">$100</td>
<td className="py-4 px-lg text-on-surface-variant">12/50</td>
<td className="py-4 px-lg text-on-surface-variant">Nov 15, 2026</td>
<td className="py-4 px-lg">
<div className="w-10 h-6 bg-surface-dim rounded-full relative cursor-pointer">
<div className="absolute left-1 top-1 w-4 h-4 bg-white rounded-full shadow-sm"></div>
</div>
</td>
<td className="py-4 px-lg text-right group-hover:opacity-100 transition-opacity">
<button className="text-on-surface-variant hover:text-primary p-1"><span className="material-symbols-outlined text-[20px]">edit</span></button>
<button className="text-on-surface-variant hover:text-error p-1 ml-2"><span className="material-symbols-outlined text-[20px]">delete</span></button>
</td>
</tr>
</tbody>
</table>
</div>
</div>

<div className="bg-surface-container-lowest rounded-card p-lg border border-surface-dim/30">
<h3 className="font-headline-md text-headline-md text-primary mb-8 border-b border-surface-dim pb-4">Create New Coupon</h3>
<form className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
<div className="flex flex-col">
<label className="font-label-lg text-label-lg uppercase tracking-wider text-on-surface-variant mb-2">Code</label>
<input className="h-12 px-4 rounded-lg bg-surface border border-outline-variant/30 focus:border-sage-green focus:ring-1 focus:ring-sage-green outline-none transition-colors font-mono text-body-md" placeholder="e.g. SUMMER25" type="text" />
</div>
<div className="flex flex-col">
<label className="font-label-lg text-label-lg uppercase tracking-wider text-on-surface-variant mb-2">Type</label>
<div className="relative">
<select className="h-12 w-full px-4 appearance-none rounded-lg bg-surface border border-outline-variant/30 focus:border-sage-green focus:ring-1 focus:ring-sage-green outline-none transition-colors text-body-md cursor-pointer">
<option>Percentage</option>
<option>Fixed Amount</option>
<option>Free Shipping</option>
</select>
<span className="material-symbols-outlined absolute right-4 top-3 pointer-events-none text-on-surface-variant">expand_more</span>
</div>
</div>
<div className="flex flex-col">
<label className="font-label-lg text-label-lg uppercase tracking-wider text-on-surface-variant mb-2">Value</label>
<input className="h-12 px-4 rounded-lg bg-surface border border-outline-variant/30 focus:border-sage-green focus:ring-1 focus:ring-sage-green outline-none transition-colors text-body-md" placeholder="0" type="number" />
</div>
<div className="flex flex-col">
<label className="font-label-lg text-label-lg uppercase tracking-wider text-on-surface-variant mb-2">Min Order Amount</label>
<div className="relative">
<span className="absolute left-4 top-3 text-on-surface-variant">$</span>
<input className="h-12 pl-8 pr-4 w-full rounded-lg bg-surface border border-outline-variant/30 focus:border-sage-green focus:ring-1 focus:ring-sage-green outline-none transition-colors text-body-md" placeholder="0.00" type="number" />
</div>
</div>
<div className="flex flex-col">
<label className="font-label-lg text-label-lg uppercase tracking-wider text-on-surface-variant mb-2">Usage Limit (Per User)</label>
<input className="h-12 px-4 rounded-lg bg-surface border border-outline-variant/30 focus:border-sage-green focus:ring-1 focus:ring-sage-green outline-none transition-colors text-body-md" placeholder="Leave blank for unlimited" type="number" />
</div>
<div className="flex flex-col">
<label className="font-label-lg text-label-lg uppercase tracking-wider text-on-surface-variant mb-2">Expiry Date</label>
<div className="relative">
<input className="h-12 w-full px-4 appearance-none rounded-lg bg-surface border border-outline-variant/30 focus:border-sage-green focus:ring-1 focus:ring-sage-green outline-none transition-colors text-body-md text-on-surface-variant cursor-pointer" type="date" />
</div>
</div>
<div className="md:col-span-2 flex flex-col mt-4">
<label className="font-label-lg text-label-lg uppercase tracking-wider text-on-surface-variant mb-4">Apply To</label>
<div className="flex gap-4">
<label className="cursor-pointer group flex items-center">
<input defaultChecked={true} className="peer sr-only" name="applyTo" type="radio" />
<div className="px-6 py-2 rounded-full border border-outline-variant/30 peer-checked:bg-primary peer-checked:text-on-primary peer-checked:border-primary transition-colors font-label-lg text-label-lg text-on-surface-variant group-hover:bg-surface-container">
                                        All Products
                                    </div>
</label>
<label className="cursor-pointer group flex items-center">
<input className="peer sr-only" name="applyTo" type="radio" />
<div className="px-6 py-2 rounded-full border border-outline-variant/30 peer-checked:bg-primary peer-checked:text-on-primary peer-checked:border-primary transition-colors font-label-lg text-label-lg text-on-surface-variant group-hover:bg-surface-container">
                                        Category
                                    </div>
</label>
<label className="cursor-pointer group flex items-center">
<input className="peer sr-only" name="applyTo" type="radio" />
<div className="px-6 py-2 rounded-full border border-outline-variant/30 peer-checked:bg-primary peer-checked:text-on-primary peer-checked:border-primary transition-colors font-label-lg text-label-lg text-on-surface-variant group-hover:bg-surface-container">
                                        Specific Products
                                    </div>
</label>
</div>
</div>
<div className="md:col-span-2 flex justify-end mt-8 border-t border-surface-dim pt-6">
<button className="h-14 px-10 rounded-full bg-primary text-on-primary font-label-lg text-label-lg flex items-center justify-center hover:bg-primary/90 transition-colors" type="button" data-verified="true">
                                SAVE COUPON
                            </button>
</div>
</form>
</div>
</div>
</div>
</main>
  );
}