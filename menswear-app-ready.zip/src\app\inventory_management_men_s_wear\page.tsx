export default function InventoryManagementMenSWear() {
  return (
    <main className="flex-1 overflow-y-auto px-margin-desktop py-xl">

<div className="flex justify-between items-end mb-lg">
<div>
<h2 className="font-display-lg text-display-lg text-primary tracking-tight">INVENTORY</h2>
</div>
<button className="h-12 px-6 rounded-full border border-primary text-primary font-label-lg text-label-lg hover:bg-surface-container-low transition-colors flex items-center gap-sm">
<span className="material-symbols-outlined text-[18px]">download</span>
                    Export CSV
                </button>
</div>

<div className="flex flex-wrap justify-between items-center gap-lg mb-xl pb-md border-b border-primary/5">

<div className="flex gap-sm">
<button className="px-4 py-2 rounded-full bg-secondary text-on-secondary font-label-lg text-label-lg">All</button>
<button className="px-4 py-2 rounded-full bg-surface-container-lowest border border-outline-variant/50 text-on-surface-variant hover:bg-surface-container-low transition-colors font-label-lg text-label-lg">In Stock</button>
<button className="px-4 py-2 rounded-full bg-surface-container-lowest border border-outline-variant/50 text-on-surface-variant hover:bg-surface-container-low transition-colors font-label-lg text-label-lg">Low Stock</button>
<button className="px-4 py-2 rounded-full bg-surface-container-lowest border border-outline-variant/50 text-on-surface-variant hover:bg-surface-container-low transition-colors font-label-lg text-label-lg">Out of Stock</button>
</div>

<div className="flex gap-sm">
<div className="bg-surface-container-lowest border border-outline-variant/20 px-3 py-1.5 rounded-lg flex items-center gap-2">
<span className="w-2 h-2 rounded-full bg-primary"></span>
<span className="font-label-sm text-label-sm text-on-surface-variant">Total SKUs: <strong className="text-primary">240</strong></span>
</div>
<div className="bg-secondary-fixed/50 border border-secondary/20 px-3 py-1.5 rounded-lg flex items-center gap-2">
<span className="w-2 h-2 rounded-full bg-secondary"></span>
<span className="font-label-sm text-label-sm text-on-secondary-container">Low Stock: <strong>12</strong></span>
</div>
<div className="bg-error-container/30 border border-error/20 px-3 py-1.5 rounded-lg flex items-center gap-2">
<span className="w-2 h-2 rounded-full bg-error"></span>
<span className="font-label-sm text-label-sm text-error">Out of Stock: <strong>4</strong></span>
</div>
</div>
</div>

<div className="grid grid-cols-12 gap-gutter">

<div className="col-span-12 lg:col-span-9 flex flex-col gap-md">
<div className="bg-surface-container-lowest rounded-xl shadow-[0px_4px_20px_rgba(20,20,20,0.02)] overflow-hidden">
<table className="w-full text-left border-collapse">
<thead>
<tr className="border-b border-outline-variant/20">
<th className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider py-4 pl-6 pr-4">Product</th>
<th className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider py-4 px-4">SKU</th>
<th className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider py-4 px-4">Size</th>
<th className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider py-4 px-4">Stock</th>
<th className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider py-4 px-4">Status</th>
<th className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider py-4 pr-6 pl-4 text-right">Updated</th>
</tr>
</thead>
<tbody className="font-body-sm text-body-sm text-on-surface">


<tr className="group hover:bg-surface-container-lowest/50 transition-colors">
<td className="py-4 pl-6 pr-4 flex items-center gap-md">
<div className="w-12 h-16 bg-surface-container-low rounded border border-outline-variant/20 overflow-hidden flex-shrink-0">
<img className="w-full h-full object-cover" data-alt="A pristine, highly detailed studio shot of a classic white men's Oxford cotton shirt, perfectly folded and lit with soft, high-key lighting to emphasize texture and modern minimalist tailoring." src="https://lh3.googleusercontent.com/aida-public/AB6AXuARgV97nA2BjWm6GwVFWh1puQPoRav-BYCHle8ErIk5zopOF7iKivb4VfRIkpBhhVsi0QCRjPZF8mw9__U9jgjZhsKEF8dZWRihIKWmP-rkrgrpnK88HRTMYbDjy4OZo2EGibrD9U08RceJljmSEWfuu7cI5oCS0IyxV5ysZlkVN-mZhH7ruoo2dsBAdPY0FQ49NhlRuPL6sVmxFdH-iNtImmFn5hwLfOLLcP4KzfjiZWoUwd5oAi91" />
</div>
<div>
<div className="font-label-lg text-label-lg text-primary">Oxford Cotton Shirt</div>
<div className="text-on-surface-variant text-[13px] mt-0.5">White / Classic Fit</div>
</div>
</td>
<td className="py-4 px-4 text-on-surface-variant">OXF-WHT-001</td>
<td className="py-4 px-4 font-label-sm text-label-sm">S</td>
<td className="py-4 px-4">
<div className="flex items-center gap-2">
<button className="w-6 h-6 rounded-full border border-outline-variant/50 flex items-center justify-center text-on-surface-variant hover:border-primary hover:text-primary transition-colors"><span className="material-symbols-outlined text-[14px]">remove</span></button>
<span className="w-6 text-center font-body-md">24</span>
<button className="w-6 h-6 rounded-full border border-outline-variant/50 flex items-center justify-center text-on-surface-variant hover:border-primary hover:text-primary transition-colors"><span className="material-symbols-outlined text-[14px]">add</span></button>
</div>
</td>
<td className="py-4 px-4">
<span className="px-2.5 py-1 rounded-full bg-surface-container-low text-on-surface font-label-sm text-[11px] tracking-wider uppercase">In Stock</span>
</td>
<td className="py-4 pr-6 pl-4 text-right text-on-surface-variant text-[13px]">Aug 14, 2026, 09:41 AM</td>
</tr>

<tr className="bg-secondary-fixed/20 border-l-[3px] border-secondary group hover:bg-secondary-fixed/30 transition-colors">
<td className="py-3 pl-6 pr-4 flex items-center gap-md">
<div className="w-12 flex-shrink-0"></div> 
</td>
<td className="py-3 px-4 text-on-surface-variant">OXF-WHT-002</td>
<td className="py-3 px-4 font-label-sm text-label-sm">M</td>
<td className="py-3 px-4">
<div className="flex items-center gap-2">
<button className="w-6 h-6 rounded-full border border-outline-variant/50 flex items-center justify-center text-on-surface-variant hover:border-primary hover:text-primary transition-colors"><span className="material-symbols-outlined text-[14px]">remove</span></button>
<span className="w-6 text-center font-body-md text-on-secondary-container font-medium">4</span>
<button className="w-6 h-6 rounded-full border border-outline-variant/50 flex items-center justify-center text-on-surface-variant hover:border-primary hover:text-primary transition-colors"><span className="material-symbols-outlined text-[14px]">add</span></button>
</div>
</td>
<td className="py-3 px-4">
<span className="px-2.5 py-1 rounded-full bg-secondary-container/50 text-on-secondary-container font-label-sm text-[11px] tracking-wider uppercase">Low Stock</span>
</td>
<td className="py-3 pr-6 pl-4 text-right text-on-surface-variant text-[13px]">Aug 13, 2026</td>
</tr>

<tr className="group hover:bg-surface-container-lowest/50 transition-colors border-b border-outline-variant/10">
<td className="py-3 pl-6 pr-4 flex items-center gap-md">
<div className="w-12 flex-shrink-0"></div>
</td>
<td className="py-3 px-4 text-on-surface-variant">OXF-WHT-003</td>
<td className="py-3 px-4 font-label-sm text-label-sm">L</td>
<td className="py-3 px-4">
<div className="flex items-center gap-2">
<button className="w-6 h-6 rounded-full border border-outline-variant/50 flex items-center justify-center text-on-surface-variant hover:border-primary hover:text-primary transition-colors"><span className="material-symbols-outlined text-[14px]">remove</span></button>
<span className="w-6 text-center font-body-md">18</span>
<button className="w-6 h-6 rounded-full border border-outline-variant/50 flex items-center justify-center text-on-surface-variant hover:border-primary hover:text-primary transition-colors"><span className="material-symbols-outlined text-[14px]">add</span></button>
</div>
</td>
<td className="py-3 px-4">
<span className="px-2.5 py-1 rounded-full bg-surface-container-low text-on-surface font-label-sm text-[11px] tracking-wider uppercase">In Stock</span>
</td>
<td className="py-3 pr-6 pl-4 text-right text-on-surface-variant text-[13px]">Aug 12, 2026</td>
</tr>

<tr className="bg-surface-container-high/50 border-l-[3px] border-error group hover:bg-surface-container-high/70 transition-colors border-b border-outline-variant/20">
<td className="py-3 pl-6 pr-4 flex items-center gap-md opacity-60">
<div className="w-12 flex-shrink-0"></div>
</td>
<td className="py-3 px-4 text-on-surface-variant opacity-60">OXF-WHT-004</td>
<td className="py-3 px-4 font-label-sm text-label-sm opacity-60">XL</td>
<td className="py-3 px-4">
<div className="flex items-center gap-2">
<button className="w-6 h-6 rounded-full border border-outline-variant/30 flex items-center justify-center text-on-surface-variant opacity-50 cursor-not-allowed"><span className="material-symbols-outlined text-[14px]">remove</span></button>
<span className="w-6 text-center font-body-md text-error font-medium">0</span>
<button className="w-6 h-6 rounded-full border border-outline-variant/50 flex items-center justify-center text-on-surface-variant hover:border-primary hover:text-primary transition-colors"><span className="material-symbols-outlined text-[14px]">add</span></button>
</div>
</td>
<td className="py-3 px-4">
<span className="px-2.5 py-1 rounded-full bg-error-container/30 text-error font-label-sm text-[11px] tracking-wider uppercase">Out of Stock</span>
</td>
<td className="py-3 pr-6 pl-4 text-right text-on-surface-variant text-[13px] opacity-60">Aug 10, 2026</td>
</tr>

<tr className="group hover:bg-surface-container-lowest/50 transition-colors">
<td className="py-4 pl-6 pr-4 flex items-center gap-md">
<div className="w-12 h-16 bg-surface-container-low rounded border border-outline-variant/20 overflow-hidden flex-shrink-0">
<img className="w-full h-full object-cover" data-alt="A highly detailed close-up of premium raw indigo selvedge denim jeans, neatly folded to show the subtle red selvedge line, resting on a clean white surface in a bright, modern studio setting." src="https://lh3.googleusercontent.com/aida-public/AB6AXuA3KtyijTMhVXom1RO_swJZlyUyoNGvjXfqL7D4OC1xSm07BNIyRC_yiYiQ-2wXHRVZgWqchTyyl09daQKKZpIwlnTLlsV1-OCGoKWd7XZFlfH92W413H9W-QTi919sXUNgojvWUIo3JPwwkQI3BbDnJmkzYQb8cOp5-ZH9XNwPSMgwgw31M1RLlLG9j7xikGQXt1koUAVHY-2LOlCtkDTDa3DdnCh0QHX2cMKe9ot4GfA5Hyeezz4n" />
</div>
<div>
<div className="font-label-lg text-label-lg text-primary">Selvedge Jeans</div>
<div className="text-on-surface-variant text-[13px] mt-0.5">Raw Indigo / Straight</div>
</div>
</td>
<td className="py-4 px-4 text-on-surface-variant">DNM-RAW-032</td>
<td className="py-4 px-4 font-label-sm text-label-sm">32x32</td>
<td className="py-4 px-4">
<div className="flex items-center gap-2">
<button className="w-6 h-6 rounded-full border border-outline-variant/50 flex items-center justify-center text-on-surface-variant hover:border-primary hover:text-primary transition-colors"><span className="material-symbols-outlined text-[14px]">remove</span></button>
<span className="w-6 text-center font-body-md">8</span>
<button className="w-6 h-6 rounded-full border border-outline-variant/50 flex items-center justify-center text-on-surface-variant hover:border-primary hover:text-primary transition-colors"><span className="material-symbols-outlined text-[14px]">add</span></button>
</div>
</td>
<td className="py-4 px-4">
<span className="px-2.5 py-1 rounded-full bg-surface-container-low text-on-surface font-label-sm text-[11px] tracking-wider uppercase">In Stock</span>
</td>
<td className="py-4 pr-6 pl-4 text-right text-on-surface-variant text-[13px]">Aug 14, 2026, 11:20 AM</td>
</tr>
</tbody>
</table>
</div>

<div className="flex justify-between items-center px-4 py-2">
<span className="text-body-sm text-on-surface-variant">Showing 1-10 of 240 products</span>
<div className="flex gap-2">
<button className="w-8 h-8 rounded border border-outline-variant/30 flex items-center justify-center text-on-surface-variant hover:bg-surface-container-low disabled:opacity-50"><span className="material-symbols-outlined text-[18px]">chevron_left</span></button>
<button className="w-8 h-8 rounded bg-primary text-on-primary flex items-center justify-center font-label-sm">1</button>
<button className="w-8 h-8 rounded border border-outline-variant/30 flex items-center justify-center text-on-surface hover:bg-surface-container-low font-label-sm">2</button>
<button className="w-8 h-8 rounded border border-outline-variant/30 flex items-center justify-center text-on-surface hover:bg-surface-container-low font-label-sm">3</button>
<button className="w-8 h-8 rounded border border-outline-variant/30 flex items-center justify-center text-on-surface-variant hover:bg-surface-container-low"><span className="material-symbols-outlined text-[18px]">chevron_right</span></button>
</div>
</div>
</div>

<div className="col-span-12 lg:col-span-3">
<div className="bg-surface-container-lowest rounded-xl shadow-[0px_4px_20px_rgba(20,20,20,0.02)] p-lg sticky top-24">
<div className="flex items-center gap-2 mb-md">
<span className="material-symbols-outlined text-secondary">inventory</span>
<h3 className="font-headline-md text-headline-md text-primary">Restock Queue</h3>
</div>
<p className="font-body-sm text-body-sm text-on-surface-variant mb-lg">Items requiring immediate attention to prevent stockouts.</p>
<div className="flex flex-col gap-md">

<div className="flex flex-col gap-2 p-3 rounded-lg border border-outline-variant/20 bg-surface hover:border-outline-variant/50 transition-colors">
<div className="flex justify-between items-start">
<div>
<h4 className="font-label-lg text-label-lg text-primary">Selvedge Jeans</h4>
<p className="font-body-sm text-[13px] text-on-surface-variant">Size: 34x32</p>
</div>
<span className="w-2 h-2 rounded-full bg-error mt-1.5"></span>
</div>
<div className="flex justify-between items-center mt-2">
<span className="font-label-sm text-[12px] text-error bg-error-container/20 px-2 py-0.5 rounded">0 in stock</span>
<button className="font-label-sm text-label-sm text-primary border-b border-primary hover:text-secondary hover:border-secondary transition-colors pb-0.5">Restock</button>
</div>
</div>

<div className="flex flex-col gap-2 p-3 rounded-lg border border-outline-variant/20 bg-surface hover:border-outline-variant/50 transition-colors">
<div className="flex justify-between items-start">
<div>
<h4 className="font-label-lg text-label-lg text-primary">Wool Trousers</h4>
<p className="font-body-sm text-[13px] text-on-surface-variant">Size: 32R</p>
</div>
<span className="w-2 h-2 rounded-full bg-secondary mt-1.5"></span>
</div>
<div className="flex justify-between items-center mt-2">
<span className="font-label-sm text-[12px] text-on-secondary-container bg-secondary-fixed/50 px-2 py-0.5 rounded">2 in stock</span>
<button className="font-label-sm text-label-sm text-primary border-b border-primary hover:text-secondary hover:border-secondary transition-colors pb-0.5">Restock</button>
</div>
</div>

<div className="flex flex-col gap-2 p-3 rounded-lg border border-outline-variant/20 bg-surface hover:border-outline-variant/50 transition-colors">
<div className="flex justify-between items-start">
<div>
<h4 className="font-label-lg text-label-lg text-primary">Oxford Cotton Shirt</h4>
<p className="font-body-sm text-[13px] text-on-surface-variant">Size: XL</p>
</div>
<span className="w-2 h-2 rounded-full bg-error mt-1.5"></span>
</div>
<div className="flex justify-between items-center mt-2">
<span className="font-label-sm text-[12px] text-error bg-error-container/20 px-2 py-0.5 rounded">0 in stock</span>
<button className="font-label-sm text-label-sm text-primary border-b border-primary hover:text-secondary hover:border-secondary transition-colors pb-0.5">Restock</button>
</div>
</div>
</div>
<button className="w-full mt-lg h-12 rounded-full border border-primary text-primary font-label-lg text-label-lg hover:bg-surface-container-low transition-colors">
                            View All Shortages
                        </button>
</div>
</div>
</div>
</main>
  );
}