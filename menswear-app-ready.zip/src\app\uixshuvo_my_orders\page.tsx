export default function UixshuvoMyOrders() {
  return (
    <main className="pt-32 pb-stack-lg px-margin-mobile md:px-margin-desktop max-w-container-max mx-auto min-h-screen">

<div className="flex items-center space-x-2 text-muted text-sm mb-12">
<a className="hover:text-primary transition-colors" href="#">Home</a>
<span className="">/</span>
<a className="hover:text-primary transition-colors" href="#">Account</a>
<span className="">/</span>
<span className="text-primary">My Orders</span>
</div>

<div className="mb-12">
<h1 className="font-headline-lg text-headline-lg uppercase mb-8">MY ORDERS</h1>
<div className="flex flex-wrap gap-4 font-label-sm uppercase">
<button className="bg-ink text-white px-6 py-3 rounded-full hover:bg-opacity-90 transition-colors">All 12</button>
<button className="bg-white text-ink border border-surface-variant px-6 py-3 rounded-full hover:border-ink transition-colors">Active 2</button>
<button className="bg-white text-ink border border-surface-variant px-6 py-3 rounded-full hover:border-ink transition-colors">Delivered 9</button>
<button className="bg-white text-ink border border-surface-variant px-6 py-3 rounded-full hover:border-ink transition-colors">Cancelled 1</button>
</div>
</div>

<div className="space-y-6">

<div className="bg-white rounded-card p-6 md:p-8 shadow-ambient hover:shadow-ambient-hover transition-shadow duration-300 flex flex-col md:flex-row gap-8 items-start md:items-center">
<div className="flex -space-x-4">
<img className="w-24 h-24 rounded-lg object-cover border-2 border-white shadow-sm z-10" data-alt="A minimalist overhead shot of a folded crisp white slim fit oxford shirt on a soft lavender-white surface. High key lighting, pure white fabric, premium editorial aesthetic, soft subtle shadow." src="https://lh3.googleusercontent.com/aida-public/AB6AXuCJzjJUjm0cb6XuRLeZNy3Vmg9lNQsgs3d0mnfb66TaeUwXcFlpT5p2w1wgq3BxLnH9wzh6va5fxWBO51sF6icKId0624G7JTm3-UZC6-MQ5Cf1OZbUkZIffLt4yZw7kiCndutjWI-QkKkPkfsEkD5lIkU8VPxo6PcgoT2QLIVhl7SSqlW7T3dysYnRHqxpX2BosdHsM_XniKLu4PcWxRhbowAAQ8VmZPKe_O9tKRUjmxKB9xNPxoHeqQ" />
<img className="w-24 h-24 rounded-lg object-cover border-2 border-white shadow-sm z-0" data-alt="A minimalist overhead shot of a folded crisp white cotton t-shirt on a soft lavender-white surface. High key lighting, pure white fabric, premium editorial aesthetic, soft subtle shadow." src="https://lh3.googleusercontent.com/aida-public/AB6AXuBAFvgLHRj5CsnYVFExtn1ls8Wd87c84IlkABWKLuZu3UdHnQdhwBlMwHZf_OiiKu9I6-pPUgAXNQz9gTzyw4RjFWr5eUkLot4yN6DUPl8A9lp2nXr64I2B65ZYkT0gVk7NJwiq1SfSidX1CXudgHnupXTmq57qjQ0Zsi6sg06pKdz5JqLU09XtLkl-9qXeDM0uTz33JeZGN0Rux89IeJHKcuF14PtaKKjgEHip6FbCGB2gixL2FLSoJA" />
</div>
<div className="flex-1 space-y-2">
<div className="flex items-center gap-3">
<span className="font-label-sm text-muted">#MW-2481</span>
<span className="text-surface-variant">•</span>
<span className="font-label-sm text-muted">Aug 17, 2026</span>
</div>
<h3 className="font-body-md text-lg">Slim Fit Oxford Shirt, White Cotton T-shirt</h3>
<div className="inline-block mt-2">
<span className="bg-surface-variant text-ink px-3 py-1 rounded-full font-label-sm uppercase tracking-wide text-[10px]">Shipped</span>
</div>
</div>
<div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto mt-4 md:mt-0">
<button className="px-6 py-3 rounded-full border border-ink text-ink font-label-sm uppercase hover:bg-surface-variant transition-colors w-full sm:w-auto text-center">View Details</button>
<button className="px-6 py-3 rounded-full bg-ink text-white font-label-sm uppercase flex items-center justify-center gap-2 hover:bg-opacity-90 transition-colors w-full sm:w-auto">
                        Track Order <span className="material-symbols-outlined text-[16px]">arrow_forward</span>
</button>
</div>
</div>

<div className="bg-white rounded-card p-6 md:p-8 shadow-ambient hover:shadow-ambient-hover transition-shadow duration-300 flex flex-col md:flex-row gap-8 items-start md:items-center">
<div className="flex">
<img className="w-24 h-24 rounded-lg object-cover border-2 border-white shadow-sm" data-alt="A minimalist overhead shot of a folded crisp white grandad collar shirt on a soft lavender-white surface. High key lighting, pure white fabric, premium editorial aesthetic, soft subtle shadow." src="https://lh3.googleusercontent.com/aida-public/AB6AXuBOHjct4Z8RAPWnzzKVfdpfqlOPrddhUrvipVllT_eW0UZU5kFoWk6m2haBfi2S6JcvMNrYMC4bZYII6yzrlTmaEOpUwgJ0Hk7x37F7iBx3i3iYZzDAZCPKKKleARS9gS1Ts2PGlqGgjopZQNWzX-d-J6HD_PbMRncbnlO5lcTE9RoqY_fKErIFxoFyEIT9MkZpEE3WTTDPilPdD8lV09nzNypF9CnQRDtSXYVgldBmanhapTMB86jrNQ" />
</div>
<div className="flex-1 space-y-2">
<div className="flex items-center gap-3">
<span className="font-label-sm text-muted">#MW-2310</span>
<span className="text-surface-variant">•</span>
<span className="font-label-sm text-muted">Jul 30, 2026</span>
</div>
<h3 className="font-body-md text-lg">Grandad Collar Shirt</h3>
<div className="inline-block mt-2">
<span className="border border-ink text-ink px-3 py-1 rounded-full font-label-sm uppercase tracking-wide text-[10px]">Processing</span>
</div>
</div>
<div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto mt-4 md:mt-0">
<button className="px-6 py-3 rounded-full border border-ink text-ink font-label-sm uppercase hover:bg-surface-variant transition-colors w-full sm:w-auto text-center">View Details</button>
<button className="px-6 py-3 rounded-full bg-ink text-white font-label-sm uppercase flex items-center justify-center gap-2 hover:bg-opacity-90 transition-colors w-full sm:w-auto">
                        Track Order <span className="material-symbols-outlined text-[16px]">arrow_forward</span>
</button>
</div>
</div>

<div className="bg-white rounded-card p-6 md:p-8 shadow-ambient hover:shadow-ambient-hover transition-shadow duration-300 flex flex-col md:flex-row gap-8 items-start md:items-center">
<div className="flex">
<img className="w-24 h-24 rounded-lg object-cover border-2 border-white shadow-sm" data-alt="A minimalist overhead shot of a folded crisp white premium poplin shirt on a soft lavender-white surface. High key lighting, pure white fabric, premium editorial aesthetic, soft subtle shadow." src="https://lh3.googleusercontent.com/aida-public/AB6AXuDleePo4Ff-If5PJIVSUC4MGr7mAiGstUg1PqbT_LEHmH4BN3bboEAcmRiNcSrPQVB1Vftj6nzdiqTvwzC-thMeK7Xrv0BbddYUqY2aLRvxzmK8Xa0Kmv9ft-S1M8ih7nX_nJianzBzZ3AYkYy7bwXWSWVTwh9OppB5sgtOc33mRSkB_DsT6wvF_sF_2utn9ClitZTtftR6poR5T0H5QnaVtiIazePjBaXlvaZEgoXlgzFV3Ji3yeH78w" />
</div>
<div className="flex-1 space-y-2">
<div className="flex items-center gap-3">
<span className="font-label-sm text-muted">#MW-2144</span>
<span className="text-surface-variant">•</span>
<span className="font-label-sm text-muted">Jun 12, 2026</span>
</div>
<h3 className="font-body-md text-lg">Premium Poplin Shirt</h3>
<div className="inline-block mt-2">
<span className="bg-sage text-white px-3 py-1 rounded-full font-label-sm uppercase tracking-wide text-[10px]">Delivered</span>
</div>
</div>
<div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto mt-4 md:mt-0">
<button className="px-6 py-3 rounded-full border border-ink text-ink font-label-sm uppercase hover:bg-surface-variant transition-colors w-full sm:w-auto text-center">View Details</button>
<button className="px-6 py-3 rounded-full border border-ink text-ink font-label-sm uppercase hover:bg-surface-variant transition-colors w-full sm:w-auto text-center">Reorder</button>
</div>
</div>

<div className="bg-white rounded-card p-6 md:p-8 shadow-ambient hover:shadow-ambient-hover transition-shadow duration-300 flex flex-col md:flex-row gap-8 items-start md:items-center">
<div className="flex">
<img className="w-24 h-24 rounded-lg object-cover border-2 border-white shadow-sm" data-alt="A minimalist overhead shot of a folded crisp white henley shirt on a soft lavender-white surface. High key lighting, pure white fabric, premium editorial aesthetic, soft subtle shadow." src="https://lh3.googleusercontent.com/aida-public/AB6AXuCpAWoVsQlx10DxXTTAjBHornEp4IFb7OIcsc2GVMiFaWPkZ-f25GUU3RTUJ1h0WoGUmYEdUfqFj_xo0cnD9bmFiNet9kLtWl_S84vKGfM3RR1A4l-o5W_JU0s85tE8gU-AIESbe8lYe7_Br1cUviACXI3TwHJn0NP9-b16bU-hZM_35pM-2p5DbXroDeJfivybIZoPnY4eJOjnVSvOAaS3JkhW_KNPymreL41zRI5CHuxO1nvgAU0taA" />
</div>
<div className="flex-1 space-y-2">
<div className="flex items-center gap-3">
<span className="font-label-sm text-muted">#MW-1987</span>
<span className="text-surface-variant">•</span>
<span className="font-label-sm text-muted">May 3, 2026</span>
</div>
<h3 className="font-body-md text-lg">White Henley Shirt</h3>
<div className="inline-block mt-2">
<span className="bg-sage text-white px-3 py-1 rounded-full font-label-sm uppercase tracking-wide text-[10px]">Delivered</span>
</div>
</div>
<div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto mt-4 md:mt-0">
<button className="px-6 py-3 rounded-full border border-ink text-ink font-label-sm uppercase hover:bg-surface-variant transition-colors w-full sm:w-auto text-center">View Details</button>
<button className="px-6 py-3 rounded-full border border-ink text-ink font-label-sm uppercase hover:bg-surface-variant transition-colors w-full sm:w-auto text-center">Reorder</button>
</div>
</div>
</div>
</main>
  );
}