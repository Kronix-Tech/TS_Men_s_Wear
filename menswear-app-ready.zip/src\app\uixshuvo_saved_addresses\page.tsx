export default function UixshuvoSavedAddresses() {
  return (
    <main className="max-w-container-max mx-auto px-margin-mobile md:px-margin-desktop py-stack-md">
<nav className="text-[#6E6E75] font-body-md text-sm mb-stack-md">
<span className="">Home</span> / <span className="">Account</span> / <span className="text-primary font-medium">Addresses</span>
</nav>
<h1 className="font-headline-lg-mobile md:font-headline-lg text-headline-lg-mobile md:text-headline-lg uppercase mb-stack-lg">SAVED ADDRESSES</h1>
<section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-gutter mb-stack-lg">
<div className="bg-surface-container-lowest rounded-[24px] p-6 ambient-shadow hover:-translate-y-1 transition-transform duration-300 relative group">
<div className="absolute top-6 right-6">
<span className="bg-[#8FB0A4] text-white font-label-sm text-label-sm px-3 py-1.5 rounded-full uppercase">Default</span>
</div>
<div className="mb-4">
<span className="material-symbols-outlined text-outline mb-2">home</span>
<h3 className="font-label-sm text-label-sm uppercase text-on-surface-variant mb-2">HOME</h3>
<p className="font-body-md text-on-surface font-medium">John Doe</p>
<p className="font-body-md text-on-surface-variant mt-1 text-sm">+1 123-456-7890</p>
<p className="font-body-md text-on-surface-variant mt-2 text-sm leading-relaxed">
                        123 Maple St, Apt 4B<br />
                        New York, NY 10001
                    </p>
</div>
<div className="flex items-center space-x-4 mt-6">
<button className="border border-primary text-primary px-6 py-2 rounded-full font-label-sm text-label-sm uppercase hover:bg-primary hover:text-on-primary transition-colors">EDIT</button>
<button className="text-outline uppercase font-label-sm text-label-sm hover:text-error transition-colors underline decoration-transparent hover:decoration-error">DELETE</button>
</div>
</div>
<div className="bg-surface-container-lowest rounded-[24px] p-6 ambient-shadow hover:-translate-y-1 transition-transform duration-300 relative">
<div className="mb-4">
<span className="material-symbols-outlined text-outline mb-2">work</span>
<h3 className="font-label-sm text-label-sm uppercase text-on-surface-variant mb-2">WORK</h3>
<p className="font-body-md text-on-surface font-medium">John Doe</p>
<p className="font-body-md text-on-surface-variant mt-1 text-sm">+1 123-456-7890</p>
<p className="font-body-md text-on-surface-variant mt-2 text-sm leading-relaxed">
                        456 Business Way, Suite 200<br />
                        Brooklyn, NY 11201
                    </p>
</div>
<div className="flex items-center space-x-4 mt-6 flex-wrap gap-y-2">
<button className="border border-primary text-primary px-6 py-2 rounded-full font-label-sm text-label-sm uppercase hover:bg-primary hover:text-on-primary transition-colors">EDIT</button>
<button className="text-outline uppercase font-label-sm text-label-sm hover:text-error transition-colors underline decoration-transparent hover:decoration-error">DELETE</button>
<button className="text-primary uppercase font-label-sm text-label-sm hover:underline transition-all">SET DEFAULT</button>
</div>
</div>
<button className="bg-[#E7E5EE] border-2 border-dashed border-outline-variant rounded-[24px] p-6 flex flex-col items-center justify-center min-h-[250px] hover:border-primary transition-colors group">
<span className="material-symbols-outlined text-4xl text-outline group-hover:text-primary mb-4 transition-colors">add</span>
<span className="font-label-sm text-label-sm uppercase text-on-surface-variant group-hover:text-primary transition-colors">ADD NEW ADDRESS</span>
</button>
</section>
<section className="bg-surface-container-lowest rounded-[24px] p-margin-mobile md:p-margin-desktop ambient-shadow max-w-4xl mx-auto">
<h2 className="font-headline-md text-headline-md mb-stack-md uppercase">ADD A NEW ADDRESS</h2>
<form className="space-y-6">
<div className="grid grid-cols-1 md:grid-cols-2 gap-6">
<div>
<label className="block font-label-sm text-label-sm text-on-surface-variant mb-2">FULL NAME</label>
<input className="w-full border-b border-outline-variant bg-transparent py-2 focus:outline-none focus:border-primary transition-colors font-body-md" placeholder="John Doe" type="text" />
</div>
<div>
<label className="block font-label-sm text-label-sm text-on-surface-variant mb-2">PHONE</label>
<input className="w-full border-b border-outline-variant bg-transparent py-2 focus:outline-none focus:border-primary transition-colors font-body-md" placeholder="+1 123-456-7890" type="tel" />
</div>
</div>
<div className="grid grid-cols-1 md:grid-cols-3 gap-6">
<div className="md:col-span-1">
<label className="block font-label-sm text-label-sm text-on-surface-variant mb-2">PIN CODE</label>
<input className="w-full border-b border-outline-variant bg-transparent py-2 focus:outline-none focus:border-primary transition-colors font-body-md" placeholder="10001" type="text" />
</div>
<div className="md:col-span-1">
<label className="block font-label-sm text-label-sm text-on-surface-variant mb-2">CITY</label>
<input className="w-full border-b border-outline-variant bg-transparent py-2 focus:outline-none focus:border-primary transition-colors font-body-md" placeholder="New York" type="text" />
</div>
<div className="md:col-span-1">
<label className="block font-label-sm text-label-sm text-on-surface-variant mb-2">STATE</label>
<input className="w-full border-b border-outline-variant bg-transparent py-2 focus:outline-none focus:border-primary transition-colors font-body-md" placeholder="NY" type="text" />
</div>
</div>
<div>
<label className="block font-label-sm text-label-sm text-on-surface-variant mb-2">ADDRESS LINE 1</label>
<input className="w-full border-b border-outline-variant bg-transparent py-2 focus:outline-none focus:border-primary transition-colors font-body-md" placeholder="123 Maple St" type="text" />
</div>
<div>
<label className="block font-label-sm text-label-sm text-on-surface-variant mb-2">ADDRESS LINE 2 (OPTIONAL)</label>
<input className="w-full border-b border-outline-variant bg-transparent py-2 focus:outline-none focus:border-primary transition-colors font-body-md" placeholder="Apt 4B" type="text" />
</div>
<div className="pt-4">
<label className="block font-label-sm text-label-sm text-on-surface-variant mb-4">ADDRESS TYPE</label>
<div className="flex space-x-4">
<label className="flex items-center cursor-pointer">
<input defaultChecked={true} className="peer sr-only" name="addressType" type="radio" />
<span className="px-6 py-2 rounded-full border border-outline-variant text-on-surface-variant font-label-sm text-label-sm uppercase peer-checked:bg-surface-container peer-checked:border-primary peer-checked:text-primary transition-all">HOME</span>
</label>
<label className="flex items-center cursor-pointer">
<input className="peer sr-only" name="addressType" type="radio" />
<span className="px-6 py-2 rounded-full border border-outline-variant text-on-surface-variant font-label-sm text-label-sm uppercase peer-checked:bg-surface-container peer-checked:border-primary peer-checked:text-primary transition-all">WORK</span>
</label>
</div>
</div>
<div className="flex flex-col sm:flex-row items-center gap-4 pt-8">
<button className="w-full sm:w-auto bg-[#141414] text-white px-8 py-3 rounded-full font-label-sm text-label-sm uppercase flex items-center justify-center space-x-2 hover:bg-primary-container/90 transition-colors" type="button">
<span className="">SAVE ADDRESS</span>
<span className="">→</span>
</button>
<button className="w-full sm:w-auto border border-[#141414] text-[#141414] px-8 py-3 rounded-full font-label-sm text-label-sm uppercase hover:bg-surface-container-highest transition-colors" type="button">
                        CANCEL
                    </button>
</div>
</form>
</section>
</main>
  );
}