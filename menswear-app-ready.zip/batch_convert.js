const fs = require('fs');
const path = require('path');

const sourceDir = '../stitch_minimalist_men_s_wear';
const targetBaseDir = 'src/app';

function toComponentName(folderName) {
    return folderName.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join('');
}

function convertPage(htmlPath, targetPath, componentName) {
    try {
        let html = fs.readFileSync(htmlPath, 'utf8');
        let mainMatch = html.match(/<main[\s\S]*?<\/main>/i);
        if (mainMatch) {
            let main = mainMatch[0];
            
            // React attribute replacements
            main = main.replace(/\sclass=/g, ' className=');
            main = main.replace(/\sfor=/g, ' htmlFor=');
            main = main.replace(/<!--[\s\S]*?-->/g, ''); // remove comments
            
            // Self close img and input and hr tags
            main = main.replace(/<(img|input|hr)([^>]+)>/g, (match, tag, attrs) => {
                if(attrs.trim().endsWith('/')) return match;
                return '<' + tag + attrs + ' />';
            });
            
            // Self close br tags
            main = main.replace(/<br>/gi, '<br />');
            
            // Fix boolean attributes
            main = main.replace(/disabled=""/g, 'disabled={true}');
            main = main.replace(/checked=""/g, 'defaultChecked={true}');
            
            // Handle inline styles using a generic replacer for style="..."
            main = main.replace(/style="([^"]*)"/g, (match, p1) => {
                 let styleObjStr = p1.split(';')
                     .filter(s => s.trim())
                     .map(s => { 
                        let parts = s.split(':'); 
                        if (parts.length < 2) return '';
                        let k = parts[0].trim();
                        let v = parts.slice(1).join(':').trim();
                        
                        // Handle specific tricky rules like font-variation-settings that use quotes inside
                        if (k === 'font-variation-settings') {
                            v = v.replace(/'/g, "\\'");
                        }
                        
                        // camelCase the key
                        if (k.startsWith('-')) {
                            // Leave custom properties (CSS variables) as is, React supports them if quoted
                        } else {
                            k = k.replace(/-([a-z])/g, (g) => g[1].toUpperCase());
                        }
                        return `"${k}": "${v}"`;
                     })
                     .filter(s => s !== '')
                     .join(',');
                 return 'style={{' + styleObjStr + '}}';
            });
            
            let comp = `export default function ${componentName}() {\n  return (\n    ${main}\n  );\n}`;
            fs.writeFileSync(targetPath, comp);
            console.log(`Successfully created ${targetPath}`);
            return true;
        } else {
            console.log(`No <main> tag found in ${htmlPath}`);
            // Fallback: extract body if no main
            let bodyMatch = html.match(/<body[^>]*>([\s\S]*?)<\/body>/i);
            if (bodyMatch) {
                // we should strip header and footer if possible, but for now just use a wrapper div
                let content = bodyMatch[1].replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '');
                // Do the same replacements
                content = content.replace(/\sclass=/g, ' className=');
                content = content.replace(/\sfor=/g, ' htmlFor=');
                content = content.replace(/<!--[\s\S]*?-->/g, ''); 
                content = content.replace(/<(img|input|hr)([^>]+)>/g, (match, tag, attrs) => {
                    if(attrs.trim().endsWith('/')) return match;
                    return '<' + tag + attrs + ' />';
                });
                content = content.replace(/<br>/gi, '<br />');
                content = content.replace(/style="([^"]*)"/g, (match, p1) => {
                     let styleObjStr = p1.split(';').filter(s => s.trim()).map(s => { 
                        let parts = s.split(':'); if(parts.length<2) return '';
                        let k = parts[0].trim(); let v = parts.slice(1).join(':').trim();
                        if (k === 'font-variation-settings') v = v.replace(/'/g, "\\'");
                        if (!k.startsWith('-')) k = k.replace(/-([a-z])/g, (g) => g[1].toUpperCase());
                        return `"${k}": "${v}"`;
                     }).filter(s=>s!=='').join(',');
                     return 'style={{' + styleObjStr + '}}';
                });
                let comp = `export default function ${componentName}() {\n  return (\n    <div className="w-full flex-grow flex flex-col">\n      ${content}\n    </div>\n  );\n}`;
                fs.writeFileSync(targetPath, comp);
                console.log(`Successfully created ${targetPath} (from body)`);
                return true;
            }
            return false;
        }
    } catch (e) {
        console.error(`Failed to process ${htmlPath}: ${e.message}`);
        return false;
    }
}

const folders = fs.readdirSync(sourceDir).filter(f => fs.statSync(path.join(sourceDir, f)).isDirectory());

let successCount = 0;
for (const folder of folders) {
    const htmlPath = path.join(sourceDir, folder, 'code.html');
    if (fs.existsSync(htmlPath)) {
        let routeName = folder;
        // Clean up route name a bit, or keep as is for mapping
        // We will create the folder in src/app
        
        const targetDir = path.join(targetBaseDir, routeName);
        if (!fs.existsSync(targetDir)) {
            fs.mkdirSync(targetDir, { recursive: true });
        }
        
        const componentName = toComponentName(folder);
        const targetPath = path.join(targetDir, 'page.tsx');
        
        const success = convertPage(htmlPath, targetPath, componentName);
        if (success) successCount++;
    }
}
console.log(`\nFinished converting ${successCount} out of ${folders.length} pages.`);
