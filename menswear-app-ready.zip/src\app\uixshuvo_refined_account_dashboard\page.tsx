export default function UixshuvoRefinedAccountDashboard() {
  return (
    <main className="flex-grow w-full max-w-container-max mx-auto px-margin-mobile md:px-margin-desktop py-stack-md md:py-stack-lg">
<div className="grid grid-cols-1 md:grid-cols-12 gap-gutter">

<aside className="md:col-span-3 lg:col-span-3 space-y-6">

<div className="bg-surface-container-lowest rounded-xl p-6 editorial-shadow flex flex-col items-center text-center">
<div className="w-24 h-24 rounded-full overflow-hidden mb-4 border-2 border-surface-variant">
<img alt="Arun Kumar Avatar" className="w-full h-full object-cover" data-alt="A close-up portrait of a modern man with a neat beard, wearing a high-end minimalist black turtleneck. Soft, diffused lighting highlights his features against a clean, light lavender-white background. The overall mood is sophisticated, calm, and subtly luxurious, matching a quiet luxury editorial style." src="https://lh3.googleusercontent.com/aida-public/AB6AXuA7L5qDo_Q1ybjlag1KlVuUzEpzbFcQmBsjVdThk5hYuAmc2PywVYdFEEdJbg0thctFHC-YLu_fRSQxCMOUxvVEBdXaeA6d_JQ-_G65MhbopZAxWJpvSrrp-1l5-9KBcHivU1cz9-PQtyPYjAxt_xBfuY3P4Mvl_QPb0bhZso0feB1TjcqiKJ1yAF2EXHrense9C8ccPwTv1UJkejIkd_85pkqpZUhjGpsXXoX4YxJkCk6NrXlfKZOWzA" />
</div>
<h2 className="font-headline-md text-headline-md text-primary mb-1">Arun Kumar</h2>
<p className="font-body-md text-body-md text-on-surface-variant">arun@menswear.com</p>
</div>

<nav className="bg-surface-container-lowest rounded-xl p-4 editorial-shadow">
<ul className="space-y-2">
<li className="">
<a className="flex items-center px-4 py-3 rounded-full bg-primary text-on-primary font-body-md text-body-md transition-all" href="#">
<span className="material-symbols-outlined mr-3">dashboard</span>
                                Dashboard
                            </a>
</li>
<li className="">
<a className="flex items-center px-4 py-3 rounded-full text-on-surface-variant hover:bg-surface-container-low hover:text-primary transition-all font-body-md text-body-md" href="#">
<span className="material-symbols-outlined mr-3">inventory_2</span>
                                My Orders
                            </a>
</li>
<li className="">
<a className="flex items-center px-4 py-3 rounded-full text-on-surface-variant hover:bg-surface-container-low hover:text-primary transition-all font-body-md text-body-md" href="#">
<span className="material-symbols-outlined mr-3">favorite</span>
                                Wishlist
                            </a>
</li>
<li className="">
<a className="flex items-center px-4 py-3 rounded-full text-on-surface-variant hover:bg-surface-container-low hover:text-primary transition-all font-body-md text-body-md" href="#">
<span className="material-symbols-outlined mr-3">location_on</span>
                                Addresses
                            </a>
</li>
<li className="">
<a className="flex items-center px-4 py-3 rounded-full text-on-surface-variant hover:bg-surface-container-low hover:text-primary transition-all font-body-md text-body-md" href="#">
<span className="material-symbols-outlined mr-3">settings</span>
                                Profile Settings
                            </a>
</li>
<li className="pt-4 mt-2 border-t border-surface-variant">
<a className="flex items-center px-4 py-3 rounded-full text-error hover:bg-error-container transition-all font-body-md text-body-md" href="#">
<span className="material-symbols-outlined mr-3">logout</span>
                                Logout
                            </a>
</li>
</ul>
</nav>
</aside>

<div className="md:col-span-9 lg:col-span-9 space-y-8">

<header className="pb-2">
<h1 className="font-headline-lg text-headline-lg-mobile md:text-headline-lg text-primary uppercase tracking-widest">HELLO, ARUN</h1>
<p className="font-body-md text-body-md text-on-surface-variant mt-2">Welcome back to your personalized dashboard.</p>
</header>

<div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
<div className="bg-surface-container-lowest rounded-xl p-6 editorial-shadow border border-surface-variant/50 hover:-translate-y-1 transition-transform duration-300">
<div className="flex justify-between items-start mb-4">
<h3 className="font-label-sm text-label-sm uppercase text-on-surface-variant">Active Orders</h3>
<span className="material-symbols-outlined text-secondary font-light" style={{"fontVariationSettings": "\'wght\' 200"}}>local_shipping</span>
</div>
<p className="font-display-lg text-display-lg text-primary">2</p>
</div>
<div className="bg-surface-container-lowest rounded-xl p-6 editorial-shadow border border-surface-variant/50 hover:-translate-y-1 transition-transform duration-300">
<div className="flex justify-between items-start mb-4">
<h3 className="font-label-sm text-label-sm uppercase text-on-surface-variant">Wishlist Items</h3>
<span className="material-symbols-outlined text-secondary font-light" style={{"fontVariationSettings": "\'wght\' 200"}}>favorite_border</span>
</div>
<p className="font-display-lg text-display-lg text-primary">6</p>
</div>
<div className="bg-surface-container-lowest rounded-xl p-6 editorial-shadow border border-surface-variant/50 hover:-translate-y-1 transition-transform duration-300">
<div className="flex justify-between items-start mb-4">
<h3 className="font-label-sm text-label-sm uppercase text-on-surface-variant">Available Coupons</h3>
<span className="material-symbols-outlined text-secondary font-light" style={{"fontVariationSettings": "\'wght\' 200"}}>sell</span>
</div>
<p className="font-display-lg text-display-lg text-primary">3</p>
</div>
</div>

<div className="grid grid-cols-1 lg:grid-cols-3 gap-8">

<div className="lg:col-span-2 space-y-8">

<div className="bg-surface-container-lowest rounded-[24px] p-6 md:p-8 editorial-shadow">
<div className="flex justify-between items-end mb-6">
<h3 className="font-headline-md text-headline-md text-primary">Recent Orders</h3>
<a className="font-label-sm text-label-sm uppercase text-on-surface-variant hover:text-primary hover:underline transition-all" href="#">View All</a>
</div>
<div className="space-y-6">

<div className="flex items-center justify-between group">
<div className="flex items-center space-x-4">
<div className="w-16 h-20 rounded-lg overflow-hidden bg-surface-variant flex-shrink-0">
<img alt="Order Thumbnail" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" data-alt="A minimalist high-end leather tote bag in a deep charcoal color, resting on a stark white plinth. Soft directional lighting casts long, elegant shadows, emphasizing the fine texture of the leather. The mood is luxurious and understated, fitting a premium editorial catalog." src="https://lh3.googleusercontent.com/aida/AP1WRLtfdaW2daAoiyD_rytcUgGPIncw_CCQbkBGulvFxl5SMVxsY_HhyHQiza1LChOz91SOaEEHERaf9Qh-3QzuQGE5b6ubl8zVuqcvvLI0uxMI7DEmghRKkQj_q0sb6-yM_DJ9E0muZ5JemdBzJGeQJ7Z46KC_y6FrYN6jES5BEnpU0W55y7OutXNLkoAarPKdAGBq4RrqaqWujrLijy90tUMWOFkpj4yT9Nz3ItWACd22ATVRowgaTQhu7OHv" />
</div>
<div>
<p className="font-label-sm text-label-sm text-on-surface-variant mb-1">#MW-09283</p>
<p className="font-body-md text-body-md text-primary mb-2">Aug 10, 2026</p>
<span className="inline-flex items-center px-3 py-1 rounded-full bg-surface-variant text-on-surface-variant font-label-sm text-label-sm uppercase">Shipped</span>
</div>
</div>
<a className="font-body-md text-body-md text-primary hover:underline transition-all" href="#">View</a>
</div>

<hr className="border-surface-variant" />

<div className="flex items-center justify-between group">
<div className="flex items-center space-x-4">
<div className="w-16 h-20 rounded-lg overflow-hidden bg-surface-variant flex-shrink-0">
<img alt="Order Thumbnail" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" data-alt="A perfectly folded crisp white poplin shirt presented on a soft muted lilac surface. The lighting is bright and diffuse, creating a pristine, clean aesthetic. The composition highlights the premium collar construction and minimalist styling, evoking a quiet luxury fashion brand." src="https://lh3.googleusercontent.com/aida-public/AB6AXuDcnIcMuEeOrlx825cvZXFmO-7KBDKjkFFJ6F8RSfXXcmf3bMJIqU2_f4hBuJzE2F6r_DDEyUUMbRQnqCZ_8zL3V3ZuseByMIJnDnHfTYyaqt5V8YOk_NTprO7n4HeaBH_aVRvuAPN8bu3Jm7rhPqPrco1z5CNLGE27xbtk_fVOD1tQd6cjxBZOaCaLfWgPDEbW8wBhHdsGj7-E_q2bILWYpGYg21ZH9MP6kufPAJ6jAB-qTAhHxCfVMA" />
</div>
<div>
<p className="font-label-sm text-label-sm text-on-surface-variant mb-1">#MW-08144</p>
<p className="font-body-md text-body-md text-primary mb-2">Sep 28, 2024</p>
<span className="inline-flex items-center px-3 py-1 rounded-full bg-secondary text-on-secondary font-label-sm text-label-sm uppercase">Delivered</span>
</div>
</div>
<a className="font-body-md text-body-md text-primary hover:underline transition-all" href="#">View</a>
</div>
</div>
</div>

<div className="bg-surface-container-lowest rounded-[24px] p-6 md:p-8 editorial-shadow">
<h3 className="font-headline-md text-headline-md text-primary mb-4">Profile Status</h3>
<div className="flex justify-between items-end mb-2">
<span className="font-body-md text-body-md text-on-surface-variant">80% complete — add a saved address</span>
<span className="font-label-sm text-label-sm text-primary">80%</span>
</div>
<div className="w-full h-2 bg-surface-variant rounded-full overflow-hidden">
<div className="h-full bg-primary rounded-full" style={{"width": "80%"}}></div>
</div>
</div>
</div>

<div className="lg:col-span-1">
<div className="bg-secondary rounded-[24px] p-8 text-on-secondary h-full flex flex-col justify-between editorial-shadow" style={{"backgroundColor": "#8FB0A4"}}>
<div>
<span className="material-symbols-outlined text-4xl mb-6 opacity-80" style={{"fontVariationSettings": "\'wght\' 200"}}>local_activity</span>
<h3 className="font-headline-md text-headline-md mb-4 uppercase tracking-wider">Member Offer</h3>
<p className="font-body-lg text-body-lg mb-8 opacity-90 leading-relaxed">Enjoy 20% off your next order as a thank you for your continued loyalty.</p>
<div className="mb-8">
<p className="font-label-sm text-label-sm uppercase mb-2 opacity-70">Your Code</p>
<div className="inline-block bg-on-secondary text-secondary font-body-md text-body-md px-6 py-3 rounded-full font-bold tracking-widest border border-on-secondary/20 border-dashed">
                                        ARUN20
                                    </div>
</div>
</div>
<a className="inline-flex items-center justify-center px-6 py-4 bg-primary text-on-primary rounded-full font-body-md text-body-md hover:bg-on-surface-variant transition-colors w-full group" href="#">
                                SHOP NOW
                                <span className="material-symbols-outlined ml-2 group-hover:translate-x-1 transition-transform">arrow_forward</span>
</a>
</div>
</div>
</div>
</div>
</div>
</main>
  );
}