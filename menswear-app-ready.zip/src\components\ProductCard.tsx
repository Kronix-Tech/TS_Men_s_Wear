'use client';

import { useCartStore } from '@/lib/store';

export default function ProductCard({ product }: { product: any }) {
  const addItem = useCartStore((state) => state.addItem);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      quantity: 1,
      imageUrl: product.imageUrl,
    });
    alert(`${product.name} added to cart!`);
  };

  return (
    <div className="product-card flex flex-col gap-3 group relative cursor-pointer hover-lift rounded-[24px] bg-surface p-3 pb-4">
      <div className="relative product-image-container h-[300px] w-full bg-surface-container rounded-xl overflow-hidden">
        <img className="w-full h-full object-cover" src={product.imageUrl} alt={product.name} />
        <button className="absolute top-3 right-3 w-8 h-8 bg-white/80 backdrop-blur rounded-full flex items-center justify-center hover:bg-white transition-colors z-10 text-on-surface">
          <span className="material-symbols-outlined text-sm">favorite</span>
        </button>
        <button 
          onClick={handleAddToCart}
          className="absolute bottom-3 right-3 w-10 h-10 bg-brand-black text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 translate-y-4 group-hover:translate-y-0 transition-all z-10"
        >
          <span className="material-symbols-outlined text-sm">shopping_bag</span>
        </button>
      </div>
      <div className="flex flex-col gap-1 px-1">
        <span className="font-label-sm text-on-surface-variant uppercase tracking-widest text-[10px]">{product.category?.name || 'Category'}</span>
        <h3 className="font-body-lg text-body-lg leading-tight truncate">{product.name}</h3>
        <div className="flex items-center gap-1 text-[#FFD700]">
          <span className="material-symbols-outlined text-[14px]" style={{fontVariationSettings: "'FILL' 1"}}>star</span>
          <span className="material-symbols-outlined text-[14px]" style={{fontVariationSettings: "'FILL' 1"}}>star</span>
          <span className="material-symbols-outlined text-[14px]" style={{fontVariationSettings: "'FILL' 1"}}>star</span>
          <span className="material-symbols-outlined text-[14px]" style={{fontVariationSettings: "'FILL' 1"}}>star</span>
          <span className="material-symbols-outlined text-[14px]">star_border</span>
          <span className="font-label-sm text-on-surface-variant ml-1">(0)</span>
        </div>
        <div className="flex items-center gap-2 mt-1">
          <span className="font-body-md font-medium">${product.price.toFixed(2)}</span>
        </div>
      </div>
    </div>
  );
}
