export default function OrdersListMenSWear() {
  return (
    <main className="flex-1 p-margin-mobile md:p-margin-desktop max-w-container-max mx-auto w-full flex flex-col gap-xl">

<div className="flex flex-col gap-md">
<h2 className="font-display-lg-mobile md:font-display-lg text-display-lg-mobile md:text-display-lg text-primary uppercase tracking-tight">ORDERS</h2>

<div className="flex flex-wrap gap-sm">
<button className="px-md py-2 rounded-full bg-secondary-fixed text-on-secondary-fixed font-label-sm text-label-sm uppercase tracking-wider transition-colors">
                        All (156)
                    </button>
<button className="px-md py-2 rounded-full bg-surface-container text-on-surface font-label-sm text-label-sm uppercase tracking-wider hover:bg-surface-container-high transition-colors">
                        Processing (12)
                    </button>
<button className="px-md py-2 rounded-full bg-surface-container text-on-surface font-label-sm text-label-sm uppercase tracking-wider hover:bg-surface-container-high transition-colors">
                        Shipped (30)
                    </button>
<button className="px-md py-2 rounded-full bg-surface-container text-on-surface font-label-sm text-label-sm uppercase tracking-wider hover:bg-surface-container-high transition-colors">
                        Delivered (108)
                    </button>
<button className="px-md py-2 rounded-full bg-surface-container text-on-surface font-label-sm text-label-sm uppercase tracking-wider hover:bg-surface-container-high transition-colors">
                        Cancelled (6)
                    </button>
</div>
</div>

<div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-md">
<div className="flex flex-col sm:flex-row gap-md w-full md:w-auto">

<div className="relative w-full sm:w-64">
<span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-on-surface-variant/50 text-[20px]">search</span>
<input className="w-full pl-10 pr-4 py-2.5 rounded-lg bg-surface-container-lowest border border-outline-variant/30 focus:border-secondary focus:ring-0 font-body-sm text-body-sm shadow-[0px_4px_20px_rgba(20,20,20,0.04)]" placeholder="Search order id or customer" type="text" />
</div>

<button className="flex items-center gap-sm px-4 py-2.5 rounded-lg bg-surface-container-lowest border border-outline-variant/30 hover:bg-surface-container-low transition-colors shadow-[0px_4px_20px_rgba(20,20,20,0.04)] w-full sm:w-auto">
<span className="material-symbols-outlined text-[20px] text-on-surface-variant">calendar_month</span>
<span className="font-body-sm text-body-sm text-on-surface">Aug 01 - Aug 31, 2026</span>
</button>
</div>
<button className="flex items-center gap-sm px-lg py-2.5 rounded-full border border-primary text-primary font-label-lg text-label-lg hover:bg-surface-container transition-colors w-full md:w-auto justify-center">
<span className="material-symbols-outlined text-[18px]">download</span>
                    Export CSV
                </button>
</div>

<div className="bg-surface-container-lowest rounded-[24px] overflow-hidden w-full border border-outline-variant/10">
<div className="overflow-x-auto w-full">
<table className="w-full text-left border-collapse">
<thead>
<tr className="border-b border-primary/5">
<th className="py-lg px-lg font-label-lg text-label-lg text-on-surface-variant uppercase tracking-wider w-[12%]">Order ID</th>
<th className="py-lg px-md font-label-lg text-label-lg text-on-surface-variant uppercase tracking-wider w-[18%]">Customer</th>
<th className="py-lg px-md font-label-lg text-label-lg text-on-surface-variant uppercase tracking-wider w-[15%]">Date</th>
<th className="py-lg px-md font-label-lg text-label-lg text-on-surface-variant uppercase tracking-wider w-[10%]">Items</th>
<th className="py-lg px-md font-label-lg text-label-lg text-on-surface-variant uppercase tracking-wider w-[10%]">Payment</th><th className="py-lg px-md font-label-lg text-label-lg text-on-surface-variant uppercase tracking-wider w-[12%]">Payment Status</th>
<th className="py-lg px-md font-label-lg text-label-lg text-on-surface-variant uppercase tracking-wider w-[15%]">Order Status</th>
<th className="py-lg px-md font-label-lg text-label-lg text-on-surface-variant uppercase tracking-wider w-[10%]">Total</th>
<th className="py-lg px-lg font-label-lg text-label-lg text-on-surface-variant uppercase tracking-wider text-right w-[10%]">Action</th>
</tr>
</thead>
<tbody className="font-body-sm text-body-sm text-on-surface divide-y divide-primary/5">

<tr className="hover:bg-surface-container-low/50 transition-colors group cursor-pointer">
<td className="py-4 px-lg font-label-lg text-label-lg text-primary">#MW-2481</td>
<td className="py-4 px-md">James Harrison</td>
<td className="py-4 px-md text-on-surface-variant">Aug 12, 2026</td>
<td className="py-4 px-md text-on-surface-variant">2 items</td>
<td className="py-4 px-md">
<div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-surface-container text-on-surface font-label-sm text-label-sm">
<span className="material-symbols-outlined text-[14px]">credit_card</span> Card
                                    </div>
</td><td className="py-4 px-md"><span className="inline-flex items-center px-2.5 py-1 rounded-full bg-secondary-container/50 text-on-secondary-container font-label-sm text-label-sm">PAID</span></td>
<td className="py-4 px-md">
<span className="inline-flex items-center px-2.5 py-1 rounded-full bg-secondary-container/50 text-on-secondary-container font-label-sm text-label-sm">
                                        Delivered
                                    </span>
</td>
<td className="py-4 px-md font-label-lg text-label-lg">$240.00</td>
<td className="py-4 px-lg text-right">
<button className="p-2 rounded-full hover:bg-surface-container text-on-surface-variant hover:text-primary transition-colors">
<span className="material-symbols-outlined text-[20px]">visibility</span>
</button>
</td>
</tr>

<tr className="hover:bg-surface-container-low/50 transition-colors group cursor-pointer">
<td className="py-4 px-lg font-label-lg text-label-lg text-primary">#MW-2482</td>
<td className="py-4 px-md">Michael Chen</td>
<td className="py-4 px-md text-on-surface-variant">Aug 14, 2026</td>
<td className="py-4 px-md text-on-surface-variant">1 item</td>
<td className="py-4 px-md">
<div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-surface-container text-on-surface font-label-sm text-label-sm">
<span className="material-symbols-outlined text-[14px]">account_balance_wallet</span> UPI
                                    </div>
</td><td className="py-4 px-md"><span className="inline-flex items-center px-2.5 py-1 rounded-full bg-secondary-container/50 text-on-secondary-container font-label-sm text-label-sm">PAID</span></td>
<td className="py-4 px-md">
<span className="inline-flex items-center px-2.5 py-1 rounded-full bg-primary-fixed/50 text-on-primary-fixed font-label-sm text-label-sm">
                                        Processing
                                    </span>
</td>
<td className="py-4 px-md font-label-lg text-label-lg">$125.50</td>
<td className="py-4 px-lg text-right">
<button className="p-2 rounded-full hover:bg-surface-container text-on-surface-variant hover:text-primary transition-colors">
<span className="material-symbols-outlined text-[20px]">visibility</span>
</button>
</td>
</tr>

<tr className="hover:bg-surface-container-low/50 transition-colors group cursor-pointer">
<td className="py-4 px-lg font-label-lg text-label-lg text-primary">#MW-2483</td>
<td className="py-4 px-md">Robert Foster</td>
<td className="py-4 px-md text-on-surface-variant">Aug 15, 2026</td>
<td className="py-4 px-md text-on-surface-variant">4 items</td>
<td className="py-4 px-md">
<div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-surface-container text-on-surface font-label-sm text-label-sm">
<span className="material-symbols-outlined text-[14px]">local_shipping</span> COD
                                    </div>
</td><td className="py-4 px-md"><span className="inline-flex items-center px-2.5 py-1 rounded-full bg-secondary-fixed text-on-secondary-fixed font-label-sm text-label-sm">UNPAID</span></td>
<td className="py-4 px-md">
<span className="inline-flex items-center px-2.5 py-1 rounded-full bg-surface-variant text-on-surface-variant font-label-sm text-label-sm">
                                        Shipped
                                    </span>
</td>
<td className="py-4 px-md font-label-lg text-label-lg">$580.00</td>
<td className="py-4 px-lg text-right">
<button className="p-2 rounded-full hover:bg-surface-container text-on-surface-variant hover:text-primary transition-colors">
<span className="material-symbols-outlined text-[20px]">visibility</span>
</button>
</td>
</tr>

<tr className="hover:bg-surface-container-low/50 transition-colors group cursor-pointer">
<td className="py-4 px-lg font-label-lg text-label-lg text-primary">#MW-2484</td>
<td className="py-4 px-md">William Davis</td>
<td className="py-4 px-md text-on-surface-variant">Aug 18, 2026</td>
<td className="py-4 px-md text-on-surface-variant">2 items</td>
<td className="py-4 px-md">
<div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-surface-container text-on-surface font-label-sm text-label-sm">
<span className="material-symbols-outlined text-[14px]">credit_card</span> Card
                                    </div>
</td><td className="py-4 px-md"><span className="inline-flex items-center px-2.5 py-1 rounded-full bg-secondary-container/50 text-on-secondary-container font-label-sm text-label-sm">PAID</span></td>
<td className="py-4 px-md">
<span className="inline-flex items-center px-2.5 py-1 rounded-full bg-error-container/50 text-on-error-container font-label-sm text-label-sm">
                                        Cancelled
                                    </span>
</td>
<td className="py-4 px-md font-label-lg text-label-lg">$310.00</td>
<td className="py-4 px-lg text-right">
<button className="p-2 rounded-full hover:bg-surface-container text-on-surface-variant hover:text-primary transition-colors">
<span className="material-symbols-outlined text-[20px]">visibility</span>
</button>
</td>
</tr>

<tr className="hover:bg-surface-container-low/50 transition-colors group cursor-pointer">
<td className="py-4 px-lg font-label-lg text-label-lg text-primary">#MW-2485</td>
<td className="py-4 px-md">Thomas Wright</td>
<td className="py-4 px-md text-on-surface-variant">Aug 20, 2026</td>
<td className="py-4 px-md text-on-surface-variant">1 item</td>
<td className="py-4 px-md">
<div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-surface-container text-on-surface font-label-sm text-label-sm">
<span className="material-symbols-outlined text-[14px]">account_balance_wallet</span> UPI
                                    </div>
</td><td className="py-4 px-md"><span className="inline-flex items-center px-2.5 py-1 rounded-full bg-secondary-container/50 text-on-secondary-container font-label-sm text-label-sm">PAID</span></td>
<td className="py-4 px-md">
<span className="inline-flex items-center px-2.5 py-1 rounded-full bg-secondary-container/50 text-on-secondary-container font-label-sm text-label-sm">
                                        Delivered
                                    </span>
</td>
<td className="py-4 px-md font-label-lg text-label-lg">$85.00</td>
<td className="py-4 px-lg text-right">
<button className="p-2 rounded-full hover:bg-surface-container text-on-surface-variant hover:text-primary transition-colors">
<span className="material-symbols-outlined text-[20px]">visibility</span>
</button>
</td>
</tr>

<tr className="hover:bg-surface-container-low/50 transition-colors group cursor-pointer">
<td className="py-4 px-lg font-label-lg text-label-lg text-primary">#MW-2486</td>
<td className="py-4 px-md">David Miller</td>
<td className="py-4 px-md text-on-surface-variant">Aug 22, 2026</td>
<td className="py-4 px-md text-on-surface-variant">3 items</td>
<td className="py-4 px-md">
<div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-surface-container text-on-surface font-label-sm text-label-sm">
<span className="material-symbols-outlined text-[14px]">credit_card</span> Card
                                    </div>
</td><td className="py-4 px-md"><span className="inline-flex items-center px-2.5 py-1 rounded-full bg-secondary-container/50 text-on-secondary-container font-label-sm text-label-sm">PAID</span></td>
<td className="py-4 px-md">
<span className="inline-flex items-center px-2.5 py-1 rounded-full bg-primary-fixed/50 text-on-primary-fixed font-label-sm text-label-sm">
                                        Processing
                                    </span>
</td>
<td className="py-4 px-md font-label-lg text-label-lg">$420.75</td>
<td className="py-4 px-lg text-right">
<button className="p-2 rounded-full hover:bg-surface-container text-on-surface-variant hover:text-primary transition-colors">
<span className="material-symbols-outlined text-[20px]">visibility</span>
</button>
</td>
</tr>
</tbody>
</table>
</div>
</div>

<div className="flex items-center justify-between w-full mt-sm">
<p className="font-body-sm text-body-sm text-on-surface-variant hidden sm:block">Showing 1 to 6 of 156 entries</p>
<div className="flex items-center gap-xs">
<button className="w-8 h-8 flex items-center justify-center rounded-md text-on-surface-variant hover:bg-surface-container transition-colors disabled:opacity-50">
<span className="material-symbols-outlined text-[20px]">chevron_left</span>
</button>
<button className="w-8 h-8 flex items-center justify-center rounded-md bg-primary text-on-primary font-label-sm text-label-sm">1</button>
<button className="w-8 h-8 flex items-center justify-center rounded-md hover:bg-surface-container text-on-surface font-label-sm text-label-sm transition-colors">2</button>
<button className="w-8 h-8 flex items-center justify-center rounded-md hover:bg-surface-container text-on-surface font-label-sm text-label-sm transition-colors">3</button>
<span className="w-8 h-8 flex items-center justify-center text-on-surface-variant font-label-sm text-label-sm">...</span>
<button className="w-8 h-8 flex items-center justify-center rounded-md hover:bg-surface-container text-on-surface font-label-sm text-label-sm transition-colors">26</button>
<button className="w-8 h-8 flex items-center justify-center rounded-md text-on-surface-variant hover:bg-surface-container transition-colors">
<span className="material-symbols-outlined text-[20px]">chevron_right</span>
</button>
</div>
</div>
</main>
  );
}