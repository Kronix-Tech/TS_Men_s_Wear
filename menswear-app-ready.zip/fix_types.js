const fs = require('fs');
const path = require('path');

function walk(dir) {
  const files = fs.readdirSync(dir);
  for (const file of files) {
    const fullPath = path.join(dir, file);
    if (fs.statSync(fullPath).isDirectory()) {
      walk(fullPath);
    } else if (fullPath.endsWith('.tsx') && !fullPath.includes('node_modules')) {
      let content = fs.readFileSync(fullPath, 'utf8');
      let originalContent = content;

      // Fix event handlers
      content = content.replace(/\sonsubmit=/g, ' onSubmit=');
      content = content.replace(/\sonclick=/g, ' onClick=');
      
      // Fix boolean string attributes
      content = content.replace(/\srequired="required"/g, ' required={true}');
      content = content.replace(/\srequired=""/g, ' required={true}');
      content = content.replace(/\schecked="checked"/g, ' defaultChecked={true}');
      content = content.replace(/\schecked=""/g, ' defaultChecked={true}');
      content = content.replace(/\sdisabled="disabled"/g, ' disabled={true}');
      content = content.replace(/\sdisabled=""/g, ' disabled={true}');
      content = content.replace(/\sselected="selected"/g, ' defaultValue={true}'); // rough fix
      
      // Fix number string attributes (like rows="4", cols="50", tabIndex="0", maxLength="50")
      content = content.replace(/\srows="(\d+)"/g, ' rows={$1}');
      content = content.replace(/\scols="(\d+)"/g, ' cols={$1}');
      content = content.replace(/\stabindex="(\d+)"/gi, ' tabIndex={$1}');
      content = content.replace(/\stabIndex="(\d+)"/g, ' tabIndex={$1}');
      content = content.replace(/\smaxlength="(\d+)"/gi, ' maxLength={$1}');
      content = content.replace(/\smaxLength="(\d+)"/g, ' maxLength={$1}');
      
      // specific error from contact us: rows and cols
      // Other numbers like stroke-width are svg props, they are handled differently, but React accepts strings for strokeWidth.

      if (content !== originalContent) {
        fs.writeFileSync(fullPath, content);
        console.log(`Fixed types in ${fullPath}`);
      }
    }
  }
}

walk('src/app');
