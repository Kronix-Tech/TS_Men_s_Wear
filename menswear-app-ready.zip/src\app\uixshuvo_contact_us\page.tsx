export default function UixshuvoContactUs() {
  return (
    <main className="flex-grow pt-[120px] pb-stack-lg max-w-container-max mx-auto px-margin-desktop w-full">

<nav className="mb-12 font-label-sm text-label-sm uppercase tracking-widest text-on-surface-variant">
<a className="hover:text-primary transition-colors" href="#">Home</a>
<span className="mx-2">/</span>
<span className="text-primary">Contact Us</span>
</nav>

<section className="text-center mb-stack-lg max-w-3xl mx-auto">
<h1 className="font-display-lg text-display-lg uppercase mb-6 text-primary tracking-widest">WE'RE HERE TO HELP</h1>
<p className="font-body-lg text-body-lg text-on-surface-variant">
                Whether you have a question about our collections, need assistance with an order, or just want to share your thoughts, our team is ready to assist you.
            </p>
</section>

<section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-gutter mb-stack-lg">
<div className="bg-white rounded-card p-8 shadow-ambient hover:shadow-ambient-hover transition-all duration-500 hover:-translate-y-1 flex flex-col items-center text-center group">
<div className="w-12 h-12 rounded-full bg-[#F5F4F8] flex items-center justify-center mb-6 group-hover:bg-[#8FB0A4] transition-colors duration-300">
<span className="material-symbols-outlined text-[#8FB0A4] group-hover:text-white transition-colors duration-300">mail</span>
</div>
<h3 className="font-label-sm text-label-sm uppercase tracking-widest mb-3 text-on-surface-variant">EMAIL</h3>
<a className="font-body-lg text-body-lg text-primary hover:underline underline-offset-4 decoration-1" href="mailto:support@menswear.com">support@menswear.com</a>
</div>
<div className="bg-white rounded-card p-8 shadow-ambient hover:shadow-ambient-hover transition-all duration-500 hover:-translate-y-1 flex flex-col items-center text-center group">
<div className="w-12 h-12 rounded-full bg-[#F5F4F8] flex items-center justify-center mb-6 group-hover:bg-[#8FB0A4] transition-colors duration-300">
<span className="material-symbols-outlined text-[#8FB0A4] group-hover:text-white transition-colors duration-300">phone</span>
</div>
<h3 className="font-label-sm text-label-sm uppercase tracking-widest mb-3 text-on-surface-variant">PHONE</h3>
<a className="font-body-lg text-body-lg text-primary hover:underline underline-offset-4 decoration-1" href="tel:+15551234567">+1 555-123-4567</a>
</div>
<div className="bg-white rounded-card p-8 shadow-ambient hover:shadow-ambient-hover transition-all duration-500 hover:-translate-y-1 flex flex-col items-center text-center group">
<div className="w-12 h-12 rounded-full bg-[#F5F4F8] flex items-center justify-center mb-6 group-hover:bg-[#8FB0A4] transition-colors duration-300">
<span className="material-symbols-outlined text-[#8FB0A4] group-hover:text-white transition-colors duration-300">storefront</span>
</div>
<h3 className="font-label-sm text-label-sm uppercase tracking-widest mb-3 text-on-surface-variant">FLAGSHIP STORE</h3>
<p className="font-body-lg text-body-lg text-primary">123 Maple St,<br />New York, NY 10001</p>
</div>
<div className="bg-white rounded-card p-8 shadow-ambient hover:shadow-ambient-hover transition-all duration-500 hover:-translate-y-1 flex flex-col items-center text-center group">
<div className="w-12 h-12 rounded-full bg-[#F5F4F8] flex items-center justify-center mb-6 group-hover:bg-[#8FB0A4] transition-colors duration-300">
<span className="material-symbols-outlined text-[#8FB0A4] group-hover:text-white transition-colors duration-300">schedule</span>
</div>
<h3 className="font-label-sm text-label-sm uppercase tracking-widest mb-3 text-on-surface-variant">HOURS</h3>
<p className="font-body-lg text-body-lg text-primary">Mon–Sat<br />9am–7pm</p>
</div>
</section>

<section className="grid grid-cols-1 lg:grid-cols-2 gap-gutter">

<div className="bg-white rounded-card p-12 shadow-ambient">
<h2 className="font-headline-md text-headline-md mb-8 text-primary">Send a Message</h2>
<form className="space-y-8">
<div className="grid grid-cols-1 md:grid-cols-2 gap-8">
<div>
<input className="w-full input-border" id="name" name="name" placeholder="Your Name" required={true} type="text" />
</div>
<div>
<input className="w-full input-border" id="email" name="email" placeholder="Your Email" required={true} type="email" />
</div>
</div>
<div>
<select className="w-full input-border text-on-surface-variant appearance-none cursor-pointer" id="subject" name="subject">
<option disabled={true} value="">Select Subject</option>
<option value="order">Order Inquiry</option>
<option value="returns">Returns &amp; Exchanges</option>
<option value="styling">Styling Advice</option>
<option value="other">Other</option>
</select>
</div>
<div>
<textarea className="w-full input-border resize-none" id="message" name="message" placeholder="Your Message" required={true} rows={4}></textarea>
</div>
<button className="bg-[#141414] text-white rounded-full px-8 py-4 font-body-md text-body-md font-medium flex items-center justify-center gap-3 hover:bg-black transition-colors duration-300 w-full md:w-auto" type="submit">
                        SEND MESSAGE <span className="text-xl leading-none font-light">→</span>
</button>
</form>
</div>

<div className="flex flex-col gap-gutter h-full">
<div className="bg-[#E7E5EE] rounded-card flex-grow min-h-[400px] relative overflow-hidden shadow-ambient group" data-alt="A highly detailed, sophisticated monochromatic map of central New York City. The map uses a minimalist palette of soft muted greys, crisp white, and subtle lavender-white undertones, aligning with a high-end luxury editorial aesthetic. The cartography is elegant and simplified, focusing on major arteries and prominent parks. The lighting is high-key and soft. The overall mood is urban, refined, and calm." data-location="New York" style={{"backgroundImage": "url('https://lh3.googleusercontent.com/aida-public/AB6AXuAbhYzfbIKyMqhxl8NEYchMxDXSNeHP1MaIFBxlHUfXnL9WGVZXD2cOiD22euJoUyJhxu-Rgfq0dMMmZfKihiEd3mli1LGAVxT00BH1BExALlfO61PpjZ9ZtW-hT4Jk165Jk-atDEEiyyn557hG2mWgAElwlLoJsPfaco3bDP9cX3x_yMYoGpAPRk3QzBR4LWS3ZC4CDxkot_F343jcfLza362FH8dYRZLBhnlmnieY_iKZE5GEK6rGxw')"}}>
<div className="absolute inset-0 bg-black/5 group-hover:bg-transparent transition-colors duration-500 backdrop-grayscale"></div>
<div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-lg animate-bounce">
<span className="material-symbols-outlined text-[#141414]" style={{"fontVariationSettings": "&quot","color": "rgb(143, 176, 164)"}}>location_on</span>
</div>
</div>
<div className="bg-white rounded-card p-8 shadow-ambient flex flex-col md:flex-row items-center justify-between gap-6">
<div>
<h3 className="font-headline-md text-headline-md text-primary mb-2">Need immediate assistance?</h3>
<p className="font-body-md text-body-md text-on-surface-variant">Our team is available on WhatsApp.</p>
</div>
<button className="border border-[#141414] text-[#141414] rounded-full px-8 py-4 font-body-md text-body-md font-medium hover:bg-[#141414] hover:text-white transition-colors duration-300 whitespace-nowrap">
                        CHAT ON WHATSAPP
                    </button>
</div>
</div>
</section>
</main>
  );
}