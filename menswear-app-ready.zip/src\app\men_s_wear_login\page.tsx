export default function MenSWearLogin() {
  return (
    <main className="flex-grow flex items-center justify-center py-stack-md px-margin-mobile md:px-margin-desktop w-full max-w-container-max mx-auto">
<div className="w-full max-w-[1200px] bg-surface-container-lowest rounded-[24px] overflow-hidden flex flex-col md:flex-row custom-shadow min-h-[700px]">

<div className="hidden md:flex md:w-1/2 relative bg-surface-variant overflow-hidden group">
<img alt="Editorial Image" className="w-full h-full object-cover transition-transform duration-700 ease-in-out group-hover:scale-105" src="https://lh3.googleusercontent.com/aida-public/AB6AXuA62C2Gwm9MQFp1ZbjGXhPgWoMXIBc8ndnadZlm2Eglqnjz5s2jU8PkZLL_0MPQSVNroX5O8ey1HHxUAS6y8rAf17_0bttclz4OWI-i0znn57tifoYiAh8KVRi10OjApPzRerEelHaTvyq88Vn7VGdHyU4R2qJqi-RqM7B0lW3k0FGehK2yrl-t8LMGIbeaM8M6khNuRbL6oKPTuQIufLXZN66rza45vWxovkJTL-V6B4l3p09ZrMkMRg" />
<div className="absolute inset-0 bg-gradient-to-t from-[#8FB0A4]/80 to-transparent mix-blend-multiply"></div>
<div className="absolute inset-0 flex items-center justify-center p-stack-md text-center z-10">
<h2 className="font-display-lg text-headline-lg text-on-primary max-w-md uppercase">Dress With Confidence</h2>
</div>
</div>

<div className="w-full md:w-1/2 flex flex-col justify-center px-gutter py-stack-md md:p-stack-lg bg-surface-container-lowest relative z-20">
<div className="max-w-md mx-auto w-full">

<h1 className="font-headline-lg-mobile md:font-headline-lg text-headline-lg-mobile md:text-headline-lg text-primary uppercase mb-gutter text-center">Welcome Back</h1>

<div className="flex border-b border-outline-variant mb-stack-md">
<button className="flex-1 pb-unit font-body-md text-body-md text-primary font-bold border-b-2 border-primary uppercase tracking-widest text-center">Login</button>
<button className="flex-1 pb-unit font-body-md text-body-md text-on-surface-variant hover:text-primary transition-colors uppercase tracking-widest text-center">Register</button>
</div>

<form className="space-y-gutter">
<div>
<label className="sr-only" htmlFor="email">Email</label>
<input className="w-full border-0 border-b border-outline-variant bg-transparent px-0 py-unit font-body-md text-body-md focus:ring-0 focus:border-primary transition-colors placeholder:text-on-surface-variant/50" id="email" placeholder="Email Address" type="email" />
</div>
<div className="relative">
<label className="sr-only" htmlFor="password">Password</label>
<input className="w-full border-0 border-b border-outline-variant bg-transparent px-0 py-unit font-body-md text-body-md focus:ring-0 focus:border-primary transition-colors placeholder:text-on-surface-variant/50" id="password" placeholder="Password" type="password" />
<button className="absolute right-0 top-1/2 -translate-y-1/2 text-on-surface-variant hover:text-primary transition-colors" type="button">
<span className="material-symbols-outlined">visibility</span>
</button>
</div>

<div className="flex items-center justify-between pt-unit">
<label className="flex items-center space-x-2 cursor-pointer">
<input className="form-checkbox h-4 w-4 text-primary border-outline-variant rounded focus:ring-primary" type="checkbox" />
<span className="font-body-md text-label-sm text-[#6E6E75]">Remember me</span>
</label>
<a className="font-body-md text-label-sm text-[#6E6E75] hover:text-primary transition-colors" href="#">Forgot password?</a>
</div>

<div className="pt-unit">
<button className="w-full bg-[#141414] text-on-primary font-body-md text-body-md py-3 rounded-full flex items-center justify-center group hover:opacity-90 transition-opacity duration-300" type="submit">
                                SIGN IN 
                                <span className="material-symbols-outlined ml-2 text-[18px] group-hover:translate-x-1 transition-transform">arrow_forward</span>
</button>
</div>
</form>

<div className="mt-stack-md">
<div className="relative">
<div className="absolute inset-0 flex items-center">
<div className="w-full border-t border-outline-variant"></div>
</div>
<div className="relative flex justify-center text-sm">
<span className="px-2 bg-surface-container-lowest font-body-md text-label-sm text-on-surface-variant uppercase">or continue with</span>
</div>
</div>
<div className="mt-gutter grid grid-cols-2 gap-4">
<button className="flex items-center justify-center px-4 py-2 border border-[#141414] rounded-full bg-transparent hover:bg-surface-variant transition-colors duration-200">
<span className="font-body-md text-label-sm text-primary uppercase">Google</span>
</button>
<button className="flex items-center justify-center px-4 py-2 border border-[#141414] rounded-full bg-transparent hover:bg-surface-variant transition-colors duration-200">
<span className="font-body-md text-label-sm text-primary uppercase">Facebook</span>
</button>
</div>
</div>

<div className="mt-stack-md text-center">
<p className="font-body-md text-label-sm text-[#6E6E75]">By continuing you agree to our Terms &amp; Privacy Policy.</p>
</div>
</div>
</div>
</div>
</main>
  );
}