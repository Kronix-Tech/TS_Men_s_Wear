export default function UixshuvoShopAllLeftLogoHeader() {
  return (
    <main className="flex-grow w-full max-w-container-max mx-auto px-margin-mobile md:px-margin-desktop py-stack-md flex flex-col gap-stack-md">

<header className="flex flex-col gap-4 items-center text-center"><div className="flex items-center justify-between w-full h-16">

<div className="flex-shrink-0">
<a className="font-display-lg text-headline-lg text-primary dark:text-on-primary tracking-tighter hover:opacity-70 transition-opacity duration-300" href="#">MEN'S WEAR</a>
</div>

<nav className="hidden lg:flex items-center gap-8">
<a className="text-on-surface-variant hover:text-primary transition-colors font-body-md text-label-sm uppercase tracking-widest" href="#">New Arrivals</a>
<a className="text-primary font-bold border-b-2 border-primary pb-1 hover:opacity-70 transition-opacity duration-300 font-body-md text-label-sm uppercase tracking-widest" href="#">Shop All</a>
<a className="text-on-surface-variant hover:text-primary transition-colors font-body-md text-label-sm uppercase tracking-widest" href="#">Collections</a>
<a className="text-on-surface-variant hover:text-primary transition-colors font-body-md text-label-sm uppercase tracking-widest" href="#">Blog</a>
<a className="text-on-surface-variant hover:text-primary transition-colors font-body-md text-label-sm uppercase tracking-widest" href="#">Contact</a>
</nav>

<div className="flex items-center gap-6">
<div className="relative hidden md:block">
<input className="bg-surface-container border-none rounded-full py-2 px-4 pl-10 text-sm focus:ring-1 focus:ring-brand-sage w-48" placeholder="Search..." type="text" />
<span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-on-surface-variant text-sm">search</span>
</div>
<div className="flex items-center gap-4 text-primary dark:text-on-primary">
<button className="md:hidden hover:opacity-70 transition-opacity duration-300"><span className="material-symbols-outlined">search</span></button>
<a className="hover:opacity-70 transition-opacity duration-300" href="#"><span className="material-symbols-outlined">favorite</span></a>
<a className="hover:opacity-70 transition-opacity duration-300" href="#"><span className="material-symbols-outlined">shopping_bag</span></a>
<a className="hover:opacity-70 transition-opacity duration-300" href="#"><span className="material-symbols-outlined">person</span></a>
</div>
</div>
</div></header>

<div className="flex flex-col lg:flex-row gap-gutter relative">

<aside className="w-full lg:w-[320px] shrink-0 lg:sticky lg:top-[100px] lg:h-[calc(100vh-120px)] overflow-y-auto no-scrollbar pb-8">
<div className="bg-surface rounded-[24px] p-6 ambient-shadow flex flex-col gap-8">
<div className="flex justify-between items-center border-b border-surface-variant pb-4">
<h2 className="font-headline-md text-headline-md">Filters</h2>
<button className="font-label-sm text-label-sm uppercase underline text-on-surface-variant hover:text-primary transition-colors">Clear all</button>
</div>

<div className="flex flex-col gap-3 border-b border-surface-variant pb-6">
<h3 className="font-body-lg font-medium">Categories</h3>
<div className="flex flex-col gap-2">
<label className="flex items-center gap-3 cursor-pointer group">
<input className="rounded border-outline-variant text-brand-sage focus:ring-brand-sage w-5 h-5 bg-transparent" type="checkbox" />
<span className="font-body-md group-hover:text-brand-sage transition-colors">Shirts</span>
</label>
<label className="flex items-center gap-3 cursor-pointer group">
<input className="rounded border-outline-variant text-brand-sage focus:ring-brand-sage w-5 h-5 bg-transparent" type="checkbox" />
<span className="font-body-md group-hover:text-brand-sage transition-colors">T-Shirts</span>
</label>
<label className="flex items-center gap-3 cursor-pointer group">
<input className="rounded border-outline-variant text-brand-sage focus:ring-brand-sage w-5 h-5 bg-transparent" type="checkbox" />
<span className="font-body-md group-hover:text-brand-sage transition-colors">Polo</span>
</label>
<label className="flex items-center gap-3 cursor-pointer group">
<input className="rounded border-outline-variant text-brand-sage focus:ring-brand-sage w-5 h-5 bg-transparent" type="checkbox" />
<span className="font-body-md group-hover:text-brand-sage transition-colors">Jeans</span>
</label>
<label className="flex items-center gap-3 cursor-pointer group">
<input className="rounded border-outline-variant text-brand-sage focus:ring-brand-sage w-5 h-5 bg-transparent" type="checkbox" />
<span className="font-body-md group-hover:text-brand-sage transition-colors">Trousers</span>
</label>
<label className="flex items-center gap-3 cursor-pointer group">
<input className="rounded border-outline-variant text-brand-sage focus:ring-brand-sage w-5 h-5 bg-transparent" type="checkbox" />
<span className="font-body-md group-hover:text-brand-sage transition-colors">Ethnic</span>
</label>
<label className="flex items-center gap-3 cursor-pointer group">
<input className="rounded border-outline-variant text-brand-sage focus:ring-brand-sage w-5 h-5 bg-transparent" type="checkbox" />
<span className="font-body-md group-hover:text-brand-sage transition-colors">Winter</span>
</label>
</div>
</div>

<div className="flex flex-col gap-3 border-b border-surface-variant pb-6">
<h3 className="font-body-lg font-medium">Size</h3>
<div className="flex flex-wrap gap-2">
<button className="w-10 h-10 rounded-full border border-outline-variant flex items-center justify-center font-body-md hover:border-primary hover:bg-primary hover:text-white transition-all">S</button>
<button className="w-10 h-10 rounded-full border border-outline-variant flex items-center justify-center font-body-md hover:border-primary hover:bg-primary hover:text-white transition-all">M</button>
<button className="w-10 h-10 rounded-full border border-primary bg-primary text-white flex items-center justify-center font-body-md transition-all">L</button>
<button className="w-10 h-10 rounded-full border border-outline-variant flex items-center justify-center font-body-md hover:border-primary hover:bg-primary hover:text-white transition-all">XL</button>
<button className="w-10 h-10 rounded-full border border-outline-variant flex items-center justify-center font-body-md hover:border-primary hover:bg-primary hover:text-white transition-all">XXL</button>
</div>
</div>

<div className="flex flex-col gap-3 border-b border-surface-variant pb-6">
<h3 className="font-body-lg font-medium">Color</h3>
<div className="flex flex-wrap gap-3">
<button aria-label="Black" className="w-8 h-8 rounded-full bg-black ring-2 ring-offset-2 ring-transparent hover:ring-outline-variant transition-all focus:ring-primary focus:outline-none"></button>
<button aria-label="White" className="w-8 h-8 rounded-full bg-white border border-outline-variant ring-2 ring-offset-2 ring-transparent hover:ring-outline-variant transition-all focus:ring-primary focus:outline-none"></button>
<button aria-label="Navy" className="w-8 h-8 rounded-full bg-[#000080] ring-2 ring-offset-2 ring-transparent hover:ring-outline-variant transition-all focus:ring-primary focus:outline-none"></button>
<button aria-label="Grey" className="w-8 h-8 rounded-full bg-gray-500 ring-2 ring-offset-2 ring-transparent hover:ring-outline-variant transition-all focus:ring-primary focus:outline-none"></button>
<button aria-label="Sage" className="w-8 h-8 rounded-full bg-brand-sage ring-2 ring-offset-2 ring-transparent hover:ring-outline-variant transition-all focus:ring-primary focus:outline-none"></button>
<button aria-label="Beige" className="w-8 h-8 rounded-full bg-[#F5F5DC] border border-outline-variant ring-2 ring-offset-2 ring-transparent hover:ring-outline-variant transition-all focus:ring-primary focus:outline-none"></button>
</div>
</div>

<div className="flex flex-col gap-3 border-b border-surface-variant pb-6">
<h3 className="font-body-lg font-medium">Price</h3>
<input className="w-full h-1 bg-surface-variant rounded-lg appearance-none cursor-pointer" max="1000" min="0" type="range" value="500" />
<div className="flex justify-between font-label-sm text-on-surface-variant">
<span className="">$0</span>
<span className="">$1000+</span>
</div>
</div>

<div className="flex flex-col gap-3 border-b border-surface-variant pb-6">
<h3 className="font-body-lg font-medium">Fabric</h3>
<div className="flex flex-col gap-2">
<label className="flex items-center gap-3 cursor-pointer group">
<input className="rounded border-outline-variant text-brand-sage focus:ring-brand-sage w-5 h-5 bg-transparent" type="checkbox" />
<span className="font-body-md group-hover:text-brand-sage transition-colors">Cotton</span>
</label>
<label className="flex items-center gap-3 cursor-pointer group">
<input className="rounded border-outline-variant text-brand-sage focus:ring-brand-sage w-5 h-5 bg-transparent" type="checkbox" />
<span className="font-body-md group-hover:text-brand-sage transition-colors">Linen</span>
</label>
<label className="flex items-center gap-3 cursor-pointer group">
<input className="rounded border-outline-variant text-brand-sage focus:ring-brand-sage w-5 h-5 bg-transparent" type="checkbox" />
<span className="font-body-md group-hover:text-brand-sage transition-colors">Denim</span>
</label>
<label className="flex items-center gap-3 cursor-pointer group">
<input className="rounded border-outline-variant text-brand-sage focus:ring-brand-sage w-5 h-5 bg-transparent" type="checkbox" />
<span className="font-body-md group-hover:text-brand-sage transition-colors">Wool</span>
</label>
</div>
</div>

<div className="flex flex-col gap-3 border-b border-surface-variant pb-6">
<h3 className="font-body-lg font-medium">Fit</h3>
<div className="flex flex-wrap gap-2">
<button className="px-4 py-2 rounded-full border border-outline-variant font-body-md hover:border-primary hover:bg-primary hover:text-white transition-all">Slim</button>
<button className="px-4 py-2 rounded-full border border-outline-variant font-body-md hover:border-primary hover:bg-primary hover:text-white transition-all">Regular</button>
<button className="px-4 py-2 rounded-full border border-outline-variant font-body-md hover:border-primary hover:bg-primary hover:text-white transition-all">Loose</button>
</div>
</div>

<div className="flex flex-col gap-3 border-b border-surface-variant pb-6">
<h3 className="font-body-lg font-medium">Discount</h3>
<div className="flex flex-wrap gap-2">
<button className="px-4 py-2 rounded-full border border-outline-variant font-body-md hover:border-primary hover:bg-primary hover:text-white transition-all">10%+</button>
<button className="px-4 py-2 rounded-full border border-outline-variant font-body-md hover:border-primary hover:bg-primary hover:text-white transition-all">20%+</button>
<button className="px-4 py-2 rounded-full border border-outline-variant font-body-md hover:border-primary hover:bg-primary hover:text-white transition-all">30%+</button>
</div>
</div>

<div className="flex items-center justify-between pb-6">
<h3 className="font-body-lg font-medium">In-stock</h3>
<div className="relative inline-block w-12 mr-2 align-middle select-none transition duration-200 ease-in">
<input className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer" id="toggle" name="toggle" type="checkbox" />
<label className="toggle-label block overflow-hidden h-6 rounded-full bg-surface-variant cursor-pointer" htmlFor="toggle"></label>
</div>
</div>
<button className="w-full bg-brand-black text-white font-body-md py-3 rounded-full flex items-center justify-center gap-2 hover:opacity-80 transition-opacity">
                        APPLY FILTERS <span className="material-symbols-outlined text-sm">arrow_forward</span>
</button>
</div>
</aside>

<section className="flex-grow flex flex-col gap-6 w-full">

<div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-surface rounded-[24px] p-4 ambient-shadow">
<div className="flex flex-wrap gap-2">
<span className="bg-brand-lilac px-3 py-1 rounded-full font-label-sm text-label-sm uppercase flex items-center gap-1">Size: L <button className="hover:text-primary"><span className="material-symbols-outlined text-[14px]">close</span></button></span>
<span className="bg-brand-lilac px-3 py-1 rounded-full font-label-sm text-label-sm uppercase flex items-center gap-1">Color: Sage <button className="hover:text-primary"><span className="material-symbols-outlined text-[14px]">close</span></button></span>
</div>
<div className="flex items-center gap-4">
<div className="relative">
<select className="appearance-none bg-transparent border-none py-2 pl-4 pr-8 font-body-md cursor-pointer focus:ring-0">
<option>Sort by: Newest</option>
<option>Price: Low to High</option>
<option>Price: High to Low</option>
</select>
<span className="material-symbols-outlined absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none">expand_more</span>
</div>
<div className="hidden sm:flex border-l border-surface-variant pl-4 gap-2">
<button className="text-primary"><span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1"}}>grid_view</span></button>
<button className="text-outline-variant hover:text-primary transition-colors"><span className="material-symbols-outlined">view_list</span></button>
</div>
</div>
</div>

<div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-gutter">

<div className="product-card flex flex-col gap-3 group relative cursor-pointer hover-lift rounded-[24px] bg-surface p-3 pb-4">
<div className="relative product-image-container h-[300px] w-full bg-surface-container rounded-xl overflow-hidden">
<img className="w-full h-full object-cover" data-alt="A male model standing in a bright minimalist studio wearing a tailored sage green linen shirt. High key lighting, editorial fashion style, crisp neutral background, soft ambient shadows." src="https://lh3.googleusercontent.com/aida-public/AB6AXuBxgGzUqq2CiqWpbdmms2LvY91YJkepmBzaYHZVMF04tIytDBg10_ssstBrDIsZ1HC0MD_aFaI2AYVismej_QRO_Z4hfXqXXIqOJUNHhl1zH629SaNHDR6FmMlEqVM-d5kmtmK5CrcRnqbcx86gxeh3w461JGe2t-HE2I4-4lP0DJJOHjQavJ8uKmTMkd69P3pAWKOgf6XTZrSUTiELwneDVkc5CHKP4hYWaANgZTbcWwgnm-CNrtrFUA" />
<div className="absolute top-3 left-3 flex flex-col gap-2 z-10">
<span className="bg-white px-2 py-1 rounded-full font-label-sm text-label-sm uppercase shadow-sm">NEW</span>
<span className="bg-brand-sage text-white px-2 py-1 rounded-full font-label-sm text-label-sm uppercase shadow-sm">-20%</span>
</div>
<button className="absolute top-3 right-3 w-8 h-8 bg-white/80 backdrop-blur rounded-full flex items-center justify-center hover:bg-white transition-colors z-10 text-on-surface">
<span className="material-symbols-outlined text-sm">favorite</span>
</button>
<button className="absolute bottom-3 right-3 w-10 h-10 bg-brand-black text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 translate-y-4 group-hover:translate-y-0 transition-all z-10">
<span className="material-symbols-outlined text-sm">shopping_bag</span>
</button>
</div>
<div className="flex flex-col gap-1 px-1">
<span className="font-label-sm text-on-surface-variant uppercase tracking-widest text-[10px]">Shirts</span>
<h3 className="font-body-lg text-body-lg leading-tight truncate">Sage Linen Shirt</h3>
<div className="flex items-center gap-1 text-[#FFD700]">
<span className="material-symbols-outlined text-[14px]" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-[14px]" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-[14px]" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-[14px]" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-[14px]">star_half</span>
<span className="font-label-sm text-on-surface-variant ml-1">(42)</span>
</div>
<div className="flex items-center gap-2 mt-1">
<span className="font-body-md font-medium">$85.00</span>
<span className="font-body-md text-on-surface-variant line-through text-sm">$105.00</span>
</div>
</div>
</div>

<div className="product-card flex flex-col gap-3 group relative cursor-pointer hover-lift rounded-[24px] bg-surface p-3 pb-4">
<div className="relative product-image-container h-[300px] w-full bg-surface-container rounded-xl overflow-hidden">
<img className="w-full h-full object-cover" data-alt="A folded stack of premium heavyweight cotton t-shirts in neutral tones on a clean marble surface. Soft natural lighting, minimalist high-end retail aesthetic, shallow depth of field." src="https://lh3.googleusercontent.com/aida-public/AB6AXuAgNxcvobwp1FSKqGUe0jr8tIdiXIahHXgbOrQC2H01wFOYzOx4HLds03OhUa_2NJedervZZpesGaL0iYRZsZOOwnkwRrinK4ADo5QjbRCq5MGy7LU0bru4uUrRYD3yGbXROnoXCrlidSKGl7J5ADoeiYTrdgR353K5828sK2pG0heb7TgUIovsz8KABnJC5SEEKQJr5WLjBsLNxlBPgdB_s5rF7dBsPorSyn51Fv6S283i1LcHXiCQgg" />
<button className="absolute top-3 right-3 w-8 h-8 bg-white/80 backdrop-blur rounded-full flex items-center justify-center hover:bg-white transition-colors z-10 text-on-surface">
<span className="material-symbols-outlined text-sm">favorite</span>
</button>
<button className="absolute bottom-3 right-3 w-10 h-10 bg-brand-black text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 translate-y-4 group-hover:translate-y-0 transition-all z-10">
<span className="material-symbols-outlined text-sm">shopping_bag</span>
</button>
</div>
<div className="flex flex-col gap-1 px-1">
<span className="font-label-sm text-on-surface-variant uppercase tracking-widest text-[10px]">T-Shirts</span>
<h3 className="font-body-lg text-body-lg leading-tight truncate">Heavyweight Tee</h3>
<div className="flex items-center gap-1 text-[#FFD700]">
<span className="material-symbols-outlined text-[14px]" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-[14px]" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-[14px]" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-[14px]" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-[14px]" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="font-label-sm text-on-surface-variant ml-1">(128)</span>
</div>
<div className="flex items-center gap-2 mt-1">
<span className="font-body-md font-medium">$45.00</span>
</div>
</div>
</div>

<div className="product-card flex flex-col gap-3 group relative cursor-pointer hover-lift rounded-[24px] bg-surface p-3 pb-4">
<div className="relative product-image-container h-[300px] w-full bg-surface-container rounded-xl overflow-hidden">
<img className="w-full h-full object-cover" data-alt="Close up shot of dark indigo selvedge denim jeans showing texture and stitching detail. Dramatic directional lighting highlighting the fabric weave, luxury minimalist presentation." src="https://lh3.googleusercontent.com/aida-public/AB6AXuDjTD-WW1zP2fvzGRu0knPSifWIFfm9qRXbujWL8ZW8aYgQmEUyQqWs_Z3PGSahgqPd4y3DFsiyMapcf3vEXRQm2p0peTtqJbdu0pswc3tTSQmmxp1fDXORQPgr9DMfVNWvK0jz_usRoNqSNZSB3OXpHMeLFwI9Hgmld2T2Gg3poDBDsfW-3CAl32fZbr3TmwD63Zyw4aglG3-cvCyn-gRyV53DlBOBQxy07_wwcMBk1DEgtSBLn3Wt7Q" />
<div className="absolute top-3 left-3 flex flex-col gap-2 z-10">
<span className="bg-white px-2 py-1 rounded-full font-label-sm text-label-sm uppercase shadow-sm">NEW</span>
</div>
<button className="absolute top-3 right-3 w-8 h-8 bg-white/80 backdrop-blur rounded-full flex items-center justify-center hover:bg-white transition-colors z-10 text-on-surface">
<span className="material-symbols-outlined text-sm">favorite</span>
</button>
<button className="absolute bottom-3 right-3 w-10 h-10 bg-brand-black text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 translate-y-4 group-hover:translate-y-0 transition-all z-10">
<span className="material-symbols-outlined text-sm">shopping_bag</span>
</button>
</div>
<div className="flex flex-col gap-1 px-1">
<span className="font-label-sm text-on-surface-variant uppercase tracking-widest text-[10px]">Jeans</span>
<h3 className="font-body-lg text-body-lg leading-tight truncate">Selvedge Jeans</h3>
<div className="flex items-center gap-1 text-[#FFD700]">
<span className="material-symbols-outlined text-[14px]" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-[14px]" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-[14px]" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-[14px]" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-[14px]">star_border</span>
<span className="font-label-sm text-on-surface-variant ml-1">(12)</span>
</div>
<div className="flex items-center gap-2 mt-1">
<span className="font-body-md font-medium">$145.00</span>
</div>
</div>
</div>

<div className="product-card flex flex-col gap-3 group relative cursor-pointer hover-lift rounded-[24px] bg-surface p-3 pb-4">
<div className="relative product-image-container h-[300px] w-full bg-surface-container rounded-xl overflow-hidden">
<img className="w-full h-full object-cover" data-alt="A man walking in a modern architectural setting wearing a tailored charcoal gray blazer and matching trousers. Sophisticated, quiet luxury vibe, soft diffused daylight." src="https://lh3.googleusercontent.com/aida-public/AB6AXuAaqJ-iojQ1YFdAjiF6r0QE_cCb-P7HJv-EJJbu9XXj7gSwcGbyxubejoWsDY6zbnSnyzf4WvClm1UT85MlsKpd8z0WyEPItuMRSajVWsuCUlmSzoEhCxFOpckv09Kt_IAyNqT-FwKJpH27DpNTL3zUYoSXHXXJZw2vcP2NMrVKRvL8WlF9XGdd0Aqyfhh_V1en6pcE6ca1GqxN-XS1caj-z6ZRblddIqompZDhuslc5-jsCGHyucWmNQ" />
<button className="absolute top-3 right-3 w-8 h-8 bg-white/80 backdrop-blur rounded-full flex items-center justify-center hover:bg-white transition-colors z-10 text-on-surface">
<span className="material-symbols-outlined text-sm">favorite</span>
</button>
<button className="absolute bottom-3 right-3 w-10 h-10 bg-brand-black text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 translate-y-4 group-hover:translate-y-0 transition-all z-10">
<span className="material-symbols-outlined text-sm">shopping_bag</span>
</button>
</div>
<div className="flex flex-col gap-1 px-1">
<span className="font-label-sm text-on-surface-variant uppercase tracking-widest text-[10px]">Trousers</span>
<h3 className="font-body-lg text-body-lg leading-tight truncate">Wool Trousers</h3>
<div className="flex items-center gap-1 text-[#FFD700]">
<span className="material-symbols-outlined text-[14px]" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-[14px]" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-[14px]" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-[14px]" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-[14px]" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="font-label-sm text-on-surface-variant ml-1">(89)</span>
</div>
<div className="flex items-center gap-2 mt-1">
<span className="font-body-md font-medium">$120.00</span>
</div>
</div>
</div>
</div>

<div className="w-full bg-brand-sage rounded-[24px] overflow-hidden relative min-h-[200px] flex items-center justify-center p-8 mt-4 mb-4 hover-lift cursor-pointer shadow-lg">

<div className="absolute inset-0 opacity-10 bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI4IiBoZWlnaHQ9IjgiPgo8cmVjdCB3aWR0aD0iOCIgaGVpZ2h0PSI4IiBmaWxsPSIjZmZmIj48L3JlY3Q+CjxwYXRoIGQ9Ik0wIDBMOCA4Wk04IDBMMCA4WiIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjEiPjwvcGF0aD4KPC9zdmc+')]"></div>
<div className="relative z-10 text-center flex flex-col items-center gap-4">
<h2 className="font-headline-md md:font-headline-lg text-white max-w-2xl">FLAT 40% OFF ON FORMAL WEAR — SHOP NOW</h2>
<button className="bg-white text-brand-black px-6 py-2 rounded-full font-label-sm uppercase hover:bg-surface-container transition-colors shadow-md">Explore Formal</button>
</div>
</div>

<div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-gutter">

<div className="product-card flex flex-col gap-3 group relative cursor-pointer hover-lift rounded-[24px] bg-surface p-3 pb-4">
<div className="relative product-image-container h-[300px] w-full bg-surface-container rounded-xl overflow-hidden">
<img className="w-full h-full object-cover" data-alt="A meticulously folded beige knit polo shirt resting on a textured stone plinth. Bright, soft studio lighting emphasizing the ribbed fabric texture, minimal and elegant composition." src="https://lh3.googleusercontent.com/aida-public/AB6AXuA6MiYgZCAmUfevEYeZq3w06lk58zWxv5jAXZIQkkKGz8W4Cqc8A5k6dZP01UwzWqDzOptfFq-ULgd8ATxovXA6CjKsnBV-792lNQR-RAzm-kY0EPgcv_7jCZmkmV2Hfo6p7o7HRUlWY304_Y_R0GF1_723f5NyjzL_fXXIllWuSS5k_WU-4d-tLulwhP2P7B1h64GKgYzM46KMuam53F6K3LkFwU5y-1Li14FxUGeviRsexWMZP8IBFQ" />
<button className="absolute top-3 right-3 w-8 h-8 bg-white/80 backdrop-blur rounded-full flex items-center justify-center hover:bg-white transition-colors z-10 text-on-surface">
<span className="material-symbols-outlined text-sm">favorite</span>
</button>
<button className="absolute bottom-3 right-3 w-10 h-10 bg-brand-black text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 translate-y-4 group-hover:translate-y-0 transition-all z-10">
<span className="material-symbols-outlined text-sm">shopping_bag</span>
</button>
</div>
<div className="flex flex-col gap-1 px-1">
<span className="font-label-sm text-on-surface-variant uppercase tracking-widest text-[10px]">Polo</span>
<h3 className="font-body-lg text-body-lg leading-tight truncate">Ribbed Knit Polo</h3>
<div className="flex items-center gap-1 text-[#FFD700]">
<span className="material-symbols-outlined text-[14px]" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-[14px]" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-[14px]" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-[14px]" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-[14px]">star_border</span>
<span className="font-label-sm text-on-surface-variant ml-1">(24)</span>
</div>
<div className="flex items-center gap-2 mt-1">
<span className="font-body-md font-medium">$75.00</span>
</div>
</div>
</div>

<div className="product-card flex flex-col gap-3 group relative cursor-pointer hover-lift rounded-[24px] bg-surface p-3 pb-4">
<div className="relative product-image-container h-[300px] w-full bg-surface-container rounded-xl overflow-hidden">
<img className="w-full h-full object-cover" data-alt="A meticulously folded beige knit polo shirt resting on a textured stone plinth. Bright, soft studio lighting emphasizing the ribbed fabric texture, minimal and elegant composition." src="https://lh3.googleusercontent.com/aida-public/AB6AXuDm5VJ0pk-YGvaq_DkB6hLnM0Q7Cntoca4pAO7uaxm_GS-gtlmmn37278682LTvb8GmN_Q8CPCKI92dcV8nfl5bAtcaadZMhniViDkrRDA9MS9-juttOETdS_eOxPxifHB4u311tgR_OVuL6eOYfZ-0omBLAkIzcCSHn8AdHE5z9Hg-lt1j7gw4vFAlxd0gGth37lIMa9-wHzMJog0-0WkSYmoVOy__j7g_YZNHa3TajgnRnGE33JO8MQ" />
<button className="absolute top-3 right-3 w-8 h-8 bg-white/80 backdrop-blur rounded-full flex items-center justify-center hover:bg-white transition-colors z-10 text-on-surface">
<span className="material-symbols-outlined text-sm">favorite</span>
</button>
<button className="absolute bottom-3 right-3 w-10 h-10 bg-brand-black text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 translate-y-4 group-hover:translate-y-0 transition-all z-10">
<span className="material-symbols-outlined text-sm">shopping_bag</span>
</button>
</div>
<div className="flex flex-col gap-1 px-1">
<span className="font-label-sm text-on-surface-variant uppercase tracking-widest text-[10px]">Shirts</span>
<h3 className="font-body-lg text-body-lg leading-tight truncate">Oxford Shirt</h3>
<div className="flex items-center gap-1 text-[#FFD700]">
<span className="material-symbols-outlined text-[14px]" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-[14px]" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-[14px]" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-[14px]" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-[14px]">star_border</span>
<span className="font-label-sm text-on-surface-variant ml-1">(34)</span>
</div>
<div className="flex items-center gap-2 mt-1">
<span className="font-body-md font-medium">$95.00</span>
</div>
</div>
</div>

<div className="product-card flex flex-col gap-3 group relative cursor-pointer hover-lift rounded-[24px] bg-surface p-3 pb-4">
<div className="relative product-image-container h-[300px] w-full bg-surface-container rounded-xl overflow-hidden">
<img className="w-full h-full object-cover" data-alt="A meticulously folded beige knit polo shirt resting on a textured stone plinth. Bright, soft studio lighting emphasizing the ribbed fabric texture, minimal and elegant composition." src="https://lh3.googleusercontent.com/aida-public/AB6AXuBTUvg9c9k_L857cL4XC_TOKQfHb5HYaLuLSPpbKEnU99dItboy7a2GGZEemWwBQzUEgLTdj2zGnKehxOcll1DGR7REe_SEyA7OSVtIW3_iLZ_yQZ6E7HvpbzOywd9BkGqsIBxREncN3KODKPKKr1986EB2kiWVZUcp0G27L2ahnT8DcDjs1EnMhCFqa0eRFgCJwfrq0tmkB3MgBOIT0BhhZyGyfhT4y39RzISLpxj9IBVEr5EcZub0Tg" />
<button className="absolute top-3 right-3 w-8 h-8 bg-white/80 backdrop-blur rounded-full flex items-center justify-center hover:bg-white transition-colors z-10 text-on-surface">
<span className="material-symbols-outlined text-sm">favorite</span>
</button>
<button className="absolute bottom-3 right-3 w-10 h-10 bg-brand-black text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 translate-y-4 group-hover:translate-y-0 transition-all z-10">
<span className="material-symbols-outlined text-sm">shopping_bag</span>
</button>
</div>
<div className="flex flex-col gap-1 px-1">
<span className="font-label-sm text-on-surface-variant uppercase tracking-widest text-[10px]">Trousers</span>
<h3 className="font-body-lg text-body-lg leading-tight truncate">Cargo Trousers</h3>
<div className="flex items-center gap-1 text-[#FFD700]">
<span className="material-symbols-outlined text-[14px]" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-[14px]" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-[14px]" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-[14px]" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-[14px]">star_border</span>
<span className="font-label-sm text-on-surface-variant ml-1">(52)</span>
</div>
<div className="flex items-center gap-2 mt-1">
<span className="font-body-md font-medium">$115.00</span>
</div>
</div>
</div>

<div className="product-card flex flex-col gap-3 group relative cursor-pointer hover-lift rounded-[24px] bg-surface p-3 pb-4">
<div className="relative product-image-container h-[300px] w-full bg-surface-container rounded-xl overflow-hidden">
<img className="w-full h-full object-cover" data-alt="A meticulously folded beige knit polo shirt resting on a textured stone plinth. Bright, soft studio lighting emphasizing the ribbed fabric texture, minimal and elegant composition." src="https://lh3.googleusercontent.com/aida-public/AB6AXuAIonhzCFOBQXRfxtorJ5R4TdO14y7fi_HFt1Uhlg440dIJBxhHmiQTCs73vjUK6J-951AAW-dXJoU3f_Mea_B3pzoCtZsPmHLg4lZvQ1japr1vVD2PKCyCusY1mTLHmrKcLbSuqR8Iynk3EQbCyGjlKhROCDgxV2i7rLfBpm1b7cK-1qRqWjprXI3pSIGtFbmioeInvAyxFuUT9LYnN8HVy87-S8qpag3bbbsflrezYzb3NDhzNRLkmw" />
<button className="absolute top-3 right-3 w-8 h-8 bg-white/80 backdrop-blur rounded-full flex items-center justify-center hover:bg-white transition-colors z-10 text-on-surface">
<span className="material-symbols-outlined text-sm">favorite</span>
</button>
<button className="absolute bottom-3 right-3 w-10 h-10 bg-brand-black text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 translate-y-4 group-hover:translate-y-0 transition-all z-10">
<span className="material-symbols-outlined text-sm">shopping_bag</span>
</button>
</div>
<div className="flex flex-col gap-1 px-1">
<span className="font-label-sm text-on-surface-variant uppercase tracking-widest text-[10px]">Winter</span>
<h3 className="font-body-lg text-body-lg leading-tight truncate">Wool Overcoat</h3>
<div className="flex items-center gap-1 text-[#FFD700]">
<span className="material-symbols-outlined text-[14px]" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-[14px]" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-[14px]" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-[14px]" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-[14px]">star_border</span>
<span className="font-label-sm text-on-surface-variant ml-1">(18)</span>
</div>
<div className="flex items-center gap-2 mt-1">
<span className="font-body-md font-medium">$295.00</span>
</div>
</div>
</div>
</div>

<div className="flex justify-center items-center gap-2 mt-8">
<button className="w-10 h-10 rounded-full flex items-center justify-center text-on-surface-variant hover:bg-surface-variant transition-colors disabled:opacity-50" disabled={true}><span className="material-symbols-outlined">chevron_left</span></button>
<button className="w-10 h-10 rounded-full bg-brand-black text-white flex items-center justify-center font-body-md shadow-md">1</button>
<button className="w-10 h-10 rounded-full hover:bg-surface-variant flex items-center justify-center font-body-md transition-colors">2</button>
<button className="w-10 h-10 rounded-full hover:bg-surface-variant flex items-center justify-center font-body-md transition-colors">3</button>
<span className="w-10 h-10 flex items-center justify-center font-body-md">...</span>
<button className="w-10 h-10 rounded-full hover:bg-surface-variant flex items-center justify-center font-body-md transition-colors">12</button>
<button className="w-10 h-10 rounded-full flex items-center justify-center text-on-surface-variant hover:bg-surface-variant transition-colors"><span className="material-symbols-outlined">chevron_right</span></button>
</div>
</section>
</div>
</main>
  );
}