export default function MenSWearProductDetail() {
  return (
    <main className="flex-grow w-full max-w-container-max mx-auto px-margin-mobile md:px-margin-desktop py-stack-md flex flex-col gap-stack-lg">

<nav aria-label="Breadcrumb" className="mb-gutter text-on-surface-variant text-label-sm font-label-sm uppercase tracking-widest -mb-6">
<ol className="flex items-center space-x-2">
<li className=""><a className="hover:text-primary transition-colors" href="#">Home</a></li>
<li><span className="material-symbols-outlined text-sm">chevron_right</span></li>
<li className=""><a className="hover:text-primary transition-colors" href="#">Shirts</a></li>
<li><span className="material-symbols-outlined text-sm">chevron_right</span></li>
<li aria-current="page" className="text-primary">Slim Fit Oxford Shirt</li>
</ol>
</nav>

<div className="grid grid-cols-1 md:grid-cols-12 gap-gutter md:gap-stack-md">

<div className="md:col-span-7 flex flex-col-reverse md:flex-row gap-4 h-full">

<div className="flex md:flex-col space-x-4 md:space-x-0 md:space-y-4 overflow-x-auto md:overflow-visible no-scrollbar w-full md:w-24 flex-shrink-0">
<button className="w-20 h-24 md:w-24 md:h-32 rounded-lg overflow-hidden border-2 border-primary outline-none relative hover-lift">
<img className="w-full h-full object-cover" data-alt="Close up shot of a male model wearing a pristine white slim fit oxford shirt. The lighting is soft and natural, emphasizing the texture of the cotton fabric and the neat collar. The aesthetic is modern minimalist luxury, set against a subtle lavender-white backdrop. The focus is sharp on the shirt details." src="https://lh3.googleusercontent.com/aida-public/AB6AXuDGvblNM8FpIex072mGdR0BJ-pVnpSkieaO4LnVA-f6IGqPfBKzT4EKGBaX4IsTt4y5sn0495-NBD9XVcPxXgNrwMlEehtQBxaby2C3PBFP78ad8M4-fW7jU4rNhmi-Hy0sIM2H584Iy9IsdYiqwCky8ba99FqcJzHOXCvRGysyfXMsGYSG8P7jhKh__KHXvzf5rNAdkUiyeQ_-4DK2VKpF9ZU1OYX578ETlaBH-BLhNa3tjYXtRhqp8Q" />
</button>
<button className="w-20 h-24 md:w-24 md:h-32 rounded-lg overflow-hidden border border-surface-dim hover:border-primary transition-colors relative hover-lift opacity-70 hover:opacity-100">
<img className="w-full h-full object-cover" data-alt="Side profile shot of a male model in a white slim fit oxford shirt, showing the fit along the torso and arm. Gentle studio lighting highlights the seams and fabric drape. The mood is sophisticated and calm, with a clean, light-mode background ensuring the garment is the focal point." src="https://lh3.googleusercontent.com/aida-public/AB6AXuCa7l4bbsJSQn1o9tbL_-2P2XyMKjoIJVOGk72Lf5K59-eBLZClL456aVGo_yQm_C9E2VBUuBEkngLnKqq_pdiMknGk_xUzCFuEnuKfKof8EputZRwvsCofdWiBVVuAxaom8MlcWCkno0rCMyNkiIEEovdMXGYAyuzwQeJ0wpyWi9esWu_5lLjtbyTJXUqtfv8wu6Nipx7PLH5pKWv1bBtWYoGHhqv86UeWsnSbxBoBxkQ4CZfPxXmYDg" />
</button>
<button className="w-20 h-24 md:w-24 md:h-32 rounded-lg overflow-hidden border border-surface-dim hover:border-primary transition-colors relative hover-lift opacity-70 hover:opacity-100">
<img className="w-full h-full object-cover" data-alt="Detail shot of the cuffs and buttons of a white slim fit oxford shirt worn by a male model. The image focuses on the high-quality stitching and premium resin buttons. The lighting is crisp, creating subtle shadows that define the shape. The overall vibe is high-end editorial fashion." src="https://lh3.googleusercontent.com/aida-public/AB6AXuBetDNUaKIfCUamKyDGpEKKLbrpaeYPr5Yd0mo8lXXWoQ1THqwrXLx3aG_EiwfQxEmGZqdmpjoNSIaz4RnExgIczJPHFdZYT4zS25vR54fkeUPveewlGSsJaOUf68gz8nUTF4k7eBBjeOHHVyaBA1jqD3zcVh4QhzJyIT1QJgXs0l0EG6iR_znUiyBOrtpXdHU3BqQlZ4L_en867JwIeF_zFV8osoS4uCG0p5KnvFUsOT1m2aU3c4Jw3g" />
</button>
<button className="w-20 h-24 md:w-24 md:h-32 rounded-lg overflow-hidden border border-surface-dim hover:border-primary transition-colors relative hover-lift opacity-70 hover:opacity-100">
<img className="w-full h-full object-cover" data-alt="Back view of a male model wearing a white slim fit oxford shirt, demonstrating the tailored fit across the shoulders and back. Soft, diffused lighting creates an airy atmosphere. The setting is minimal, reflecting a quiet luxury aesthetic with deep blacks, pristine whites, and a touch of lavender-white." src="https://lh3.googleusercontent.com/aida-public/AB6AXuARDHIhyhP2tzW0hnuoM_XR1ez_RjlzyxmBH_jy8N_ZEji8U9tMev9zsFLWOvYV4eKfGKTpP2aZbRQQu24VLtTHXnKvbm717yLB2rvUHNGUDM1dOcyvhUN0kKIsfuavZu_036U1JcM7Ukj3huesQYkuDF4bt1ju0WYO3UE5Rl8_PwX05Jir2zyfn3TeoeygABDPrf-T9bKv3X85mkHTIVBY3S67GWiAO32ZVtegTqt7vXAGVFxM1wBTAw" />
</button>
</div>

<div className="relative w-full aspect-[3/4] md:aspect-auto md:flex-grow rounded-2xl overflow-hidden bg-surface-container-low">
<div className="absolute top-6 left-6 z-10">
<span className="bg-surface-container-lowest text-primary text-label-sm font-label-sm px-4 py-2 rounded-full shadow-sm">40% OFF</span>
</div>
<img className="w-full h-full object-cover object-center absolute inset-0" data-alt="Full body, premium editorial shot of a male model confidently wearing a crisp white slim fit oxford shirt paired with tailored dark trousers. The lighting is high-key and soft, creating a bright, modern aesthetic. The background is a minimalist, airy studio space, emphasizing negative space and quiet luxury. The composition is centered and striking." src="https://lh3.googleusercontent.com/aida-public/AB6AXuCEGGjsz8sNnENvu2cQRy1Dh1kHz5D04nV-EFPN6x_iZaVbOibWTIA1OIwNK1uSKYJCWbhOD3frAD6kSZt4fkTBmyfp24akIzlQiukZTS__T0fzqAmL3URcHpgTiVR1r5H-YhywuqD8Q4oCihwP9UgvQ38CoI-DEheNmU8DJxqx34LWSaHXhQ8BsathGnX85XjPeZYgwqsenXqXqsloRGt2nEYok54QQCPNN-5wySj2Amf99VnrzVgr-g" />
</div>
</div>

<div className="md:col-span-5 flex flex-col justify-start pt-4 md:pt-0">
<div className="mb-6 border-b border-surface-variant pb-6">
<span className="text-on-surface-variant text-label-sm font-label-sm uppercase tracking-widest block mb-2">UIXSHUVO</span>
<h1 className="font-headline-lg-mobile md:font-headline-lg text-headline-lg-mobile md:text-headline-lg text-primary uppercase mb-4">Slim Fit Oxford Shirt</h1>
<div className="flex items-center space-x-2 mb-6">
<div className="flex text-[#D4AF37]">
<span className="material-symbols-outlined text-lg" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-lg" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-lg" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-lg" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-lg" style={{"fontVariationSettings": "\'FILL\' 1"}}>star_half</span>
</div>
<span className="text-on-surface-variant text-body-md font-body-md">4.8 (214 reviews)</span>
</div>
<div className="flex items-end space-x-4 mb-2">
<span className="text-headline-md font-headline-md text-primary">$119.99</span>
<span className="text-body-lg font-body-lg text-on-surface-variant line-through mb-1">$199.99</span>
<span className="bg-sage text-surface-container-lowest text-label-sm font-label-sm px-3 py-1 rounded-full mb-1">SAVE $80</span>
</div>
</div>

<div className="mb-6">
<span className="text-label-sm font-label-sm uppercase tracking-widest text-primary block mb-3">Color: White</span>
<div className="flex space-x-3">
<button aria-label="White" className="w-8 h-8 rounded-full bg-surface-container-lowest border border-outline ring-2 ring-primary ring-offset-2 ring-offset-lavender-white"></button>
<button aria-label="Navy" className="w-8 h-8 rounded-full bg-[#1C2841] border border-transparent hover:scale-110 transition-transform"></button>
<button aria-label="Beige" className="w-8 h-8 rounded-full bg-[#E5DBCB] border border-transparent hover:scale-110 transition-transform"></button>
</div>
</div>

<div className="mb-8">
<div className="flex justify-between items-center mb-3">
<span className="text-label-sm font-label-sm uppercase tracking-widest text-primary">Size</span>
<a className="text-label-sm font-label-sm uppercase text-on-surface-variant underline hover:text-primary transition-colors" href="#">Size Guide</a>
</div>
<div className="flex flex-wrap gap-3">
<button className="w-12 h-12 rounded-full border border-surface-dim text-on-surface-variant text-body-md font-body-md hover:border-primary transition-colors flex items-center justify-center">S</button>
<button className="w-12 h-12 rounded-full bg-ink text-surface-container-lowest text-body-md font-body-md flex items-center justify-center shadow-sm">M</button>
<button className="w-12 h-12 rounded-full border border-surface-dim text-on-surface-variant text-body-md font-body-md hover:border-primary transition-colors flex items-center justify-center">L</button>
<button className="w-12 h-12 rounded-full border border-surface-dim text-on-surface-variant text-body-md font-body-md hover:border-primary transition-colors flex items-center justify-center">XL</button>
<button className="w-12 h-12 rounded-full border border-surface-dim text-on-surface-variant text-body-md font-body-md hover:border-primary transition-colors flex items-center justify-center opacity-50 cursor-not-allowed" disabled={true}>XXL</button>
</div>
</div>

<div className="flex flex-col space-y-4 mb-8">
<div className="flex items-center space-x-4">
<div className="flex items-center border border-outline rounded-full h-12 px-2 bg-surface-container-lowest">
<button className="w-8 h-8 flex items-center justify-center text-primary hover:bg-surface-container-low rounded-full transition-colors">
<span className="material-symbols-outlined text-sm">remove</span>
</button>
<span className="w-8 text-center text-body-md font-body-md">1</span>
<button className="w-8 h-8 flex items-center justify-center text-primary hover:bg-surface-container-low rounded-full transition-colors">
<span className="material-symbols-outlined text-sm">add</span>
</button>
</div>
<button className="flex-1 bg-ink text-surface-container-lowest h-12 rounded-full text-body-md font-body-md font-medium flex items-center justify-center space-x-2 hover:bg-primary-container transition-colors hover-lift">
<span className="">ADD TO CART</span>
<span className="">→</span>
</button>
</div>
<div className="flex items-center space-x-4">
<button className="flex-1 border border-ink text-ink h-12 rounded-full text-body-md font-body-md font-medium flex items-center justify-center hover:bg-surface-container-low transition-colors">
                            BUY NOW
                        </button>
<button className="w-12 h-12 border border-outline rounded-lg flex items-center justify-center text-primary hover:bg-surface-container-low transition-colors">
<span className="material-symbols-outlined">favorite</span>
</button>
</div>
</div>

<div className="mb-8 p-4 bg-muted-lilac rounded-xl">
<div className="flex items-center space-x-2 mb-3 text-primary">
<span className="material-symbols-outlined">local_shipping</span>
<span className="text-label-sm font-label-sm uppercase tracking-widest">Delivery &amp; Returns</span>
</div>
<div className="flex">
<input className="flex-1 bg-surface-container-lowest border-none rounded-l-full px-4 text-body-md font-body-md focus:ring-0" placeholder="Enter Pincode" type="text" />
<button className="bg-ink text-surface-container-lowest px-6 rounded-r-full text-label-sm font-label-sm uppercase tracking-widest hover:bg-primary-container transition-colors">Check</button>
</div>
</div>

<div className="border-t border-surface-variant">
<details className="group py-4 border-b border-surface-variant cursor-pointer" open={true}>
<summary className="flex justify-between items-center font-body-md text-body-md font-medium text-primary list-none">
<span className="">Description</span>
<span className="material-symbols-outlined transition group-open:rotate-180">expand_more</span>
</summary>
<div className="text-on-surface-variant text-body-md font-body-md mt-4 pr-4">
                            A cornerstone of the modern wardrobe. Our Slim Fit Oxford Shirt is crafted from premium, breathable organic cotton. It features a perfectly structured button-down collar, elegant mother-of-pearl buttons, and a tailored silhouette that flatters without restricting movement. Ideal for both editorial layering and standalone quiet luxury looks.
                        </div>
</details>
<details className="group py-4 border-b border-surface-variant cursor-pointer">
<summary className="flex justify-between items-center font-body-md text-body-md font-medium text-primary list-none">
<span className="">Fabric &amp; Care</span>
<span className="material-symbols-outlined transition group-open:rotate-180">expand_more</span>
</summary>
<div className="text-on-surface-variant text-body-md font-body-md mt-4 pr-4">
                            100% Organic Cotton. Machine wash cold with like colors. Do not bleach. Tumble dry low or line dry in shade. Warm iron if needed.
                        </div>
</details>
<details className="group py-4 border-b border-surface-variant cursor-pointer">
<summary className="flex justify-between items-center font-body-md text-body-md font-medium text-primary list-none">
<span className="">Shipping &amp; Returns</span>
<span className="material-symbols-outlined transition group-open:rotate-180">expand_more</span>
</summary>
<div className="text-on-surface-variant text-body-md font-body-md mt-4 pr-4">
                            Free standard shipping on orders over $150. Returns accepted within 30 days of purchase in unworn condition with tags attached.
                        </div>
</details>
</div>
</div>
</div>

<section className="flex flex-col gap-8 pt-8 border-t border-surface-variant">
<h2 className="font-headline-md text-headline-md text-primary uppercase">Reviews</h2>
<div className="grid grid-cols-1 lg:grid-cols-12 gap-12">

<div className="lg:col-span-4 flex flex-col gap-6 bg-surface-container p-8 rounded-[24px]">
<div className="flex items-end gap-4">
<span className="text-display-lg font-display-lg leading-none">4.8</span>
<div className="flex flex-col gap-1 pb-1">
<div className="flex text-[#D4AF37]">
<span className="material-symbols-outlined text-xl" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-xl" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-xl" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-xl" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-xl" style={{"fontVariationSettings": "\'FILL\' 1"}}>star_half</span>
</div>
<span className="text-on-surface-variant text-sm">Based on 214 reviews</span>
</div>
</div>
<div className="flex flex-col gap-2">

<div className="flex items-center gap-3">
<span className="text-sm font-medium w-3 text-right">5</span>
<span className="material-symbols-outlined text-sm text-[#D4AF37]" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<div className="flex-grow h-2 bg-surface-variant rounded-full overflow-hidden">
<div className="h-full bg-primary w-[80%]"></div>
</div>
<span className="text-sm text-on-surface-variant w-8 text-right">170</span>
</div>

<div className="flex items-center gap-3">
<span className="text-sm font-medium w-3 text-right">4</span>
<span className="material-symbols-outlined text-sm text-[#D4AF37]" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<div className="flex-grow h-2 bg-surface-variant rounded-full overflow-hidden">
<div className="h-full bg-primary w-[15%]"></div>
</div>
<span className="text-sm text-on-surface-variant w-8 text-right">32</span>
</div>

<div className="flex items-center gap-3">
<span className="text-sm font-medium w-3 text-right">3</span>
<span className="material-symbols-outlined text-sm text-[#D4AF37]" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<div className="flex-grow h-2 bg-surface-variant rounded-full overflow-hidden">
<div className="h-full bg-primary w-[3%]"></div>
</div>
<span className="text-sm text-on-surface-variant w-8 text-right">8</span>
</div>

<div className="flex items-center gap-3">
<span className="text-sm font-medium w-3 text-right">2</span>
<span className="material-symbols-outlined text-sm text-[#D4AF37]" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<div className="flex-grow h-2 bg-surface-variant rounded-full overflow-hidden">
<div className="h-full bg-primary w-[1%]"></div>
</div>
<span className="text-sm text-on-surface-variant w-8 text-right">2</span>
</div>

<div className="flex items-center gap-3">
<span className="text-sm font-medium w-3 text-right">1</span>
<span className="material-symbols-outlined text-sm text-[#D4AF37]" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<div className="flex-grow h-2 bg-surface-variant rounded-full overflow-hidden">
<div className="h-full bg-primary w-[1%]"></div>
</div>
<span className="text-sm text-on-surface-variant w-8 text-right">2</span>
</div>
</div>
</div>

<div className="lg:col-span-8 flex flex-col gap-6">

<div className="bg-surface p-6 rounded-[24px] border border-surface-variant flex flex-col gap-4">
<div className="flex justify-between items-start">
<div className="flex items-center gap-4">
<div className="w-12 h-12 rounded-full bg-brand-lilac flex items-center justify-center text-primary font-headline-md">JD</div>
<div>
<h4 className="font-medium text-body-md">James D.</h4>
<div className="flex text-[#D4AF37] mt-1">
<span className="material-symbols-outlined text-sm" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-sm" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-sm" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-sm" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-sm" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
</div>
</div>
</div>
<span className="text-sm text-on-surface-variant">2 days ago</span>
</div>
<p className="text-body-md text-on-surface-variant">"The fit on this oxford is incredible. The organic cotton feels substantial yet breathable. Definitely buying more colors."</p>
</div>

<div className="bg-surface p-6 rounded-[24px] border border-surface-variant flex flex-col gap-4">
<div className="flex justify-between items-start">
<div className="flex items-center gap-4">
<div className="w-12 h-12 rounded-full bg-brand-lilac flex items-center justify-center text-primary font-headline-md">MR</div>
<div>
<h4 className="font-medium text-body-md">Michael R.</h4>
<div className="flex text-[#D4AF37] mt-1">
<span className="material-symbols-outlined text-sm" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-sm" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-sm" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-sm" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-sm">star_border</span>
</div>
</div>
</div>
<span className="text-sm text-on-surface-variant">1 week ago</span>
</div>
<p className="text-body-md text-on-surface-variant">"Great quality shirt. The slim fit is true to size. Deducting one star only because I wish there were more dark color options available."</p>
</div>

<div className="bg-surface p-6 rounded-[24px] border border-surface-variant flex flex-col gap-4">
<div className="flex justify-between items-start">
<div className="flex items-center gap-4">
<div className="w-12 h-12 rounded-full bg-brand-lilac flex items-center justify-center text-primary font-headline-md">AT</div>
<div>
<h4 className="font-medium text-body-md">Alexander T.</h4>
<div className="flex text-[#D4AF37] mt-1">
<span className="material-symbols-outlined text-sm" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-sm" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-sm" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-sm" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined text-sm" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
</div>
</div>
</div>
<span className="text-sm text-on-surface-variant">3 weeks ago</span>
</div>
<p className="text-body-md text-on-surface-variant">"Perfect everyday shirt for the office. Elevates a simple look instantly. The collar roll is exactly what you want from a high-end oxford."</p>
</div>
</div>
</div>
</section>

<section className="flex flex-col gap-8 pt-12">
<h2 className="font-headline-lg text-headline-lg text-primary uppercase text-center tracking-widest">You May Also Like</h2>
<div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-gutter">

<div className="product-card flex flex-col gap-3 group relative cursor-pointer hover-lift rounded-[24px] bg-surface p-3 pb-4">
<div className="relative product-image-container h-[300px] w-full bg-surface-container rounded-xl overflow-hidden">
<img className="w-full h-full object-cover" data-alt="A male model standing in a bright minimalist studio wearing a tailored sage green linen shirt. High key lighting, editorial fashion style, crisp neutral background, soft ambient shadows." src="https://lh3.googleusercontent.com/aida-public/AB6AXuBxgGzUqq2CiqWpbdmms2LvY91YJkepmBzaYHZVMF04tIytDBg10_ssstBrDIsZ1HC0MD_aFaI2AYVismej_QRO_Z4hfXqXXIqOJUNHhl1zH629SaNHDR6FmMlEqVM-d5kmtmK5CrcRnqbcx86gxeh3w461JGe2t-HE2I4-4lP0DJJOHjQavJ8uKmTMkd69P3pAWKOgf6XTZrSUTiELwneDVkc5CHKP4hYWaANgZTbcWwgnm-CNrtrFUA" />
<div className="absolute top-3 left-3 flex flex-col gap-2 z-10">
<span className="bg-white px-2 py-1 rounded-full font-label-sm text-label-sm uppercase shadow-sm">NEW</span>
</div>
<button className="absolute top-3 right-3 w-8 h-8 bg-white/80 backdrop-blur rounded-full flex items-center justify-center hover:bg-white transition-colors z-10 text-on-surface">
<span className="material-symbols-outlined text-sm">favorite</span>
</button>
</div>
<div className="flex flex-col gap-1 px-1">
<span className="font-label-sm text-on-surface-variant uppercase tracking-widest text-[10px]">Shirts</span>
<h3 className="font-body-lg text-body-lg leading-tight truncate">Sage Linen Shirt</h3>
<div className="flex items-center gap-2 mt-1">
<span className="font-body-md font-medium">$85.00</span>
</div>
</div>
</div>

<div className="product-card flex flex-col gap-3 group relative cursor-pointer hover-lift rounded-[24px] bg-surface p-3 pb-4">
<div className="relative product-image-container h-[300px] w-full bg-surface-container rounded-xl overflow-hidden">
<img className="w-full h-full object-cover" data-alt="A man walking in a modern architectural setting wearing a tailored charcoal gray blazer and matching trousers. Sophisticated, quiet luxury vibe, soft diffused daylight." src="https://lh3.googleusercontent.com/aida-public/AB6AXuAaqJ-iojQ1YFdAjiF6r0QE_cCb-P7HJv-EJJbu9XXj7gSwcGbyxubejoWsDY6zbnSnyzf4WvClm1UT85MlsKpd8z0WyEPItuMRSajVWsuCUlmSzoEhCxFOpckv09Kt_IAyNqT-FwKJpH27DpNTL3zUYoSXHXXJZw2vcP2NMrVKRvL8WlF9XGdd0Aqyfhh_V1en6pcE6ca1GqxN-XS1caj-z6ZRblddIqompZDhuslc5-jsCGHyucWmNQ" />
<button className="absolute top-3 right-3 w-8 h-8 bg-white/80 backdrop-blur rounded-full flex items-center justify-center hover:bg-white transition-colors z-10 text-on-surface">
<span className="material-symbols-outlined text-sm">favorite</span>
</button>
</div>
<div className="flex flex-col gap-1 px-1">
<span className="font-label-sm text-on-surface-variant uppercase tracking-widest text-[10px]">Trousers</span>
<h3 className="font-body-lg text-body-lg leading-tight truncate">Wool Trousers</h3>
<div className="flex items-center gap-2 mt-1">
<span className="font-body-md font-medium">$120.00</span>
</div>
</div>
</div>

<div className="product-card flex flex-col gap-3 group relative cursor-pointer hover-lift rounded-[24px] bg-surface p-3 pb-4">
<div className="relative product-image-container h-[300px] w-full bg-surface-container rounded-xl overflow-hidden">
<img className="w-full h-full object-cover" data-alt="Close up shot of dark indigo selvedge denim jeans showing texture and stitching detail. Dramatic directional lighting highlighting the fabric weave, luxury minimalist presentation." src="https://lh3.googleusercontent.com/aida-public/AB6AXuDjTD-WW1zP2fvzGRu0knPSifWIFfm9qRXbujWL8ZW8aYgQmEUyQqWs_Z3PGSahgqPd4y3DFsiyMapcf3vEXRQm2p0peTtqJbdu0pswc3tTSQmmxp1fDXORQPgr9DMfVNWvK0jz_usRoNqSNZSB3OXpHMeLFwI9Hgmld2T2Gg3poDBDsfW-3CAl32fZbr3TmwD63Zyw4aglG3-cvCyn-gRyV53DlBOBQxy07_wwcMBk1DEgtSBLn3Wt7Q" />
<button className="absolute top-3 right-3 w-8 h-8 bg-white/80 backdrop-blur rounded-full flex items-center justify-center hover:bg-white transition-colors z-10 text-on-surface">
<span className="material-symbols-outlined text-sm">favorite</span>
</button>
</div>
<div className="flex flex-col gap-1 px-1">
<span className="font-label-sm text-on-surface-variant uppercase tracking-widest text-[10px]">Jeans</span>
<h3 className="font-body-lg text-body-lg leading-tight truncate">Selvedge Jeans</h3>
<div className="flex items-center gap-2 mt-1">
<span className="font-body-md font-medium">$145.00</span>
</div>
</div>
</div>

<div className="product-card flex flex-col gap-3 group relative cursor-pointer hover-lift rounded-[24px] bg-surface p-3 pb-4">
<div className="relative product-image-container h-[300px] w-full bg-surface-container rounded-xl overflow-hidden">
<img className="w-full h-full object-cover" data-alt="A meticulously folded beige knit polo shirt resting on a textured stone plinth. Bright, soft studio lighting emphasizing the ribbed fabric texture, minimal and elegant composition." src="https://lh3.googleusercontent.com/aida-public/AB6AXuA6MiYgZCAmUfevEYeZq3w06lk58zWxv5jAXZIQkkKGz8W4Cqc8A5k6dZP01UwzWqDzOptfFq-ULgd8ATxovXA6CjKsnBV-792lNQR-RAzm-kY0EPgcv_7jCZmkmV2Hfo6p7o7HRUlWY304_Y_R0GF1_723f5NyjzL_fXXIllWuSS5k_WU-4d-tLulwhP2P7B1h64GKgYzM46KMuam53F6K3LkFwU5y-1Li14FxUGeviRsexWMZP8IBFQ" />
<button className="absolute top-3 right-3 w-8 h-8 bg-white/80 backdrop-blur rounded-full flex items-center justify-center hover:bg-white transition-colors z-10 text-on-surface">
<span className="material-symbols-outlined text-sm">favorite</span>
</button>
</div>
<div className="flex flex-col gap-1 px-1">
<span className="font-label-sm text-on-surface-variant uppercase tracking-widest text-[10px]">Polo</span>
<h3 className="font-body-lg text-body-lg leading-tight truncate">Ribbed Knit Polo</h3>
<div className="flex items-center gap-2 mt-1">
<span className="font-body-md font-medium">$75.00</span>
</div>
</div>
</div>
</div>
</section>

<section className="flex flex-col gap-6 pt-12">
<h3 className="font-body-lg text-body-lg font-medium text-primary uppercase">Recently Viewed</h3>
<div className="grid grid-cols-2 md:grid-cols-4 gap-4">

<a className="group flex items-center gap-3 p-2 rounded-xl hover:bg-surface transition-colors border border-transparent hover:border-surface-variant" href="#">
<div className="w-16 h-16 rounded-lg overflow-hidden bg-surface-container shrink-0">
<img className="w-full h-full object-cover group-hover:scale-110 transition-transform" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAgNxcvobwp1FSKqGUe0jr8tIdiXIahHXgbOrQC2H01wFOYzOx4HLds03OhUa_2NJedervZZpesGaL0iYRZsZOOwnkwRrinK4ADo5QjbRCq5MGy7LU0bru4uUrRYD3yGbXROnoXCrlidSKGl7J5ADoeiYTrdgR353K5828sK2pG0heb7TgUIovsz8KABnJC5SEEKQJr5WLjBsLNxlBPgdB_s5rF7dBsPorSyn51Fv6S283i1LcHXiCQgg" />
</div>
<div className="flex flex-col">
<span className="text-sm font-medium truncate">Heavyweight Tee</span>
<span className="text-sm text-on-surface-variant">$45.00</span>
</div>
</a>

<a className="group flex items-center gap-3 p-2 rounded-xl hover:bg-surface transition-colors border border-transparent hover:border-surface-variant" href="#">
<div className="w-16 h-16 rounded-lg overflow-hidden bg-surface-container shrink-0">
<img className="w-full h-full object-cover group-hover:scale-110 transition-transform" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDm5VJ0pk-YGvaq_DkB6hLnM0Q7Cntoca4pAO7uaxm_GS-gtlmmn37278682LTvb8GmN_Q8CPCKI92dcV8nfl5bAtcaadZMhniViDkrRDA9MS9-juttOETdS_eOxPxifHB4u311tgR_OVuL6eOYfZ-0omBLAkIzcCSHn8AdHE5z9Hg-lt1j7gw4vFAlxd0gGth37lIMa9-wHzMJog0-0WkSYmoVOy__j7g_YZNHa3TajgnRnGE33JO8MQ" />
</div>
<div className="flex flex-col">
<span className="text-sm font-medium truncate">Oxford Shirt</span>
<span className="text-sm text-on-surface-variant">$95.00</span>
</div>
</a>

<a className="group flex items-center gap-3 p-2 rounded-xl hover:bg-surface transition-colors border border-transparent hover:border-surface-variant" href="#">
<div className="w-16 h-16 rounded-lg overflow-hidden bg-surface-container shrink-0">
<img className="w-full h-full object-cover group-hover:scale-110 transition-transform" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBTUvg9c9k_L857cL4XC_TOKQfHb5HYaLuLSPpbKEnU99dItboy7a2GGZEemWwBQzUEgLTdj2zGnKehxOcll1DGR7REe_SEyA7OSVtIW3_iLZ_yQZ6E7HvpbzOywd9BkGqsIBxREncN3KODKPKKr1986EB2kiWVZUcp0G27L2ahnT8DcDjs1EnMhCFqa0eRFgCJwfrq0tmkB3MgBOIT0BhhZyGyfhT4y39RzISLpxj9IBVEr5EcZub0Tg" />
</div>
<div className="flex flex-col">
<span className="text-sm font-medium truncate">Cargo Trousers</span>
<span className="text-sm text-on-surface-variant">$115.00</span>
</div>
</a>

<a className="group flex items-center gap-3 p-2 rounded-xl hover:bg-surface transition-colors border border-transparent hover:border-surface-variant" href="#">
<div className="w-16 h-16 rounded-lg overflow-hidden bg-surface-container shrink-0">
<img className="w-full h-full object-cover group-hover:scale-110 transition-transform" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAIonhzCFOBQXRfxtorJ5R4TdO14y7fi_HFt1Uhlg440dIJBxhHmiQTCs73vjUK6J-951AAW-dXJoU3f_Mea_B3pzoCtZsPmHLg4lZvQ1japr1vVD2PKCyCusY1mTLHmrKcLbSuqR8Iynk3EQbCyGjlKhROCDgxV2i7rLfBpm1b7cK-1qRqWjprXI3pSIGtFbmioeInvAyxFuUT9LYnN8HVy87-S8qpag3bbbsflrezYzb3NDhzNRLkmw" />
</div>
<div className="flex flex-col">
<span className="text-sm font-medium truncate">Wool Overcoat</span>
<span className="text-sm text-on-surface-variant">$295.00</span>
</div>
</a>
</div>
</section>
</main>
  );
}