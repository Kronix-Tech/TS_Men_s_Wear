import ShopProductGrid from "@/components/ShopProductGrid";
export default function MenSWearShopAll() {
  return (
    <main className="flex-grow w-full max-w-container-max mx-auto px-margin-mobile md:px-margin-desktop py-stack-md flex flex-col gap-stack-md">

<header className="flex flex-col gap-4 items-center text-center">
<nav aria-label="Breadcrumb" className="text-on-surface-variant font-body-md text-sm">
<a className="hover:text-primary transition-colors" href="#">Home</a>
<span className="mx-2">/</span>
<span className="text-primary">Shop</span>
</nav>
<h1 className="font-headline-lg-mobile md:font-headline-lg text-headline-lg-mobile md:text-headline-lg text-primary uppercase">SHOP ALL — MEN'S COLLECTION</h1>
<p className="font-body-md text-on-surface-variant">128 items</p>
</header>

<div className="flex flex-col lg:flex-row gap-gutter relative">

<aside className="w-full lg:w-[320px] shrink-0 lg:sticky lg:top-[100px] lg:h-[calc(100vh-120px)] overflow-y-auto no-scrollbar pb-8">
<div className="bg-surface rounded-[24px] p-6 ambient-shadow flex flex-col gap-8">
<div className="flex justify-between items-center border-b border-surface-variant pb-4">
<h2 className="font-headline-md text-headline-md">Filters</h2>
<button className="font-label-sm text-label-sm uppercase underline text-on-surface-variant hover:text-primary transition-colors">Clear all</button>
</div>

<div className="flex flex-col gap-3 border-b border-surface-variant pb-6">
<h3 className="font-body-lg font-medium">Categories</h3>
<div className="flex flex-col gap-2">
<label className="flex items-center gap-3 cursor-pointer group">
<input className="rounded border-outline-variant text-brand-sage focus:ring-brand-sage w-5 h-5 bg-transparent" type="checkbox" />
<span className="font-body-md group-hover:text-brand-sage transition-colors">Shirts</span>
</label>
<label className="flex items-center gap-3 cursor-pointer group">
<input className="rounded border-outline-variant text-brand-sage focus:ring-brand-sage w-5 h-5 bg-transparent" type="checkbox" />
<span className="font-body-md group-hover:text-brand-sage transition-colors">T-Shirts</span>
</label>
<label className="flex items-center gap-3 cursor-pointer group">
<input className="rounded border-outline-variant text-brand-sage focus:ring-brand-sage w-5 h-5 bg-transparent" type="checkbox" />
<span className="font-body-md group-hover:text-brand-sage transition-colors">Polo</span>
</label>
<label className="flex items-center gap-3 cursor-pointer group">
<input className="rounded border-outline-variant text-brand-sage focus:ring-brand-sage w-5 h-5 bg-transparent" type="checkbox" />
<span className="font-body-md group-hover:text-brand-sage transition-colors">Jeans</span>
</label>
<label className="flex items-center gap-3 cursor-pointer group">
<input className="rounded border-outline-variant text-brand-sage focus:ring-brand-sage w-5 h-5 bg-transparent" type="checkbox" />
<span className="font-body-md group-hover:text-brand-sage transition-colors">Trousers</span>
</label>
<label className="flex items-center gap-3 cursor-pointer group">
<input className="rounded border-outline-variant text-brand-sage focus:ring-brand-sage w-5 h-5 bg-transparent" type="checkbox" />
<span className="font-body-md group-hover:text-brand-sage transition-colors">Ethnic</span>
</label>
<label className="flex items-center gap-3 cursor-pointer group">
<input className="rounded border-outline-variant text-brand-sage focus:ring-brand-sage w-5 h-5 bg-transparent" type="checkbox" />
<span className="font-body-md group-hover:text-brand-sage transition-colors">Winter</span>
</label>
</div>
</div>

<div className="flex flex-col gap-3 border-b border-surface-variant pb-6">
<h3 className="font-body-lg font-medium">Size</h3>
<div className="flex flex-wrap gap-2">
<button className="w-10 h-10 rounded-full border border-outline-variant flex items-center justify-center font-body-md hover:border-primary hover:bg-primary hover:text-white transition-all">S</button>
<button className="w-10 h-10 rounded-full border border-outline-variant flex items-center justify-center font-body-md hover:border-primary hover:bg-primary hover:text-white transition-all">M</button>
<button className="w-10 h-10 rounded-full border border-primary bg-primary text-white flex items-center justify-center font-body-md transition-all">L</button>
<button className="w-10 h-10 rounded-full border border-outline-variant flex items-center justify-center font-body-md hover:border-primary hover:bg-primary hover:text-white transition-all">XL</button>
<button className="w-10 h-10 rounded-full border border-outline-variant flex items-center justify-center font-body-md hover:border-primary hover:bg-primary hover:text-white transition-all">XXL</button>
</div>
</div>

<div className="flex flex-col gap-3 border-b border-surface-variant pb-6">
<h3 className="font-body-lg font-medium">Color</h3>
<div className="flex flex-wrap gap-3">
<button aria-label="Black" className="w-8 h-8 rounded-full bg-black ring-2 ring-offset-2 ring-transparent hover:ring-outline-variant transition-all focus:ring-primary focus:outline-none"></button>
<button aria-label="White" className="w-8 h-8 rounded-full bg-white border border-outline-variant ring-2 ring-offset-2 ring-transparent hover:ring-outline-variant transition-all focus:ring-primary focus:outline-none"></button>
<button aria-label="Navy" className="w-8 h-8 rounded-full bg-[#000080] ring-2 ring-offset-2 ring-transparent hover:ring-outline-variant transition-all focus:ring-primary focus:outline-none"></button>
<button aria-label="Grey" className="w-8 h-8 rounded-full bg-gray-500 ring-2 ring-offset-2 ring-transparent hover:ring-outline-variant transition-all focus:ring-primary focus:outline-none"></button>
<button aria-label="Sage" className="w-8 h-8 rounded-full bg-brand-sage ring-2 ring-offset-2 ring-transparent hover:ring-outline-variant transition-all focus:ring-primary focus:outline-none"></button>
<button aria-label="Beige" className="w-8 h-8 rounded-full bg-[#F5F5DC] border border-outline-variant ring-2 ring-offset-2 ring-transparent hover:ring-outline-variant transition-all focus:ring-primary focus:outline-none"></button>
</div>
</div>

<div className="flex flex-col gap-3 border-b border-surface-variant pb-6">
<h3 className="font-body-lg font-medium">Price</h3>
<input className="w-full h-1 bg-surface-variant rounded-lg appearance-none cursor-pointer" max="1000" min="0" type="range" defaultValue="500" />
<div className="flex justify-between font-label-sm text-on-surface-variant">
<span className="">$0</span>
<span className="">$1000+</span>
</div>
</div>

<div className="flex flex-col gap-3 border-b border-surface-variant pb-6">
<h3 className="font-body-lg font-medium">Fabric</h3>
<div className="flex flex-col gap-2">
<label className="flex items-center gap-3 cursor-pointer group">
<input className="rounded border-outline-variant text-brand-sage focus:ring-brand-sage w-5 h-5 bg-transparent" type="checkbox" />
<span className="font-body-md group-hover:text-brand-sage transition-colors">Cotton</span>
</label>
<label className="flex items-center gap-3 cursor-pointer group">
<input className="rounded border-outline-variant text-brand-sage focus:ring-brand-sage w-5 h-5 bg-transparent" type="checkbox" />
<span className="font-body-md group-hover:text-brand-sage transition-colors">Linen</span>
</label>
<label className="flex items-center gap-3 cursor-pointer group">
<input className="rounded border-outline-variant text-brand-sage focus:ring-brand-sage w-5 h-5 bg-transparent" type="checkbox" />
<span className="font-body-md group-hover:text-brand-sage transition-colors">Denim</span>
</label>
<label className="flex items-center gap-3 cursor-pointer group">
<input className="rounded border-outline-variant text-brand-sage focus:ring-brand-sage w-5 h-5 bg-transparent" type="checkbox" />
<span className="font-body-md group-hover:text-brand-sage transition-colors">Wool</span>
</label>
</div>
</div>

<div className="flex flex-col gap-3 border-b border-surface-variant pb-6">
<h3 className="font-body-lg font-medium">Fit</h3>
<div className="flex flex-wrap gap-2">
<button className="px-4 py-2 rounded-full border border-outline-variant font-body-md hover:border-primary hover:bg-primary hover:text-white transition-all">Slim</button>
<button className="px-4 py-2 rounded-full border border-outline-variant font-body-md hover:border-primary hover:bg-primary hover:text-white transition-all">Regular</button>
<button className="px-4 py-2 rounded-full border border-outline-variant font-body-md hover:border-primary hover:bg-primary hover:text-white transition-all">Loose</button>
</div>
</div>

<div className="flex flex-col gap-3 border-b border-surface-variant pb-6">
<h3 className="font-body-lg font-medium">Discount</h3>
<div className="flex flex-wrap gap-2">
<button className="px-4 py-2 rounded-full border border-outline-variant font-body-md hover:border-primary hover:bg-primary hover:text-white transition-all">10%+</button>
<button className="px-4 py-2 rounded-full border border-outline-variant font-body-md hover:border-primary hover:bg-primary hover:text-white transition-all">20%+</button>
<button className="px-4 py-2 rounded-full border border-outline-variant font-body-md hover:border-primary hover:bg-primary hover:text-white transition-all">30%+</button>
</div>
</div>

<div className="flex items-center justify-between pb-6">
<h3 className="font-body-lg font-medium">In-stock</h3>
<div className="relative inline-block w-12 mr-2 align-middle select-none transition duration-200 ease-in">
<input className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer" id="toggle" name="toggle" type="checkbox" />
<label className="toggle-label block overflow-hidden h-6 rounded-full bg-surface-variant cursor-pointer" htmlFor="toggle"></label>
</div>
</div>
<button className="w-full bg-brand-black text-white font-body-md py-3 rounded-full flex items-center justify-center gap-2 hover:opacity-80 transition-opacity">
                        APPLY FILTERS <span className="material-symbols-outlined text-sm">arrow_forward</span>
</button>
</div>
</aside>

<section className="flex-grow flex flex-col gap-6 w-full">

<div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-surface rounded-[24px] p-4 ambient-shadow">
<div className="flex flex-wrap gap-2">
<span className="bg-brand-lilac px-3 py-1 rounded-full font-label-sm text-label-sm uppercase flex items-center gap-1">Size: L <button className="hover:text-primary"><span className="material-symbols-outlined text-[14px]">close</span></button></span>
<span className="bg-brand-lilac px-3 py-1 rounded-full font-label-sm text-label-sm uppercase flex items-center gap-1">Color: Sage <button className="hover:text-primary"><span className="material-symbols-outlined text-[14px]">close</span></button></span>
</div>
<div className="flex items-center gap-4">
<div className="relative">
<select className="appearance-none bg-transparent border-none py-2 pl-4 pr-8 font-body-md cursor-pointer focus:ring-0">
<option>Sort by: Newest</option>
<option>Price: Low to High</option>
<option>Price: High to Low</option>
</select>
<span className="material-symbols-outlined absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none">expand_more</span>
</div>
<div className="hidden sm:flex border-l border-surface-variant pl-4 gap-2">
<button className="text-primary"><span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1"}}>grid_view</span></button>
<button className="text-outline-variant hover:text-primary transition-colors"><span className="material-symbols-outlined">view_list</span></button>
</div>
</div>
</div>

<ShopProductGrid />
<div className="flex justify-center items-center gap-2 mt-8">
<button className="w-10 h-10 rounded-full flex items-center justify-center text-on-surface-variant hover:bg-surface-variant transition-colors disabled:opacity-50" disabled={true}><span className="material-symbols-outlined">chevron_left</span></button>
<button className="w-10 h-10 rounded-full bg-brand-black text-white flex items-center justify-center font-body-md shadow-md">1</button>
<button className="w-10 h-10 rounded-full hover:bg-surface-variant flex items-center justify-center font-body-md transition-colors">2</button>
<button className="w-10 h-10 rounded-full hover:bg-surface-variant flex items-center justify-center font-body-md transition-colors">3</button>
<span className="w-10 h-10 flex items-center justify-center font-body-md">...</span>
<button className="w-10 h-10 rounded-full hover:bg-surface-variant flex items-center justify-center font-body-md transition-colors">12</button>
<button className="w-10 h-10 rounded-full flex items-center justify-center text-on-surface-variant hover:bg-surface-variant transition-colors"><span className="material-symbols-outlined">chevron_right</span></button>
</div>
</section>
</div>
</main>
  );
}