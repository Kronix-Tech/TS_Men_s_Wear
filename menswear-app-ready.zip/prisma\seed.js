const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  // Create categories
  const catShirts = await prisma.category.upsert({
    where: { slug: 'shirts' },
    update: {},
    create: {
      name: 'Shirts',
      slug: 'shirts',
    },
  });

  const catTrousers = await prisma.category.upsert({
    where: { slug: 'trousers' },
    update: {},
    create: {
      name: 'Trousers',
      slug: 'trousers',
    },
  });

  // Create products
  await prisma.product.upsert({
    where: { slug: 'sage-linen-shirt' },
    update: {},
    create: {
      name: 'Sage Linen Shirt',
      slug: 'sage-linen-shirt',
      description: 'A male model standing in a bright minimalist studio wearing a tailored sage green linen shirt. High key lighting, editorial fashion style.',
      price: 85.00,
      stock: 50,
      categoryId: catShirts.id,
      imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBxgGzUqq2CiqWpbdmms2LvY91YJkepmBzaYHZVMF04tIytDBg10_ssstBrDIsZ1HC0MD_aFaI2AYVismej_QRO_Z4hfXqXXIqOJUNHhl1zH629SaNHDR6FmMlEqVM-d5kmtmK5CrcRnqbcx86gxeh3w461JGe2t-HE2I4-4lP0DJJOHjQavJ8uKmTMkd69P3pAWKOgf6XTZrSUTiELwneDVkc5CHKP4hYWaANgZTbcWwgnm-CNrtrFUA'
    },
  });

  await prisma.product.upsert({
    where: { slug: 'heavyweight-tee' },
    update: {},
    create: {
      name: 'Heavyweight Tee',
      slug: 'heavyweight-tee',
      description: 'A folded stack of premium heavyweight cotton t-shirts in neutral tones.',
      price: 45.00,
      stock: 120,
      categoryId: catShirts.id,
      imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAgNxcvobwp1FSKqGUe0jr8tIdiXIahHXgbOrQC2H01wFOYzOx4HLds03OhUa_2NJedervZZpesGaL0iYRZsZOOwnkwRrinK4ADo5QjbRCq5MGy7LU0bru4uUrRYD3yGbXROnoXCrlidSKGl7J5ADoeiYTrdgR353K5828sK2pG0heb7TgUIovsz8KABnJC5SEEKQJr5WLjBsLNxlBPgdB_s5rF7dBsPorSyn51Fv6S283i1LcHXiCQgg'
    },
  });

  // Create an Admin user
  await prisma.user.upsert({
    where: { email: 'admin@menswear.com' },
    update: {},
    create: {
      email: 'admin@menswear.com',
      password: 'password123', // In a real app this would be hashed
      name: 'Admin User',
      role: 'ADMIN',
    },
  });

  console.log('Seed completed successfully');
}

main()
  .then(async () => {
    await prisma.$disconnect();
  })
  .catch(async (e) => {
    console.error(e);
    await prisma.$disconnect();
    process.exit(1);
  });
