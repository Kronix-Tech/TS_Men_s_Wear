export default function Home() {
  return (
    <main className="flex-grow w-full max-w-container-max mx-auto px-margin-desktop py-stack-md flex flex-col gap-stack-lg">
      {/* Section 1: Hero */}
      <section className="flex flex-col gap-stack-md">
        <div className="flex flex-col md:flex-row justify-between items-end gap-gutter">
          <div className="max-w-4xl relative">
            <h1 className="font-display-lg text-display-lg uppercase leading-[1.1] tracking-wide text-brand-ink">
              DIVE INTO A WORLD OF ENDLESS FASHION POSSIBILITIES
            </h1>
            <div className="absolute top-4 -left-8 w-4 h-4 rounded-full bg-brand-sage hidden md:block"></div>
          </div>
          <div className="max-w-sm md:text-right font-body-lg text-body-lg text-on-surface-variant">
            <p className="">Discover our curated collection designed for the modern man. Experience quiet luxury with pieces that blend classical elegance and functional precision.</p>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-gutter h-auto md:h-[600px]">
          <div className="relative bg-white rounded-2xl overflow-hidden editorial-shadow group image-zoom h-[400px] md:h-full">
            <img alt="Model in white shirt and grey trousers" className="w-full h-full object-cover object-center" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDg-Uh8t9KfZ8LsLb01-KFQ6hP3UOMkG1UifxDJ2Dskxecrko7C3atwL252Bsa3qInvmhKvjAC2WCuLtu_0pLE2nJuDv3xTJh9rMR1yFsHck7ryHvnTIMVdURbLTa-uW4RM3LwqzSsZgZrJNTz-nEl6qn9JLIHghjwU9cVNAjtBSRRdRSD8n-f-4fhVLN0NDWlvi56bCkbJGUBoo05NChyQWHP8GXSU62uNnAbPm8bATMCgDqmBtSzyFA" />
            <div className="absolute top-1/4 left-8 flex items-center gap-2">
              <div className="bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full font-label-sm text-label-sm border border-brand-lilac">$120.00</div>
              <div className="w-8 h-[1px] bg-white"></div>
            </div>
            <div className="absolute top-1/2 right-8 flex items-center gap-2 flex-row-reverse">
              <div className="bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full font-label-sm text-label-sm border border-brand-lilac">$90.00</div>
              <div className="w-8 h-[1px] bg-white"></div>
            </div>
            <div className="absolute bottom-1/4 left-1/4 flex flex-col items-center gap-2">
              <div className="w-[1px] h-8 bg-white"></div>
              <div className="bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full font-label-sm text-label-sm border border-brand-lilac">$30.00</div>
            </div>
          </div>
          <div className="flex flex-col gap-gutter h-full">
            <div className="flex flex-col gap-unit items-center justify-center p-8 bg-brand-lilac rounded-2xl h-1/3">
              <button className="w-full flex items-center justify-between px-6 py-4 bg-brand-ink text-white rounded-full hover:bg-brand-ink/90 transition-colors font-body-md text-body-md">
                <span className="">SHOP NOW</span>
                <span className="material-symbols-outlined text-lg">arrow_forward</span>
              </button>
              <button className="w-full flex items-center justify-center px-6 py-4 bg-transparent text-brand-ink border border-brand-ink rounded-full hover:bg-white/50 transition-colors font-body-md text-body-md">
                <span className="">EXPLORE MORE PRODUCTS</span>
              </button>
            </div>
            <div className="relative bg-white rounded-2xl overflow-hidden editorial-shadow group image-zoom h-2/3">
              <img alt="Autumn Collection" className="w-full h-full object-cover object-center" src="https://lh3.googleusercontent.com/aida-public/AB6AXuA42uLh0a6FO5_OW4xVmi9U_ToP2a9bato1lDjDGoYgH8Pk9qEuWLrnfu-tNf_GcKubjrz88-42rarjXI_20Q37VK10YXtjACE0trLoR4nzNwN77m1Ay2VIkdt7mC3rAjled3OcBDEsWMCQ9iDOZISbWZYhPrrBbN5KSBtqIP3ek9bsFFW4GjBYzWMbf524dqOLCXU7s_9sbEKj8ar3sIsxLiv5fDkK1WfGPb_if9e99CrYlxNMiwoIbQ" />
              <div className="absolute bottom-6 left-6 right-6 flex justify-between items-end">
                <div className="bg-white/90 backdrop-blur-sm px-4 py-2 rounded-full font-headline-md text-headline-md tracking-widest text-brand-ink uppercase">
                  Autumn Collection
                </div>
              </div>
            </div>
          </div>
          <div className="relative bg-white rounded-2xl overflow-hidden editorial-shadow group image-zoom h-[400px] md:h-full">
            <img alt="Quasi Formal Set" className="w-full h-full object-cover object-center" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDoLcDGnr2aDJiW1y-Ec3Y_pBMnf3SDFt7X65Zvgofjn7jz4BwUh_7ScHNUJavGViJ2bfM9-0ou2Qao1CdHk6xC1SZ0oDzcmUQWocLj213p-fNIwCmvTIvM9UWKslBTrf8M_yNYCrlQRwB0Ee2smRgYFtu-zrDn_Kj6UjZ1y8v9Fk2DZs5iywUYU3TTfINafcJD-KiHLBfBk8ym04o75iPnGnHj4igeHmLVP-eKrLxo0pynu4S8rOe-Lw" />
            <div className="absolute top-6 right-6 flex flex-col gap-2 items-end">
              <div className="bg-brand-lilac/90 backdrop-blur-sm px-3 py-1 rounded-full font-label-sm text-label-sm text-brand-ink">$400</div>
              <div className="bg-brand-lilac/90 backdrop-blur-sm px-3 py-1 rounded-full font-label-sm text-label-sm text-brand-ink">Quasi Formal Set</div>
            </div>
            <button className="absolute bottom-6 right-6 w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-lg hover:bg-brand-ink hover:text-white transition-colors">
              <span className="material-symbols-outlined">arrow_forward</span>
            </button>
          </div>
        </div>
      </section>
      
      {/* Section 2: Featured Collection Carousel */}
      <section className="flex flex-col gap-stack-md py-stack-md">
        <div className="flex justify-between items-end mb-4">
          <h2 className="font-display-lg text-headline-lg uppercase tracking-widest text-brand-ink">
            FEATURED COLLECTION
          </h2>
          <div className="flex gap-2">
            <button className="w-10 h-10 border border-brand-ink rounded-full flex items-center justify-center hover:bg-brand-ink hover:text-white transition-colors">
              <span className="material-symbols-outlined">arrow_back</span>
            </button>
            <button className="w-10 h-10 border border-brand-ink rounded-full flex items-center justify-center hover:bg-brand-ink hover:text-white transition-colors">
              <span className="material-symbols-outlined">arrow_forward</span>
            </button>
          </div>
        </div>
        <div className="flex gap-gutter overflow-x-auto pb-8 snap-x snap-mandatory hide-scrollbar items-center">
          {/* Card 1 */}
          <div className="snap-center shrink-0 w-80 h-[500px] relative bg-white rounded-3xl overflow-hidden editorial-shadow group image-zoom">
            <img alt="Product 1" className="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAyry1tsIBUTXV4F3kSgC_i2DQzv-MjymHYm4PTeyD3ZZdAHdxckASe-q2IjSsDaXd60PdwXTXsIdQBL8xrVIQepEpocuuUZo_70ODc_QuWKynvLHN6P3SDwML-DWlhrAYwroIuL14ROlZx4KlchKR-DGUgNwXWeFrjYpeup5PEarskls7ZnkWHVweqW_tJaxsOkhG_8Qpx2diFRvD95lNF8hVJkwIwciIGrTQqlS421ro_OEAvnr3lYQ" />
            <div className="absolute bottom-6 left-6 right-6 flex justify-between items-center bg-white/90 backdrop-blur-sm p-4 rounded-full">
              <span className="font-body-lg text-body-lg font-bold ml-2">$89.99</span>
              <button className="w-10 h-10 bg-brand-ink text-white rounded-full flex items-center justify-center hover:bg-brand-ink/80 transition-colors">
                <span className="material-symbols-outlined text-sm">shopping_bag</span>
              </button>
            </div>
          </div>
          {/* Card 2 */}
          <div className="snap-center shrink-0 w-80 h-[500px] relative bg-white rounded-3xl overflow-hidden editorial-shadow group image-zoom">
            <img alt="Featured Product" className="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDpaSrtBFsIfl0Eov-ZUEiyofAzAXJb2uHfn6TUcSgMl8Mmk_J4fcnUPzK8wUH-Xmm6dsuG27lZ1Axh4C_fjl_FsB-tnQXAKRIQu_XJF0eE22fUG9s6uR6StZPy_ZpmJRSZaIqbpdlzwnIlC7wuGbozxqHQjMlZY3HAIMaAm3w038nWQGzdKCi7uPZ2Uj0bok-EHh9IS3SYEDtIQEfXIw7gg_Ydu9ylsMks-GQEAWFrIzgi5CLjLfe6hw" />
            <div className="absolute top-4 left-4 bg-white px-3 py-1 rounded-full font-label-sm text-label-sm border border-brand-lilac">40%</div>
            <div className="absolute top-1/2 -left-12 -rotate-90 origin-center bg-white/80 backdrop-blur-sm px-4 py-2 rounded-full font-headline-md text-body-lg tracking-widest uppercase">Quick Formal</div>
            <div className="absolute bottom-6 left-6 right-6 flex justify-between items-center bg-white/90 backdrop-blur-sm p-4 rounded-full">
              <span className="font-body-lg text-body-lg font-bold ml-2">$119.99</span>
              <button className="w-10 h-10 bg-brand-ink text-white rounded-full flex items-center justify-center hover:bg-brand-ink/80 transition-colors">
                <span className="material-symbols-outlined text-sm">shopping_bag</span>
              </button>
            </div>
          </div>
          {/* Card 3 */}
          <div className="snap-center shrink-0 w-80 h-[500px] relative bg-white rounded-3xl overflow-hidden editorial-shadow group image-zoom">
            <img alt="Product 3" className="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBvPeO0wmaIHB-7QW5Yd9nPgNbrEFiuexrx-LSfYRQgxp_Nn-omUW6jOr2-BIrkyZzvjQC6vmx3aeSEhmVCbr4CVPAWU9FHNX4Gl9G-8afLojsLGG1XxTntY6MxGN00dktwHfLP8V_FFsgwfbUChwPn-PW1jeC74jnCEKVPZeErIYMzmgW5h5VoafwqDfYZiVHKPQNKyxqaky6RLxtTp5BJj-VZbqBVUsT9NampXR5Jn4f9AAP5uPGY-Q" />
            <div className="absolute bottom-6 left-6 right-6 flex justify-between items-center bg-white/90 backdrop-blur-sm p-4 rounded-full">
              <span className="font-body-lg text-body-lg font-bold ml-2">$145.00</span>
              <button className="w-10 h-10 bg-brand-ink text-white rounded-full flex items-center justify-center hover:bg-brand-ink/80 transition-colors">
                <span className="material-symbols-outlined text-sm">shopping_bag</span>
              </button>
            </div>
          </div>
          {/* Card 4 */}
          <div className="snap-center shrink-0 w-80 h-[500px] relative bg-white rounded-3xl overflow-hidden editorial-shadow group image-zoom">
            <img alt="Product 4" className="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAtVD1Vog8tyMTH0wDpTOCHz1iRRVf-qaC_345PvKu1J1Fdr2G6cEFOB617jWUL3eKM1seMHqViFKBImVBMnnsAL9WRxqcMdEfP4Wg5NZUow0XzvDaOLljs-rVweuRCTHRMMogbdSgcspsTA7m0Y5cutJznHruhwrTVFaMfBvCTkwDZlIutHdpTVZOO_HAQiYFE6PY0lAbNAEs8DYy2QhNiE1nPe5PFb33AzyT8Sv9py8MFf_J1HRyQJg" />
            <div className="absolute bottom-6 left-6 right-6 flex justify-between items-center bg-white/90 backdrop-blur-sm p-4 rounded-full">
              <span className="font-body-lg text-body-lg font-bold ml-2">$210.00</span>
              <button className="w-10 h-10 bg-brand-ink text-white rounded-full flex items-center justify-center hover:bg-brand-ink/80 transition-colors">
                <span className="material-symbols-outlined text-sm">shopping_bag</span>
              </button>
            </div>
          </div>
          {/* Card 5 */}
          <div className="snap-center shrink-0 w-80 h-[500px] relative bg-white rounded-3xl overflow-hidden editorial-shadow group image-zoom">
            <img alt="Product 5" className="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuA0n1KA6oyoCe55sb6qrkUpVTtYokNwGdztUz47C6BWQqWNqbL94DY3Jy_mbQf1-EXaJ1bFVa28M_knKKy_0OPNSFHai5BfxRkE4CpqFP3t3kOIsFinCgBYRLl9ELffapg9mkoeS8F3iE5Si9WtbNwkvgocrWgcuAOtBMvFKVX82KuVauL1df0s-HpTMTPOtxO8JRchI3VSMVv8Re_HBqZJxpBa62_mtta-ui60zxEr9GZugBSUNzogAA" />
            <div className="absolute bottom-6 left-6 right-6 flex justify-between items-center bg-white/90 backdrop-blur-sm p-4 rounded-full">
              <span className="font-body-lg text-body-lg font-bold ml-2">$185.00</span>
              <button className="w-10 h-10 bg-brand-ink text-white rounded-full flex items-center justify-center hover:bg-brand-ink/80 transition-colors">
                <span className="material-symbols-outlined text-sm">shopping_bag</span>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Section 3: Sage Banner Section */}
      <section className="bg-brand-sage rounded-[2rem] p-8 md:p-16 flex flex-col md:flex-row gap-12 items-center justify-between mb-stack-lg">
        <div className="flex-1 text-white max-w-xl">
          <h2 className="font-display-lg text-headline-lg lg:text-display-lg uppercase leading-tight tracking-wide mb-6">
            ELEVATE YOUR WARDROBE WITH OUR FASHION FINDS
          </h2>
          <p className="font-body-lg text-white/90 mb-8">
            Explore carefully curated pieces that effortlessly blend contemporary style with timeless elegance. Perfect for the modern man looking to make a statement.
          </p>
          <button className="px-8 py-4 bg-white text-brand-ink rounded-full font-bold hover:bg-surface transition-colors inline-flex items-center gap-2">
            SHOP THE LOOK <span className="material-symbols-outlined">arrow_forward</span>
          </button>
        </div>
        <div className="flex-1 relative w-full flex justify-center">
          <div className="relative w-full max-w-md aspect-[3/4] rounded-3xl overflow-hidden">
            <img alt="Man in brown blazer" className="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAaaGhxVEz7P6h98udiZI-gpANkYXf5KR5kwBa7AeGmHl_FGhTG9G6OWITDs7iyFXKJteoSEcj7wygRbFOkImY6_xYX57KuRoAQip35i38BWunpwwlesSsFcJeJoJft9DW7rwn42QwTK3nezl0MmNCRGAsysy1Jee63MiRRtj_E-yke40h2GrSmiUykrB4D5s7-GpNuyk6rVm1IjDs2jQDSfH1DulT5dmKkJHvclTWfWCXUpY5IerJ6vA" />
            <div className="absolute inset-0 bg-black/10 flex items-center justify-center">
              <button className="w-20 h-20 bg-white/30 backdrop-blur-md border border-white/50 rounded-full flex items-center justify-center text-white hover:bg-white/40 transition-colors">
                <span className="material-symbols-outlined text-4xl">play_arrow</span>
              </button>
            </div>
          </div>
          {/* Rotating Badge */}
          <div className="absolute -bottom-6 -right-6 md:bottom-12 md:-left-12 w-32 h-32 bg-white rounded-full shadow-xl flex items-center justify-center rotate-animation z-10 hidden md:flex">
            <svg className="w-full h-full p-2" viewBox="0 0 100 100">
              <path d="M 50, 50 m -37, 0 a 37,37 0 1,1 74,0 a 37,37 0 1,1 -74,0" fill="transparent" id="curve"></path>
              <text className="text-[11px] font-bold tracking-[0.2em] uppercase fill-brand-ink">
                <textPath href="#curve">New Arrivals • Premium Quality • </textPath>
              </text>
            </svg>
          </div>
        </div>
      </section>

      {/* Section 4: Fashion at your Fingertips */}
      <section className="flex flex-col gap-stack-md pb-stack-lg">
        <h2 className="font-display-lg text-headline-lg uppercase tracking-widest text-brand-ink text-center mb-4">
          FASHION AT YOUR FINGERTIPS
        </h2>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-gutter h-auto lg:h-[600px]">
          {/* Stat Card */}
          <div className="col-span-1 bg-brand-sage rounded-3xl p-10 text-white flex flex-col justify-center gap-12 editorial-shadow">
            <div>
              <h3 className="font-display-lg text-display-lg leading-none mb-2">1200+</h3>
              <p className="font-body-lg text-white/90 uppercase tracking-widest">Products</p>
            </div>
            <div className="w-16 h-[1px] bg-white/30"></div>
            <div>
              <h3 className="font-display-lg text-display-lg leading-none mb-2">50K+</h3>
              <p className="font-body-lg text-white/90 uppercase tracking-widest">Customers</p>
            </div>
          </div>
          {/* 2x2 Grid */}
          <div className="col-span-1 lg:col-span-2 grid grid-cols-2 grid-rows-2 gap-gutter h-[600px] lg:h-full">
            <div className="bg-white rounded-3xl overflow-hidden relative group">
              <img alt="Grid item 1" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDsMHoprjfUFovqGd_erlVIoLlTW54QS2X-X9V0-lgOhWNql_7a6V86Hs8cjlGj7ksENIqKXXsACVhqn-DxMfXBnTrOBu8Zce4UmI_2gvYI1K22TR6Pb0ZP20BTQBPWTg98BIhrZj6xWnyhvzmQD5OMTZJyzbpeCzAKQ6demFsMi9-3_XxwPOSMf7CD9qAE4mzKulFkIqTd0aTy-xu71eO4G70uSGDBHCev6TsX7eapr6hNJ3sFRiFY0w" />
              <div className="absolute inset-0 bg-black/10"></div>
            </div>
            <div className="bg-white rounded-3xl overflow-hidden relative group">
              <img alt="Grid item 2" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAZv41xMpnu6yvVmg233Ngyo_D8urr51XY8teLatK7sXYb0x_Fm-31f_WfCOPfTjtdY7B5D1a_GI6bedEtKY4wjvOk_LLcqLZuZ-PSiC0HhuRIDES_okeKL9Xeinlv2xipxUqgJ0G1yJGhgdDc9uHi85mczWzeZPMCXK3_45ZUEIs6fMbZkSZhASLW_laiDXBnrCN8Y3K6Jw8fG__0o7BOFCwkQJwUqk3lloaKOTbBXLttQJxQYvXbLHw" />
              <div className="absolute inset-0 bg-black/10"></div>
            </div>
            <div className="bg-white rounded-3xl overflow-hidden relative group">
              <img alt="Grid item 3" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" src="https://lh3.googleusercontent.com/aida-public/AB6AXuA9vYnS41j-tNOkuF45TR4Wr4b0-wzLQ867inZYWeJaAzwCpglUIcObjHHBj8-X8pJgdu-yK4zGcl7z5sx_vG55rUNO5U0Blt9l6HZGJeGb9ABCOoHLoAop8HBJQzAArDKhK4z_RslrJ6XHDrZBKehV5wLY5aLDeO2wAv6v3_FDtwQs8wBob6HZkq07kLRXyhnbzuw8y0_9DpbfmNMrw0uOtLR8UYrZFSPyftK3EJO0ufOE0hwABfwS-A" />
              <div className="absolute inset-0 bg-black/10"></div>
            </div>
            <div className="bg-brand-lilac rounded-3xl overflow-hidden relative flex items-center justify-center p-8 group cursor-pointer hover:bg-brand-ink hover:text-white transition-colors duration-300">
              <div className="text-center">
                <span className="material-symbols-outlined text-4xl mb-2">arrow_forward</span>
                <h4 className="font-display-lg text-headline-md uppercase">View All</h4>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Section 5: Category Tiles */}
      <section className="pb-stack-lg">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-gutter">
          <a className="group flex flex-col items-center gap-4" href="#">
            <div className="w-full aspect-square rounded-full overflow-hidden bg-white editorial-shadow">
              <img alt="Shirts" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" src="https://lh3.googleusercontent.com/aida-public/AB6AXuC_9rB2o1eq5wTMdMFMjBU2QkpTCHW4uSbI7bFTTuFcJClQ7RLo5SBKlLcu-QhC-maqXlaK7zEKybu5hbz-iZ3JsP70j99Rh3K_LMAlStEcLFon7PPy3Ar3HTIpmcjBLHcJttKVFWt0_aIKpBBno0McMbvU4CYlzJ0Fz4fCZKOqanAdacNI0eulFyZw5EbGFMFZs61lrSslpZEbn3djFD9035qYAvCnq-LDZpRDbgLGdaRq_eFQR8VHZQ" />
            </div>
            <span className="font-display-lg text-body-lg uppercase tracking-widest text-brand-ink">Shirts</span>
          </a>
          <a className="group flex flex-col items-center gap-4" href="#">
            <div className="w-full aspect-square rounded-full overflow-hidden bg-white editorial-shadow">
              <img alt="T-Shirts" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBeDIIFeXVfKz1T64ej-xcWjJiq-MB0h80VGhFMvxARZNj6jrwxNstdEB0eyj0Us3JvnPLBzMuyhgizDi8XR4TuK28Fbn4gSukqPzIqVvJHg39zP6gfJCqYnmktG5VmRBDUHoSt_E2n7hg6wng49yyY8CLqqnCw4hKxpx6uvsAqlQAuYwxhNy4hA-QZuJMYELdqwhKOQ5usZyaWuVUio3Ew_tc9d18gXqiSUM7dV-kMD6i2fpy-IcQYQw" />
            </div>
            <span className="font-display-lg text-body-lg uppercase tracking-widest text-brand-ink">T-Shirts</span>
          </a>
          <a className="group flex flex-col items-center gap-4" href="#">
            <div className="w-full aspect-square rounded-full overflow-hidden bg-white editorial-shadow">
              <img alt="Jeans" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAP_wuSvaJW3IIcV1RUUw0ovdjBPAkUOPBrxA4Dj1xtvf8DW58NBQ2yACHhw7ceR450dEpffPUdm0b99hLpII7oBAupdm7zq2Jh7kRYCQV19ifkGtP87jQbIaIwh-1dP4FWKcbX9C2JFyYKKb8mDtBhWHFGftjjowZ6rcb8PVE0mYmcZl_6aYnF5tMxO2OmoHdstuSZMxyfIFPMVWhqJzm0Z1-9hjf6YPX7FltoCuEf1YZr8oi1-bVr3w" />
            </div>
            <span className="font-display-lg text-body-lg uppercase tracking-widest text-brand-ink">Jeans</span>
          </a>
          <a className="group flex flex-col items-center gap-4" href="#">
            <div className="w-full aspect-square rounded-full overflow-hidden bg-white editorial-shadow">
              <img alt="Trousers" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCza-fAe2hI3o79FF_pKFoPBxQeu_2AGElD-7Ca6c9iUGZZTsKpGpmXITtL4SoRKwSgim9dADliKiiFT74UUYVFLJ5EH9zFU58yjmYoqfQRikG2zjmQVgSfyMoBN1ykJeAoo5eAyTevNWw8tyS5odqtI8U8Hz8Svt-H6sH54VVM1pB0sHL67x322i5NufnfKvsQlSZu4Hl1PXEj13ugA0D_GmzjCKIEL1CaKJQF-PSiq4pXwx-Un0WIlA" />
            </div>
            <span className="font-display-lg text-body-lg uppercase tracking-widest text-brand-ink">Trousers</span>
          </a>
          <a className="group flex flex-col items-center gap-4" href="#">
            <div className="w-full aspect-square rounded-full overflow-hidden bg-white editorial-shadow">
              <img alt="Ethnic Wear" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDObv2DaIb6XK8m47P4THoIOO8nPbiIM6ZBNS7k0lEM_GKlKD1Pyn-BnRTb5nxXifjuY7BLeD01r8QPTInYBmg2f5YI1zobztGiQs6jmFwMSxzMhAbZDXLSHiiexlGZ7AutYbWkcqIG-rDbKzJduu7NOwQHfFEwTbTOHY69IqDppwTj_9VNDy1GkW8EdaDrumMbjT_Dr__l3RHpPoJexX0cl5QCeW0xtOJxopIqyx3OY-eVXLTs9-EPjA" />
            </div>
            <span className="font-display-lg text-body-lg uppercase tracking-widest text-brand-ink">Ethnic Wear</span>
          </a>
          <a className="group flex flex-col items-center gap-4" href="#">
            <div className="w-full aspect-square rounded-full overflow-hidden bg-white editorial-shadow">
              <img alt="Winter Wear" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAown7rGSCMTPx1MXakxm7u120-TjIInJ1ClKbcD3pLyvMbojdTn_WVX14TuKnmaNK-hMbHH3_Bm2vbGqB8bmoJRy6LUcQDQjtoGChThWM-XZi-KczEDxclE0a_PJfNGLK0ZveLACKPC3uxTgfj1OAaKa7rvejU9Tgkshe8FpZ01dRXH3GH_nj-afoQGV4XGYkazZ-PHC8SLpu5Z2UR5MV24iwGz-M9HFXOh_Uel4AKIBw3vrB5CxjtXw" />
            </div>
            <span className="font-display-lg text-body-lg uppercase tracking-widest text-brand-ink">Winter Wear</span>
          </a>
        </div>
      </section>
    </main>
  );
}
