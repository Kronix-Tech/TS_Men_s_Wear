export default function UixshuvoShippingReturns() {
  return (
    <main className="flex-grow w-full max-w-container-max mx-auto px-margin-mobile md:px-margin-desktop py-stack-md flex flex-col gap-stack-lg">

<section className="flex flex-col items-center text-center gap-6 mt-8">
<nav aria-label="Breadcrumb" className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-widest">
                Home <span className="mx-2">/</span> Help <span className="mx-2">/</span> <span className="text-primary">Shipping &amp; Returns</span>
</nav>
<h1 className="font-display-lg text-display-lg text-primary uppercase">SHIPPING &amp; RETURNS</h1>
</section>

<section className="w-full flex flex-col gap-8">
<div className="grid grid-cols-1 md:grid-cols-3 gap-gutter">

<div className="bg-surface-container-lowest rounded-xl p-8 flex flex-col items-center text-center gap-4 shadow-[0_8px_30px_rgb(0,0,0,0.04)] hover:-translate-y-1 transition-transform duration-300">
<span className="material-symbols-outlined text-secondary text-4xl" style={{"fontVariationSettings": "\'FILL\' 0"}}>local_shipping</span>
<h3 className="font-body-lg text-body-lg font-medium text-primary">STANDARD</h3>
<p className="font-body-md text-body-md text-on-surface-variant">3–5 business days</p>
<p className="font-label-sm text-label-sm bg-secondary-fixed text-on-secondary-fixed px-3 py-1 rounded-full mt-2">FREE OVER $50</p>
</div>

<div className="bg-surface-container-lowest rounded-xl p-8 flex flex-col items-center text-center gap-4 shadow-[0_8px_30px_rgb(0,0,0,0.04)] hover:-translate-y-1 transition-transform duration-300">
<span className="material-symbols-outlined text-secondary text-4xl" style={{"fontVariationSettings": "\'FILL\' 0"}}>flight_takeoff</span>
<h3 className="font-body-lg text-body-lg font-medium text-primary">EXPRESS</h3>
<p className="font-body-md text-body-md text-on-surface-variant">1–2 business days</p>
<p className="font-body-md text-body-md text-primary mt-2 font-medium">$9.99</p>
</div>

<div className="bg-surface-container-lowest rounded-xl p-8 flex flex-col items-center text-center gap-4 shadow-[0_8px_30px_rgb(0,0,0,0.04)] hover:-translate-y-1 transition-transform duration-300">
<span className="material-symbols-outlined text-secondary text-4xl" style={{"fontVariationSettings": "\'FILL\' 0"}}>payments</span>
<h3 className="font-body-lg text-body-lg font-medium text-primary">CASH ON DELIVERY</h3>
<p className="font-body-md text-body-md text-on-surface-variant">Available at checkout</p>
<p className="font-body-md text-body-md text-primary mt-2 font-medium">Standard fees apply</p>
</div>
</div>
</section>

<div className="w-full h-px bg-surface-variant mx-auto max-w-2xl"></div>

<section className="w-full flex flex-col gap-10">
<h2 className="font-headline-lg text-headline-lg md:font-headline-lg text-primary text-center uppercase tracking-widest">EASY 7-DAY RETURNS</h2>

<div className="grid grid-cols-1 md:grid-cols-3 gap-gutter">

<div className="bg-surface-container rounded-xl p-8 flex flex-col items-center text-center gap-6">
<div className="w-12 h-12 rounded-full bg-secondary text-on-secondary flex items-center justify-center font-headline-md text-headline-md" style={{"backgroundColor": "rgb(143, 176, 164)","color": "rgb(255, 255, 255)"}}>1</div>
<p className="font-body-md text-body-md text-on-surface">Request a return within 7 days of delivery.</p>
</div>

<div className="bg-surface-container rounded-xl p-8 flex flex-col items-center text-center gap-6">
<div className="w-12 h-12 rounded-full bg-secondary text-on-secondary flex items-center justify-center font-headline-md text-headline-md" style={{"backgroundColor": "rgb(143, 176, 164)","color": "rgb(255, 255, 255)"}}>2</div>
<p className="font-body-md text-body-md text-on-surface">Free pickup arranged from your registered address.</p>
</div>

<div className="bg-surface-container rounded-xl p-8 flex flex-col items-center text-center gap-6">
<div className="w-12 h-12 rounded-full bg-secondary text-on-secondary flex items-center justify-center font-headline-md text-headline-md" style={{"backgroundColor": "rgb(143, 176, 164)","color": "rgb(255, 255, 255)"}}>3</div>
<p className="font-body-md text-body-md text-on-surface">Refund processed in 3–5 business days after inspection.</p>
</div>
</div>

<div className="flex flex-col items-center gap-4 mt-4">
<span className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-widest">Refund Methods Available</span>
<div className="flex flex-wrap justify-center gap-3">
<span className="bg-surface-container-lowest border border-surface-variant text-on-surface font-label-sm text-label-sm rounded-full px-6 py-3 uppercase tracking-wider">UPI</span>
<span className="bg-surface-container-lowest border border-surface-variant text-on-surface font-label-sm text-label-sm rounded-full px-6 py-3 uppercase tracking-wider">Credit/Debit Card</span>
<span className="bg-surface-container-lowest border border-surface-variant text-on-surface font-label-sm text-label-sm rounded-full px-6 py-3 uppercase tracking-wider">Bank Transfer</span>
<span className="bg-surface-container-lowest border border-surface-variant text-on-surface font-label-sm text-label-sm rounded-full px-6 py-3 uppercase tracking-wider">Wallet</span>
</div>
</div>
</section>

<section className="w-full max-w-3xl mx-auto">
<div className="bg-surface-container-lowest rounded-xl p-stack-md shadow-[0_8px_40px_rgb(0,0,0,0.03)] border border-surface-variant/50">
<h3 className="font-headline-md text-headline-md text-primary mb-6">Policy Essentials</h3>
<ul className="list-none flex flex-col gap-4 font-body-md text-body-md text-on-surface-variant">
<li className="flex items-start gap-3">
<span className="material-symbols-outlined text-secondary mt-1" style={{"fontVariationSettings": "\'FILL\' 0","fontSize": "18px"}}>check</span>
<span className="">Items must be completely unworn, unwashed, and returned with all original tags attached.</span>
</li>
<li className="flex items-start gap-3">
<span className="material-symbols-outlined text-secondary mt-1" style={{"fontVariationSettings": "\'FILL\' 0","fontSize": "18px"}}>close</span>
<span className="">Innerwear, swimwear, and customized pieces are strictly non-returnable for hygiene reasons.</span>
</li>
<li className="flex items-start gap-3">
<span className="material-symbols-outlined text-secondary mt-1" style={{"fontVariationSettings": "\'FILL\' 0","fontSize": "18px"}}>sync_alt</span>
<span className="">Items purchased during clearance or flash sales are eligible for exchange only, no direct refunds.</span>
</li>
</ul>
</div>
</section>

<section className="w-full bg-surface-container rounded-xl p-stack-md flex flex-col md:flex-row items-center justify-between gap-6 mb-8">
<div className="flex flex-col gap-2 text-center md:text-left">
<h3 className="font-headline-md text-headline-md text-primary">Still have questions?</h3>
<p className="font-body-md text-body-md text-on-surface-variant">Our concierge team is available 24/7 to assist you.</p>
</div>
<a className="bg-primary text-on-primary font-body-md text-body-md rounded-full px-8 py-4 flex items-center gap-2 hover:bg-surface-tint transition-colors duration-300" href="#">
                CONTACT US <span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 0","fontSize": "20px"}}>arrow_forward</span>
</a>
</section>
</main>
  );
}