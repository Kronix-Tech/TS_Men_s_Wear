const fs = require('fs');

function convertPage(htmlPath, targetPath, componentName) {
    let html = fs.readFileSync(htmlPath, 'utf8');
    let mainMatch = html.match(/<main[\s\S]*?<\/main>/);
    if (mainMatch) {
        let main = mainMatch[0];
        
        // React attribute replacements
        main = main.replace(/class=/g, 'className=');
        main = main.replace(/for=/g, 'htmlFor=');
        main = main.replace(/<!--[\s\S]*?-->/g, ''); // remove comments
        
        // Self close img and input tags
        main = main.replace(/<img([^>]+)>/g, (match, p1) => {
            if(p1.trim().endsWith('/')) return match;
            return '<img' + p1 + ' />';
        });
        main = main.replace(/<input([^>]+)>/g, (match, p1) => {
            if(p1.trim().endsWith('/')) return match;
            return '<input' + p1 + ' />';
        });
        
        // Fix styles and custom tags
        main = main.replace(/style="font-variation-settings:\s*'FILL'\s*1;?"/g, 'style={{ fontVariationSettings: "\\\'FILL\\\' 1" }}');
        main = main.replace(/disabled=""/g, 'disabled={true}');
        
        // Any generic style="key: value"
        main = main.replace(/style="([^"]*)"/g, (match, p1) => {
             // Handle simple cases, might need more robust parser for complex styles
             if (p1.includes('font-variation-settings')) return match; // Already handled
             return 'style={{' + p1.split(';').filter(s=>s.trim()).map(s => { 
                let [k,v] = s.split(':'); 
                // camelCase the key
                k = k.trim().replace(/-([a-z])/g, (g) => g[1].toUpperCase());
                return `"${k}": "${v.trim()}"` 
             }).join(',') + '}}';
        });

        let comp = `export default function ${componentName}() {\n  return (\n    ${main}\n  );\n}`;
        fs.writeFileSync(targetPath, comp);
        console.log(`Successfully created ${targetPath}`);
    } else {
        console.log('No <main> tag found');
    }
}

// Convert Product Detail Page
const dir = 'src/app/product';
if (!fs.existsSync(dir)){
    fs.mkdirSync(dir);
}
convertPage('../stitch_minimalist_men_s_wear/men_s_wear_product_detail/code.html', 'src/app/product/page.tsx', 'ProductDetail');
