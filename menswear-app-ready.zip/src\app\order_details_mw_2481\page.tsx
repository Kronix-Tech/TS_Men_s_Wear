export default function OrderDetailsMw2481() {
  return (
    <main className="flex-1 px-margin-mobile md:px-margin-desktop py-xl max-w-container-max mx-auto w-full">

<div className="mb-xxl">
<nav className="flex text-label-sm text-on-surface-variant mb-4 font-label-sm">
<a className="hover:text-primary transition-colors" href="#">Orders</a>
<span className="mx-2">/</span>
<span className="text-primary font-medium">#MW-2481</span>
</nav>
<div className="flex flex-col md:flex-row md:items-end justify-between gap-md">
<div>
<h2 className="font-headline-lg text-headline-lg text-primary uppercase tracking-tight">ORDER #MW-2481</h2>
<div className="flex items-center gap-3 mt-2">
<span className="px-3 py-1 bg-surface-container-highest text-primary font-label-sm rounded-full text-label-sm tracking-wider">SHIPPED</span>
<span className="text-body-sm text-on-surface-variant font-body-sm">Aug 17, 2026</span>
</div>
</div>
</div>
</div>

<div className="grid grid-cols-1 lg:grid-cols-12 gap-gutter">

<div className="lg:col-span-8 space-y-lg">

<div className="bg-surface-container-lowest rounded-24 p-lg">
<h3 className="font-label-lg text-label-lg text-primary mb-6 uppercase tracking-wider">Items</h3>
<div className="space-y-4">

<div className="flex items-center justify-between pb-4 divider">
<div className="flex items-center gap-md">
<div className="w-16 h-16 rounded-8 overflow-hidden product-image-stroke bg-surface-container-low">
<img className="w-full h-full object-cover" data-alt="A neatly folded Sage Linen Shirt, premium men's clothing, studio lighting, white background, emphasizing fabric texture and calm minimalist aesthetic." src="https://lh3.googleusercontent.com/aida-public/AB6AXuB5JNBFTzwdzATHc7I_hshXBXq0VsEyFPX7RaXiARhDj-3_pWsslmFz6Tu6N5ItFDkrizx9rWasDmzbxgQwTTyA29_GNgYgx1G1_Q6uk7ULOCjUT8O81eGzYoaUZiJMuKyjq0qOCSZjJrKrQm5BLdmHA8iLgobZMDnWtkK8WmD327K5g_gak1tPIMYWIPUvSS8Of85v-sqpgIohpcKiVB6H7K_3u_Cj0z1N0lglBudW-zqUpewy9Hjx" />
</div>
<div>
<p className="font-body-md text-primary font-medium">Sage Linen Shirt</p>
<p className="font-body-sm text-on-surface-variant">Size: M</p>
</div>
</div>
<div className="text-right">
<p className="font-body-md text-primary">1x</p>
<p className="font-body-md text-primary font-medium">$85.00</p>
</div>
</div>

<div className="flex items-center justify-between pb-4 divider">
<div className="flex items-center gap-md">
<div className="w-16 h-16 rounded-8 overflow-hidden product-image-stroke bg-surface-container-low">
<img className="w-full h-full object-cover" data-alt="A pair of premium indigo Selvedge Jeans laid flat, studio lighting, clean white background, showcasing denim texture and stitching details, modern menswear style." src="https://lh3.googleusercontent.com/aida-public/AB6AXuA0IoOHaqEz3ZX1tuW8fthsROpcpdv06GbjD4-tjqKWviaNGBXxcSYqb6KsgAnXp4VI4r_wjGATUoV8mSN8V28XqrLQeXGi4iufH9rdfxaiqERMP_CCoeTRDcOQqiMDkJZ05ITDc0shUfH8evBX4-pQ7MVxsGT8DGddXoYSfobbREBjqkIzSQig2lWZd6LR2ZUGAESHxWCeDAwh_bQchfbIDqjMSWvLOa_K7jJiIqSk6XyNN049wy2c" />
</div>
<div>
<p className="font-body-md text-primary font-medium">Selvedge Jeans</p>
<p className="font-body-sm text-on-surface-variant">Size: 32</p>
</div>
</div>
<div className="text-right">
<p className="font-body-md text-primary">1x</p>
<p className="font-body-md text-primary font-medium">$145.00</p>
</div>
</div>

<div className="flex items-center justify-between">
<div className="flex items-center gap-md">
<div className="w-16 h-16 rounded-8 overflow-hidden product-image-stroke bg-surface-container-low">
<img className="w-full h-full object-cover" data-alt="A folded Heavyweight Tee in neutral grey, premium men's apparel, bright studio lighting, minimalist presentation on white background, focusing on fabric weight and quality." src="https://lh3.googleusercontent.com/aida-public/AB6AXuDyXTSpScC9oI-h4ReNbQNTqnxf7pXXSBHCXtrSdD8bzQDdqARl1gNi3yJYD06Q4w7sto9xEnm6rM_mHCi9ndWvgXIKZADOnIOADTDP9rWEuy3SRIPhmJnihhQmgCBCEBvIBwTcZ3itQAJqO2njjpQDOmCjTp-gEklxPR6gXrzmtT3-wsETHf5gLAwfE2BXuHbCxGw5rMRkUvsHzw8v1JqmDVf8fIPjm9vJni72slFwQVB6GwQ4f8hn" />
</div>
<div>
<p className="font-body-md text-primary font-medium">Heavyweight Tee</p>
<p className="font-body-sm text-on-surface-variant">Size: L</p>
</div>
</div>
<div className="text-right">
<p className="font-body-md text-primary">1x</p>
<p className="font-body-md text-primary font-medium">$45.00</p>
</div>
</div>
</div>
</div>

<div className="bg-surface-container-lowest rounded-24 p-lg">
<div className="flex items-center justify-between mb-6">
<h3 className="font-label-lg text-label-lg text-primary uppercase tracking-wider">Status Timeline</h3>
</div>
<div className="relative pl-6 space-y-8 mb-8 border-l-2 border-surface-variant ml-3">

<div className="relative">
<span className="absolute -left-[31px] bg-primary text-on-primary rounded-full w-5 h-5 flex items-center justify-center ring-4 ring-surface-container-lowest">
<span className="material-symbols-outlined text-[12px]">check</span>
</span>
<p className="font-body-md text-primary font-medium">Ordered</p>
<p className="font-body-sm text-on-surface-variant">Aug 16, 2026, 10:24 AM</p>
</div>

<div className="relative">
<span className="absolute -left-[31px] bg-primary text-on-primary rounded-full w-5 h-5 flex items-center justify-center ring-4 ring-surface-container-lowest">
<span className="material-symbols-outlined text-[12px]">check</span>
</span>
<p className="font-body-md text-primary font-medium">Packed</p>
<p className="font-body-sm text-on-surface-variant">Aug 17, 2026, 08:15 AM</p>
</div>

<div className="relative">
<span className="absolute -left-[31px] bg-primary text-on-primary rounded-full w-5 h-5 flex items-center justify-center ring-4 ring-surface-container-lowest">
<span className="material-symbols-outlined text-[12px]">check</span>
</span>
<p className="font-body-md text-primary font-medium">Shipped</p>
<p className="font-body-sm text-on-surface-variant">Aug 17, 2026, 02:30 PM</p>
</div>

<div className="relative opacity-50">
<span className="absolute -left-[31px] bg-surface-variant text-on-surface-variant rounded-full w-5 h-5 flex items-center justify-center ring-4 ring-surface-container-lowest">
</span>
<p className="font-body-md text-primary font-medium">Delivered</p>
<p className="font-body-sm text-on-surface-variant">Pending</p>
</div>
</div>
<div className="flex gap-4 items-end bg-surface p-4 rounded-xl">
<div className="flex-1">
<label className="font-label-lg text-label-lg text-on-surface-variant block mb-2 uppercase tracking-wider">Update status</label>
<select className="w-full bg-surface-container-lowest border border-outline-variant/30 rounded-8 py-3 px-4 focus:ring-1 focus:ring-sage-green focus:border-sage-green font-body-md text-primary transition-shadow">
<option>Out for Delivery</option>
<option>Delivered</option>
<option>Delayed</option>
</select>
</div>
<button className="h-[48px] px-8 bg-primary text-on-primary rounded-full font-label-lg text-label-lg uppercase tracking-wider hover:bg-primary/90 transition-colors">UPDATE</button>
</div>
</div>

<div className="bg-surface-container-lowest rounded-24 p-lg">
<h3 className="font-label-lg text-label-lg text-primary mb-4 uppercase tracking-wider">Internal Notes</h3>
<textarea className="w-full bg-surface border border-outline-variant/30 rounded-8 p-4 focus:ring-1 focus:ring-sage-green focus:border-sage-green font-body-md text-primary transition-shadow resize-none mb-4" placeholder="Add a note (only visible to staff)..." rows={3}></textarea>
<div className="flex justify-end">
<button className="text-primary font-label-lg text-label-lg hover:underline underline-offset-4 decoration-1">Save note</button>
</div>
</div>
</div>

<div className="lg:col-span-4 space-y-lg">

<div className="bg-surface-container-lowest rounded-24 p-lg">
<div className="flex items-center justify-between mb-4 pb-4 divider">
<h3 className="font-label-lg text-label-lg text-primary uppercase tracking-wider">Customer</h3>
<button className="text-on-surface-variant hover:text-primary transition-colors"><span className="material-symbols-outlined text-[20px]">edit</span></button>
</div>
<div className="flex items-center gap-4 mb-4">
<div className="w-12 h-12 rounded-full bg-surface-container-high flex items-center justify-center text-primary font-headline-md">JD</div>
<div>
<p className="font-body-md text-primary font-medium">John Doe</p>
<p className="font-body-sm text-on-surface-variant">2 Orders</p>
</div>
</div>
<div className="space-y-3">
<div className="flex items-center gap-3 text-body-sm">
<span className="material-symbols-outlined text-[18px] text-on-surface-variant">mail</span>
<a className="text-primary hover:underline" href="mailto:john@email.com">john@email.com</a>
</div>
<div className="flex items-center gap-3 text-body-sm">
<span className="material-symbols-outlined text-[18px] text-on-surface-variant">call</span>
<a className="text-primary hover:underline" href="tel:+15550123">+1 555-0123</a>
</div>
</div>
</div>

<div className="bg-surface-container-lowest rounded-24 p-lg">
<div className="flex items-center justify-between mb-4 pb-4 divider">
<h3 className="font-label-lg text-label-lg text-primary uppercase tracking-wider">Shipping Address</h3>
<button className="text-on-surface-variant hover:text-primary transition-colors"><span className="material-symbols-outlined text-[20px]">content_copy</span></button>
</div>
<address className="font-body-sm text-primary not-italic leading-relaxed">John Doe<br />123 Maple St, Apt 4B<br />New York, NY 10001<br />United States</address>
</div>

<div className="bg-surface-container-lowest rounded-24 p-lg">
<h3 className="font-label-lg text-label-lg text-primary mb-4 pb-4 divider uppercase tracking-wider">Payment Summary</h3>
<div className="space-y-3 mb-4 pb-4 divider font-body-sm">
<div className="flex justify-between">
<span className="text-on-surface-variant">Subtotal</span>
<span className="text-primary font-medium">$275.00</span>
</div>
<div className="flex justify-between text-sage-green">
<span className="">Discount</span>
<span className="font-medium">-$40.00</span>
</div>
<div className="flex justify-between">
<span className="text-on-surface-variant">Shipping</span>
<span className="text-primary font-medium uppercase text-[12px]">Free</span>
</div>
</div>
<div className="flex justify-between items-center mb-6">
<span className="font-label-lg text-label-lg text-primary uppercase tracking-wider">Total</span>
<span className="font-headline-md text-headline-md text-primary">$235.00</span>
</div>
<div className="flex items-center gap-2 text-body-sm text-on-surface-variant bg-surface p-3 rounded-8">
<span className="material-symbols-outlined text-[18px]">credit_card</span>
                            Paid via Card ending in 4242
                        </div>
</div>

<div className="bg-surface-container-lowest rounded-24 p-lg">
<h3 className="font-label-lg text-label-lg text-primary mb-4 pb-4 divider uppercase tracking-wider">Actions</h3>
<div className="space-y-4">
<div>
<label className="font-label-lg text-label-lg text-on-surface-variant block mb-2 uppercase tracking-wider text-[11px]">AWB Number</label>
<input className="w-full bg-surface border border-outline-variant/30 rounded-8 py-3 px-4 focus:ring-1 focus:ring-sage-green focus:border-sage-green font-body-md text-primary transition-shadow" type="text" value="TRK-9876543210" />
</div>
<button className="w-full h-[48px] bg-primary text-on-primary rounded-full font-label-lg text-label-lg uppercase tracking-wider hover:bg-primary/90 transition-colors">SHIP ORDER</button>
<button className="w-full h-[48px] border border-primary text-primary rounded-full font-label-lg text-label-lg uppercase tracking-wider hover:bg-surface-container-low transition-colors">DOWNLOAD INVOICE</button>
<div className="pt-4 mt-4 divider border-t-0">
<button className="w-full h-[48px] border border-error text-error rounded-full font-label-lg text-label-lg uppercase tracking-wider hover:bg-error-container/20 transition-colors">CANCEL ORDER</button>
</div>
</div>
</div>
</div>
</div>
</main>
  );
}