export default function UixshuvoRefinedCheckoutFinalHeaderAssets() {
  return (
    <main className="max-w-container-max mx-auto px-margin-mobile md:px-margin-desktop py-stack-lg">


<header className="mb-stack-md flex justify-between items-center border-b border-outline-variant/30 pb-6"><a className="font-display-lg text-[32px] text-primary uppercase tracking-[0.15em] m-0" href="/">MEN'S WEAR</a><div className="flex items-center gap-2 bg-surface-container px-4 py-2 rounded-full text-on-surface-variant font-label-sm text-label-sm uppercase tracking-widest"><span className="material-symbols-outlined text-[18px]">lock</span> Secure Checkout</div></header>
<nav className="mb-gutter text-on-surface-variant font-label-sm text-label-sm uppercase tracking-widest">
<a className="hover:text-primary transition-colors" href="#">Home</a>
<span className="mx-2 text-outline-variant">/</span>
<a className="hover:text-primary transition-colors" href="#">Cart</a>
<span className="mx-2 text-outline-variant">/</span>
<span className="text-primary font-bold">Checkout</span>
</nav>

<header className="mb-stack-md flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
<h1 className="font-display-lg text-display-lg text-primary uppercase tracking-[0.15em] m-0">CHECKOUT</h1>

<div className="flex gap-3 overflow-x-auto pb-2 md:pb-0 w-full md:w-auto hide-scrollbar">
<div className="flex items-center gap-2 bg-ink text-white px-6 py-3 rounded-full font-label-sm text-label-sm whitespace-nowrap">
<span className="">1</span> SHIPPING
                </div>
<div className="flex items-center gap-2 bg-muted-lilac text-on-surface-variant px-6 py-3 rounded-full font-label-sm text-label-sm whitespace-nowrap">
<span className="">2</span> PAYMENT
                </div>
<div className="flex items-center gap-2 bg-muted-lilac text-on-surface-variant px-6 py-3 rounded-full font-label-sm text-label-sm whitespace-nowrap">
<span className="">3</span> REVIEW
                </div>
</div>
</header>

<div className="grid grid-cols-1 lg:grid-cols-12 gap-gutter">

<div className="lg:col-span-8 flex flex-col gap-stack-md">

<section>
<h2 className="font-headline-md text-headline-md text-primary mb-6">Shipping Address</h2>
<div className="grid grid-cols-1 md:grid-cols-2 gap-4">

<label className="block relative bg-surface-container-lowest rounded-[24px] p-6 ambient-shadow cursor-pointer border border-ink transition-all">
<div className="flex justify-between items-start mb-4">
<div className="flex items-center gap-3">
<input defaultChecked={true} className="custom-radio accent-ink" name="address" type="radio" />
<span className="font-body-md text-body-md font-bold text-primary">Home</span>
</div>
<span className="material-symbols-outlined text-outline-variant hover:text-primary transition-colors" data-icon="edit">edit</span>
</div>
<div className="font-body-md text-body-md text-on-surface-variant">
<p className="text-primary mb-1">John Doe</p>
<p className="">123 Maple St, Apt 4B</p>
<p className="">New York, NY 10001</p>
<p className="">United States</p>
<p className="mt-2">+1 (555) 123-4567</p>
</div>
</label>

<label className="block relative bg-surface-container-lowest rounded-[24px] p-6 ambient-shadow cursor-pointer border border-transparent hover:border-outline-variant transition-all">
<div className="flex justify-between items-start mb-4">
<div className="flex items-center gap-3">
<input className="custom-radio accent-ink" name="address" type="radio" />
<span className="font-body-md text-body-md font-bold text-primary">Work</span>
</div>
<span className="material-symbols-outlined text-outline-variant hover:text-primary transition-colors" data-icon="edit">edit</span>
</div>
<div className="font-body-md text-body-md text-on-surface-variant">
<p className="text-primary mb-1">John Doe</p>
<p className="">456 Business Ave, Suite 900</p>
<p className="">New York, NY 10002</p>
<p className="">United States</p>
<p className="mt-2">+1 (555) 987-6543</p>
</div>
</label>

<button className="flex flex-col items-center justify-center gap-3 h-full min-h-[200px] rounded-[24px] border-2 border-dashed border-outline-variant text-on-surface-variant hover:border-primary hover:text-primary transition-colors bg-transparent" type="button">
<span className="material-symbols-outlined text-[32px]" data-icon="add_circle">add_circle</span>
<span className="font-label-sm text-label-sm uppercase tracking-widest">Add new address</span>
</button>
</div>
</section>
<hr className="border-outline-variant/30" />

<section>
<h2 className="font-headline-md text-headline-md text-primary mb-6">Delivery Method</h2>
<div className="flex flex-col gap-4">
<label className="flex items-center justify-between p-4 rounded-xl hover:bg-muted-lilac/50 transition-colors cursor-pointer">
<div className="flex items-center gap-4">
<input defaultChecked={true} className="custom-radio accent-ink" name="delivery" type="radio" />
<div>
<span className="block font-body-md text-body-md font-bold text-primary">Standard</span>
<span className="block text-sm text-on-surface-variant">3–5 business days</span>
</div>
</div>
<span className="font-label-sm text-label-sm uppercase text-sage">FREE</span>
</label>
<label className="flex items-center justify-between p-4 rounded-xl hover:bg-muted-lilac/50 transition-colors cursor-pointer">
<div className="flex items-center gap-4">
<input className="custom-radio accent-ink" name="delivery" type="radio" />
<div>
<span className="block font-body-md text-body-md font-bold text-primary">Express</span>
<span className="block text-sm text-on-surface-variant">1–2 business days</span>
</div>
</div>
<span className="font-body-md text-body-md text-primary">$9.99</span>
</label>
</div>
</section>
<hr className="border-outline-variant/30" />

<section>
<h2 className="font-headline-md text-headline-md text-primary mb-6">Payment</h2>
<div className="flex flex-col gap-4">

<div className="bg-surface-container-lowest rounded-[24px] border border-outline-variant/50 overflow-hidden transition-all focus-within:border-primary">
<label className="flex items-center justify-between p-6 cursor-pointer">
<div className="flex items-center gap-4">
<input className="custom-radio accent-ink" name="payment" type="radio" />
<span className="font-body-md text-body-md font-bold text-primary">UPI</span>
</div>
<span className="material-symbols-outlined text-outline" data-icon="qr_code_scanner">qr_code_scanner</span>
</label>
<div className="px-6 pb-6 hidden">
<input className="w-full input-underline font-body-md text-body-md py-2" placeholder="Enter UPI ID (e.g. name@bank)" type="text" />
</div>
</div>

<div className="bg-surface-container-lowest rounded-[24px] border border-ink overflow-hidden transition-all ambient-shadow">
<label className="flex items-center justify-between p-6 cursor-pointer">
<div className="flex items-center gap-4">
<input defaultChecked={true} className="custom-radio accent-ink" name="payment" type="radio" />
<span className="font-body-md text-body-md font-bold text-primary">Credit/Debit Card</span>
</div>
<div className="flex gap-2">
<span className="material-symbols-outlined text-outline" data-icon="credit_card">credit_card</span>
</div>
</label>
<div className="px-6 pb-6 space-y-6">
<input className="w-full input-underline font-body-md text-body-md py-2" placeholder="Card Number" type="text" />
<div className="grid grid-cols-2 gap-6">
<input className="w-full input-underline font-body-md text-body-md py-2" placeholder="MM/YY" type="text" />
<input className="w-full input-underline font-body-md text-body-md py-2" placeholder="CVV" type="text" />
</div>
<input className="w-full input-underline font-body-md text-body-md py-2" placeholder="Name on Card" type="text" />
</div>
</div>

<div className="bg-surface-container-lowest rounded-[24px] border border-outline-variant/50 overflow-hidden transition-all">
<label className="flex items-center justify-between p-6 cursor-pointer">
<div className="flex items-center gap-4">
<input className="custom-radio accent-ink" name="payment" type="radio" />
<span className="font-body-md text-body-md font-bold text-primary">Cash on Delivery</span>
</div>
<span className="material-symbols-outlined text-outline" data-icon="payments">payments</span>
</label>
</div>

<div className="bg-surface-container-lowest rounded-[24px] border border-outline-variant/50 overflow-hidden transition-all">
<label className="flex items-center justify-between p-6 cursor-pointer">
<div className="flex items-center gap-4">
<input className="custom-radio accent-ink" name="payment" type="radio" />
<span className="font-body-md text-body-md font-bold text-primary">Net Banking</span>
</div>
<span className="material-symbols-outlined text-outline" data-icon="account_balance">account_balance</span>
</label>
</div>
</div>
</section>
</div>

<div className="lg:col-span-4 mt-8 lg:mt-0">
<div className="sticky top-8 bg-surface-container-lowest rounded-[24px] p-8 ambient-shadow flex flex-col gap-8">
<h3 className="font-headline-md text-headline-md text-primary">Order Summary</h3>

<div className="flex flex-col gap-4">
<div className="flex items-center gap-4"><div className="relative w-16 h-20 bg-muted-lilac rounded-lg overflow-hidden flex-shrink-0"><img className="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAfeWJ69wLb8IMGNC09NkoRyQYatUIQzFRqoc3s7iI6rltxYCHiiLiGvibqxmwa1v8XUbtCdL8kVrq7uC8O087Rlf2qIUwzxXy3A6bYZw8D8e57kKhK8bMhT31DPgIxcf1h1CbFMp6bzsyLVhtWNKZbjnovDlDqdlgtIjqsACF4lDbEM-1Bs874oSNNjHpy07uw7I5koqh6NsPiiCdNyms5npZ3Iw5SpoiU7yS6c_emAY88bZNNraRtyA" /><span className="absolute -top-2 -right-2 bg-ink text-white w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold z-10 border border-white">1</span></div><div className="flex-1"><p className="font-body-md text-body-md text-primary line-clamp-1">Sage Linen Shirt</p><p className="text-sm text-on-surface-variant">Sage / L</p></div><span className="font-body-md text-body-md text-primary whitespace-nowrap">$85.00</span></div>
<div className="flex items-center gap-4"><div className="relative w-16 h-20 bg-muted-lilac rounded-lg overflow-hidden flex-shrink-0"><img alt="Selvedge Jeans" className="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAiFIVFJrJVBxhuYxFFabyukdvVzUFfJegIZmQArR5MHz0rcCsk-FEeOX5vOongV1UBm7IcIGfqm205M4uNWopp5T10o9_IwN9hfkx_Wxfl-TbE6eFC5xeUHVpr1JJMKuyr5-Fnp7IjjAqF2-P48oMBjjmtAd2HmM95mwKq2HLyt3-U9SlbJGVsErUCMm4Z16qmy8KrILHGNIPmRCxy60RVvsUGzHOYcz5MAjxY3BadvuUL_nAfcSCKXA" /><span className="absolute -top-2 -right-2 bg-ink text-white w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold z-10 border border-white">1</span></div><div className="flex-1"><p className="font-body-md text-body-md text-primary line-clamp-1">Selvedge Jeans</p><p className="text-sm text-on-surface-variant">Indigo / 32</p></div><span className="font-body-md text-body-md text-primary whitespace-nowrap">$145.00</span></div>
<div className="flex items-center gap-4"><div className="relative w-16 h-20 bg-muted-lilac rounded-lg overflow-hidden flex-shrink-0"><img className="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAnHd-48M9CMV4C_TgZ15hSUb2qBsoqx7ePOJrPdZDfZOn0-KFYeo0iWVfRoRbTWvIMkHs5Wt578QDSe21YiF70NE-MwdpJE09ClkxDHNImWNzJ1xoT7kq-aYXmJaki5SkVq5UQ6idV0z45JZzfEIApfEUzMUVUUVo19U3wEOnZkC4MMLPingDA4uI8jDTJ1pkzsKCDk1YzlVtSBeCzYYAH7PKpkwpLpS1MWR5lktsClihcWm8IQ6pJoQ" /><span className="absolute -top-2 -right-2 bg-ink text-white w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold z-10 border border-white">1</span></div><div className="flex-1"><p className="font-body-md text-body-md text-primary line-clamp-1">Heavyweight Tee</p><p className="text-sm text-on-surface-variant">Grey / L</p></div><span className="font-body-md text-body-md text-primary whitespace-nowrap">$45.00</span></div>
</div>

<div className="flex items-center justify-between bg-muted-lilac/30 rounded-full px-4 py-2 border border-sage/20">
<div className="flex items-center gap-2 text-sage">
<span className="material-symbols-outlined text-[16px]" data-icon="local_offer">local_offer</span>
<span className="font-label-sm text-label-sm uppercase">ARUN20 applied</span>
</div>
<span className="text-sage font-body-md text-body-md">−$40.00</span>
</div>
<hr className="border-outline-variant/30" />

<div className="flex flex-col gap-3 font-body-md text-body-md text-on-surface-variant">
<div className="flex justify-between">
<span className="">Subtotal</span>
<span className="text-primary">$275.00</span>
</div>
<div className="flex justify-between text-sage">
<span className="">Discount</span>
<span className="">−$40.00</span>
</div>
<div className="flex justify-between">
<span className="">Shipping</span>
<span className="text-sage font-label-sm uppercase tracking-widest mt-1">FREE</span>
</div>
</div>
<hr className="border-ink" />

<div className="flex justify-between items-end">
<span className="font-body-md text-body-md text-primary uppercase tracking-widest">Total</span>
<span className="font-headline-lg text-headline-lg text-primary leading-none">$235.00</span>
</div>

<button className="w-full bg-ink text-white font-body-md text-body-md font-medium py-4 px-6 rounded-full flex justify-center items-center gap-2 hover:bg-black transition-colors hover:-translate-y-1 hover:shadow-lg duration-300 ease-out mt-4">
                        PLACE ORDER <span className="material-symbols-outlined text-[20px]" data-icon="arrow_forward">arrow_forward</span>
</button>

<div className="flex items-center justify-center gap-2 text-on-surface-variant text-sm mt-2">
<span className="material-symbols-outlined text-[16px]" data-icon="lock">lock</span>
<span className="">Secure encrypted checkout</span>
</div>
</div>
</div>
</div>
</main>
  );
}