export default function UixshuvoRefinedSizeGuideFaqBrandAligned() {
  return (
    <main className="pt-32 pb-stack-lg max-w-container-max mx-auto px-margin-mobile md:px-margin-desktop flex flex-col items-center">

<nav className="w-full flex items-center space-x-2 text-on-surface-variant mb-12">
<a className="font-label-sm text-label-sm hover:text-primary transition-colors" href="#">Home</a>
<span className="font-label-sm text-label-sm">/</span>
<a className="font-label-sm text-label-sm hover:text-primary transition-colors" href="#">Help</a>
<span className="font-label-sm text-label-sm">/</span>
<span className="font-label-sm text-label-sm text-primary">Size Guide</span>
</nav>

<h1 className="font-display-lg text-display-lg text-center uppercase tracking-widest mb-12 w-full">
            SIZE GUIDE &amp; FAQ
        </h1>

<div className="flex items-center justify-center space-x-4 mb-stack-md">
<button className="px-8 py-3 rounded-full bg-[#141414] text-white font-label-sm text-label-sm uppercase tracking-wider transition-all hover:opacity-90 active:scale-95 shadow-soft" id="tab-size-guide">
                SIZE GUIDE
            </button>
<button className="px-8 py-3 rounded-full border border-[#141414] text-[#141414] bg-transparent font-label-sm text-label-sm uppercase tracking-wider transition-all hover:bg-surface-variant active:scale-95" id="tab-faq">
                FAQ
            </button>
</div>
<div className="w-full max-w-4xl grid grid-cols-1 gap-stack-md">

<section className="flex flex-col space-y-12 animate-fade-in" id="section-size-guide">

<div className="flex flex-wrap justify-center gap-3">
<button className="px-6 py-2 rounded-full bg-[#8FB0A4] text-white font-label-sm text-label-sm uppercase tracking-wider transition-all hover:opacity-90">Shirts</button>
<button className="px-6 py-2 rounded-full bg-white text-[#141414] font-label-sm text-label-sm uppercase tracking-wider transition-all hover:bg-surface-variant shadow-soft">T-Shirts</button>
<button className="px-6 py-2 rounded-full bg-white text-[#141414] font-label-sm text-label-sm uppercase tracking-wider transition-all hover:bg-surface-variant shadow-soft">Jeans</button>
<button className="px-6 py-2 rounded-full bg-white text-[#141414] font-label-sm text-label-sm uppercase tracking-wider transition-all hover:bg-surface-variant shadow-soft">Trousers</button>
</div>

<div className="bg-white rounded-[24px] p-8 md:p-12 shadow-soft flex flex-col relative overflow-hidden">
<div className="overflow-x-auto">
<table className="w-full text-left border-collapse">
<thead>
<tr className="border-b border-[#E7E5EE]">
<th className="py-4 px-6 font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider">Size</th>
<th className="py-4 px-6 font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider">Chest</th>
<th className="py-4 px-6 font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider">Waist</th>
<th className="py-4 px-6 font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider">Length</th>
</tr>
</thead>
<tbody className="font-body-md text-body-md">
<tr className="hover:bg-[#F5F4F8] transition-colors border-b border-[#E7E5EE]/50">
<td className="py-4 px-6 font-bold">S</td>
<td className="py-4 px-6">36 - 38</td>
<td className="py-4 px-6">28 - 30</td>
<td className="py-4 px-6">28.5</td>
</tr>
<tr className="bg-[#E7E5EE]/30 hover:bg-[#F5F4F8] transition-colors border-b border-[#E7E5EE]/50">
<td className="py-4 px-6 font-bold">M</td>
<td className="py-4 px-6">38 - 40</td>
<td className="py-4 px-6">30 - 32</td>
<td className="py-4 px-6">29.5</td>
</tr>
<tr className="hover:bg-[#F5F4F8] transition-colors border-b border-[#E7E5EE]/50">
<td className="py-4 px-6 font-bold">L</td>
<td className="py-4 px-6">40 - 42</td>
<td className="py-4 px-6">32 - 34</td>
<td className="py-4 px-6">30.5</td>
</tr>
<tr className="bg-[#E7E5EE]/30 hover:bg-[#F5F4F8] transition-colors border-b border-[#E7E5EE]/50">
<td className="py-4 px-6 font-bold">XL</td>
<td className="py-4 px-6">42 - 44</td>
<td className="py-4 px-6">34 - 36</td>
<td className="py-4 px-6">31.5</td>
</tr>
<tr className="hover:bg-[#F5F4F8] transition-colors">
<td className="py-4 px-6 font-bold">XXL</td>
<td className="py-4 px-6">44 - 46</td>
<td className="py-4 px-6">36 - 38</td>
<td className="py-4 px-6">32.5</td>
</tr>
</tbody>
</table>
</div>
<div className="mt-8 flex items-center">
<span className="inline-block px-4 py-1.5 rounded-full bg-[#E7E5EE] text-[#141414] font-label-sm text-[10px] uppercase tracking-wider">
                            Measurements in inches
                        </span>
</div>
</div>

<div className="bg-[#E7E5EE]/50 rounded-[24px] p-8 md:p-12 flex flex-col">
<h3 className="font-headline-md text-headline-md mb-8 text-center uppercase tracking-widest">How To Measure</h3>
<div className="grid grid-cols-1 md:grid-cols-3 gap-8">

<div className="flex flex-col items-center text-center space-y-4">
<div className="w-24 h-24 rounded-full bg-white flex items-center justify-center shadow-soft mb-2">
<span className="material-symbols-outlined text-4xl text-[#8FB0A4]">straighten</span>
</div>
<h4 className="font-label-sm text-label-sm uppercase tracking-wider">Chest</h4>
<p className="font-body-md text-sm text-on-surface-variant max-w-[200px]">Measure under your arms, around the fullest part of your chest.</p>
</div>

<div className="flex flex-col items-center text-center space-y-4">
<div className="w-24 h-24 rounded-full bg-white flex items-center justify-center shadow-soft mb-2">
<span className="material-symbols-outlined text-4xl text-[#8FB0A4]">width_full</span>
</div>
<h4 className="font-label-sm text-label-sm uppercase tracking-wider">Waist</h4>
<p className="font-body-md text-sm text-on-surface-variant max-w-[200px]">Measure around your natural waistline, keeping the tape a bit loose.</p>
</div>

<div className="flex flex-col items-center text-center space-y-4">
<div className="w-24 h-24 rounded-full bg-white flex items-center justify-center shadow-soft mb-2">
<span className="material-symbols-outlined text-4xl text-[#8FB0A4]">pan_tool_alt</span>
</div>
<h4 className="font-label-sm text-label-sm uppercase tracking-wider">Sleeve Length</h4>
<p className="font-body-md text-sm text-on-surface-variant max-w-[200px]">Measure from the center back of your neck to your wrist bone.</p>
</div>
</div>
</div>
</section>

<section className="flex flex-col space-y-8 animate-fade-in mt-stack-md border-t border-[#E7E5EE] pt-stack-md" id="section-faq">
<h2 className="font-headline-lg text-headline-lg text-center uppercase tracking-widest mb-4">Frequently Asked Questions</h2>
<div className="flex flex-col divide-y divide-[#E7E5EE]">

<div className="accordion-item py-6 cursor-pointer group">
<div className="flex justify-between items-center w-full group-hover:text-primary transition-colors">
<h3 className="font-body-lg text-body-lg font-medium pr-8">How long does delivery take?</h3>
<span className="material-symbols-outlined accordion-icon transition-transform duration-300 text-on-surface-variant group-hover:text-primary">add</span>
</div>
<div className="accordion-content">
<p className="font-body-md text-body-md text-on-surface-variant pt-4 pr-12">
                                Standard delivery typically takes 3-5 business days within the continental US. Express shipping options are available at checkout for 1-2 day delivery.
                            </p>
</div>
</div>

<div className="accordion-item py-6 cursor-pointer group">
<div className="flex justify-between items-center w-full group-hover:text-primary transition-colors">
<h3 className="font-body-lg text-body-lg font-medium pr-8">What is the return policy?</h3>
<span className="material-symbols-outlined accordion-icon transition-transform duration-300 text-on-surface-variant group-hover:text-primary">add</span>
</div>
<div className="accordion-content">
<p className="font-body-md text-body-md text-on-surface-variant pt-4 pr-12">
                                We accept returns within 30 days of purchase. Items must be unworn, unwashed, and with all original tags attached. Return shipping is free for domestic orders.
                            </p>
</div>
</div>

<div className="accordion-item py-6 cursor-pointer group">
<div className="flex justify-between items-center w-full group-hover:text-primary transition-colors">
<h3 className="font-body-lg text-body-lg font-medium pr-8">How do I exchange a size?</h3>
<span className="material-symbols-outlined accordion-icon transition-transform duration-300 text-on-surface-variant group-hover:text-primary">add</span>
</div>
<div className="accordion-content">
<p className="font-body-md text-body-md text-on-surface-variant pt-4 pr-12">
                                The fastest way to exchange an item is to return the original item for a refund and place a new order for the desired size. You can initiate a return through our portal.
                            </p>
</div>
</div>

<div className="accordion-item py-6 cursor-pointer group">
<div className="flex justify-between items-center w-full group-hover:text-primary transition-colors">
<h3 className="font-body-lg text-body-lg font-medium pr-8">Is Cash on Delivery available?</h3>
<span className="material-symbols-outlined accordion-icon transition-transform duration-300 text-on-surface-variant group-hover:text-primary">add</span>
</div>
<div className="accordion-content">
<p className="font-body-md text-body-md text-on-surface-variant pt-4 pr-12">
                                We currently do not offer Cash on Delivery. We accept all major credit cards, PayPal, Apple Pay, and Google Pay for secure transactions.
                            </p>
</div>
</div>

<div className="accordion-item py-6 cursor-pointer group">
<div className="flex justify-between items-center w-full group-hover:text-primary transition-colors">
<h3 className="font-body-lg text-body-lg font-medium pr-8">How do I care for linen fabric?</h3>
<span className="material-symbols-outlined accordion-icon transition-transform duration-300 text-on-surface-variant group-hover:text-primary">add</span>
</div>
<div className="accordion-content">
<p className="font-body-md text-body-md text-on-surface-variant pt-4 pr-12">
                                Machine wash cold on a gentle cycle. Hang to dry or tumble dry on low. Iron on medium heat while slightly damp for best results. Do not bleach.
                            </p>
</div>
</div>

<div className="accordion-item py-6 cursor-pointer group">
<div className="flex justify-between items-center w-full group-hover:text-primary transition-colors">
<h3 className="font-body-lg text-body-lg font-medium pr-8">How do I track my order?</h3>
<span className="material-symbols-outlined accordion-icon transition-transform duration-300 text-on-surface-variant group-hover:text-primary">add</span>
</div>
<div className="accordion-content">
<p className="font-body-md text-body-md text-on-surface-variant pt-4 pr-12">
                                Once your order ships, you will receive a confirmation email with a tracking number. You can also view your order status by logging into your account dashboard.
                            </p>
</div>
</div>
</div>
</section>
</div>
</main>
  );
}