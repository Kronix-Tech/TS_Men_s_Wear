export default function AddProductUpdatedNavMenSWear() {
  return (
    <main className="flex-1 ml-0 md:ml-64 flex flex-col min-h-screen">

<header className="h-16 flex justify-between items-center px-margin-desktop w-full sticky top-0 z-30 bg-brand-bg/80 backdrop-blur-md"><div className="flex-1 flex items-center md:hidden">
<button className="text-brand-ink p-2 -ml-2">
<span className="material-symbols-outlined">menu</span>
</button>
</div>
<div className="flex-1 hidden md:flex">
<div className="relative w-full max-w-md">
<span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-outline">search</span>
<input className="w-full bg-white rounded-full pl-10 pr-4 py-2 text-sm border-none shadow-sm focus:ring-1 focus:ring-brand-accent outline-none" placeholder="Search products..." type="text"/>
</div>
</div>
<div className="flex items-center gap-4">
<button className="text-brand-ink hover:text-primary transition-colors duration-200 relative">
<span className="material-symbols-outlined">notifications</span>
<span className="absolute top-0 right-0 w-2 h-2 bg-error rounded-full"></span>
</button>
<div className="h-8 w-8 rounded-full bg-outline-variant/30 overflow-hidden border border-outline-variant/20">
<img alt="Admin profile avatar" className="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCkRX24vQlmRzCfENtcsOMI-x_vqW_-gAnY8btO2R1B_wisIMcDgORrJGiSZl3Yyg6ZgEzhUEe5-3azJ8epYqppbw-eiz_0LsOO-LK2XihuGsIeNjUFAxuchb51ZMvjULKC7NoQRSt6zDOZ6-bqJ4LaEMOlRT7269mjCgJr6haJ8uIriQKzxeA21z2vjug6nJdGzdtw8KYc5M1UINolWzYDyfBCCfW_r7J5A5SdDa9R5vqgaxTsfGdL"/>
</div>
</div></header>

<div className="p-margin-mobile md:p-margin-desktop max-w-[1200px] w-full mx-auto pb-xxl">

<div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-xl">
<div>
<a className="inline-flex items-center text-sm font-label-lg text-on-surface-variant hover:text-brand-ink transition-colors mb-2" href="#">
<span className="material-symbols-outlined text-[16px] mr-1">arrow_back</span>
                        Back to Products
                    </a>
<h2 className="font-headline-lg text-headline-lg font-medium text-brand-ink">ADD PRODUCT</h2>
</div>
<div className="flex items-center gap-3">
<button className="px-6 py-3 rounded-full border border-brand-ink text-brand-ink font-label-lg hover:bg-black/5 transition-colors">
                        CANCEL
                    </button>
<button className="px-6 py-3 rounded-full bg-brand-ink text-white font-label-lg flex items-center gap-2 hover:bg-black transition-colors shadow-interactive">
                        SAVE PRODUCT
                        <span className="material-symbols-outlined text-[18px]">arrow_forward</span>
</button>
</div>
</div>

<div className="grid grid-cols-1 lg:grid-cols-12 gap-gutter">

<div className="lg:col-span-8 flex flex-col gap-8">

<section className="card-container">
<h3 className="font-label-lg text-brand-ink uppercase tracking-widest mb-6">General Information</h3>
<div className="space-y-6">
<div>
<label className="input-label">Product Name</label>
<input className="input-field" placeholder="e.g. Classic Oxford Button-Down" type="text"/>
</div>
<div>
<label className="input-label">Description</label>
<textarea className="input-field min-h-[120px] resize-y" placeholder="Describe the fabric, fit, and style..."></textarea>
</div>
<div>
<label className="input-label mb-3">Product Images</label>
<div className="flex flex-wrap gap-4">
<div className="w-24 h-32 rounded-lg border border-outline-variant/30 overflow-hidden relative group cursor-pointer">
<img className="w-full h-full object-cover" data-alt="A clean, flat-lay studio shot of a crisp white men's oxford shirt on a pure white background. Soft, even lighting highlights the texture of the cotton fabric. Minimalist luxury e-commerce style, no harsh shadows." src="https://lh3.googleusercontent.com/aida-public/AB6AXuCdTCX0jVGX2L3Hx50LjFayekHvFlBHr57WBX-gsLQoAPNTTs5ZTTwxGSFk83PZq0bXEQqj8dsQoCz_7rH8s9edZfSKdatOEI8PV_NEPS7ETDkQTlLcIQ7mWaHE99mK844ArDQfN8mZqcv7EuMxA7c_KC2sK_I-qUv82fTsPzDeIcSNAaxf5Ibl2M1rBDMcjhRf6V-Q-Vf2gHeqt4e9ElYyaaiRz8gBJbH9cLVfjuDzwuD9zwdCv64n"/>
<div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
<span className="material-symbols-outlined text-white">delete</span>
</div>
</div>
<div className="w-24 h-32 rounded-lg border border-outline-variant/30 overflow-hidden relative group cursor-pointer">
<img className="w-full h-full object-cover" data-alt="A close-up studio shot detailing the collar and buttons of a high-quality white men's oxford shirt. Pure white background, soft natural lighting emphasizing the stitching and premium fabric texture. Elegant e-commerce aesthetic." src="https://lh3.googleusercontent.com/aida-public/AB6AXuAB3pzjv83LX9PMT_ruVYyU9RnDbHVAMxrxh0KjyBGxrY4gWcxAW1aXAJ2G0YiHk3GJK-M5oJlBQ9HcPFDMJIgLwJY1vkn-OG3x-XWEIyfCvQTtQhU87UuCJMF2ypFaX4qNdpDJvvL_4kdJCZYofB7bH1qpErYJjMIWTk0MOOfH6XWRE4O0-QeIrMWMVWhhrf1xhVECf1XLjfuwjZa1mHyYAKg-ZFjf_oqCzBTKJYK06CosBFjzcokK"/>
<div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
<span className="material-symbols-outlined text-white">delete</span>
</div>
</div>
<div className="w-24 h-32 rounded-lg border border-outline-variant/30 overflow-hidden relative group cursor-pointer">
<img className="w-full h-full object-cover" data-alt="A studio shot showing a folded white men's oxford shirt stacked neatly. Pure white background, sophisticated soft lighting creating subtle tonal depth. Minimalist and premium presentation." src="https://lh3.googleusercontent.com/aida-public/AB6AXuABQ4kHGQkjqNUBKVU5s0qQHtg1V-0h5mFOJS8U1HEGyofeHSBYk_fi3tc_ocf1BGHTyuYpio6VMnt4SWzoMg_JhSY2aQSsNyA5MDh8eHlcskWAyYDGz88v9_5PsOftKTOOjVzBCfFczSLur0VCAwGqiAqLJZgi-Q_5mWaYyVrRFhYJiBdRrkRJL5n1Bu21mI48Aynztde6mqrQnI1OcQmFoJxu2NNZ7TGvRc9iC4Pb1TOfaBIywaoa"/>
<div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
<span className="material-symbols-outlined text-white">delete</span>
</div>
</div>
<button className="w-24 h-32 rounded-lg border border-dashed border-outline-variant flex flex-col items-center justify-center text-on-surface-variant hover:border-brand-accent hover:text-brand-accent transition-colors bg-brand-bg/50">
<span className="material-symbols-outlined mb-1">add_photo_alternate</span>
<span className="text-xs font-label-sm">Add Image</span>
</button>
</div>
</div>
<div className="grid grid-cols-1 md:grid-cols-2 gap-6">
<div>
<label className="input-label">Category</label>
<div className="relative">
<select className="input-field appearance-none pr-10 bg-white">
<option>Shirts</option>
<option>Trousers</option>
<option>Outerwear</option>
<option>Accessories</option>
</select>
<span className="material-symbols-outlined absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-outline">expand_more</span>
</div>
</div>
<div>
<label className="input-label">Tags</label>
<input className="input-field" placeholder="e.g. Summer, Linen, Casual" type="text"/>
<p className="text-xs text-on-surface-variant/60 mt-1">Separate tags with commas</p>
</div>
</div>
</div>
</section>

<section className="card-container">
<h3 className="font-label-lg text-brand-ink uppercase tracking-widest mb-6">Pricing</h3>
<div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
<div>
<label className="input-label">Regular Price</label>
<div className="relative">
<span className="absolute left-4 top-1/2 -translate-y-1/2 text-on-surface-variant">$</span>
<input className="input-field pl-8" placeholder="0.00" type="number" value="120.00"/>
</div>
</div>
<div>
<label className="input-label flex items-center justify-between">
                                    Sale Price
                                    <span className="inline-flex items-center px-2 py-0.5 rounded-full bg-brand-accent/20 text-brand-accent text-[10px] font-bold tracking-wider">40% OFF</span>
</label>
<div className="relative">
<span className="absolute left-4 top-1/2 -translate-y-1/2 text-on-surface-variant">$</span>
<input className="input-field pl-8" placeholder="0.00" type="number" value="72.00"/>
</div>
</div>
</div>
</section>

<section className="card-container">
<div className="flex items-center justify-between mb-6">
<h3 className="font-label-lg text-brand-ink uppercase tracking-widest">Variations &amp; Stock</h3>
<div className="flex gap-2 text-xs">
<span className="text-on-surface-variant">Quick Add:</span>
<button className="text-brand-ink underline hover:text-brand-accent">Shirts (S-XXL)</button>
<span className="text-outline-variant">|</span>
<button className="text-brand-ink underline hover:text-brand-accent">Jeans (28-36)</button>
</div>
</div>
<div className="flex items-center gap-3 mb-6">
<div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-brand-accent/10 border border-brand-accent/30 text-secondary text-xs font-label-lg">
<span className="material-symbols-outlined text-[14px]">inventory_2</span>
                                TOTAL STOCK: 120
                            </div>
<div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-50 border border-amber-200 text-amber-800 text-xs font-label-lg">
<span className="material-symbols-outlined text-[14px]">warning</span>
                                SIZE M — OUT OF STOCK
                            </div>
</div>
<div className="space-y-4">

<div className="flex items-center gap-4 p-3 rounded-lg border border-outline-variant/20 bg-brand-bg/30">
<div className="w-16 h-10 flex items-center justify-center bg-white border border-brand-ink rounded font-label-lg text-brand-ink shrink-0">
                                    S
                                </div>
<div className="flex-1 flex items-center gap-4">
<div className="relative w-32">
<span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-on-surface-variant uppercase">Qty</span>
<input className="w-full bg-white border-b border-outline-variant/30 pb-1 pt-1 pl-10 pr-2 text-sm focus:border-brand-ink outline-none" type="number" value="45"/>
</div>
<div className="relative w-32 hidden sm:block">
<span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-on-surface-variant uppercase">SKU</span>
<input className="w-full bg-white border-b border-outline-variant/30 pb-1 pt-1 pl-12 pr-2 text-sm focus:border-brand-ink outline-none text-on-surface-variant" type="text" value="OXF-WHT-S"/>
</div>
</div>
<button className="text-outline hover:text-error transition-colors p-2 shrink-0">
<span className="material-symbols-outlined text-[20px]">close</span>
</button>
</div>

<div className="flex items-center gap-4 p-3 rounded-lg border border-error/20 bg-error-container/10">
<div className="w-16 h-10 flex items-center justify-center bg-white border border-brand-ink rounded font-label-lg text-brand-ink shrink-0">
                                    M
                                </div>
<div className="flex-1 flex items-center gap-4">
<div className="relative w-32">
<span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-on-surface-variant uppercase">Qty</span>
<input className="w-full bg-white border-b border-error/50 pb-1 pt-1 pl-10 pr-2 text-sm focus:border-error outline-none text-error" type="number" value="0"/>
</div>
<div className="relative w-32 hidden sm:block">
<span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-on-surface-variant uppercase">SKU</span>
<input className="w-full bg-white border-b border-outline-variant/30 pb-1 pt-1 pl-12 pr-2 text-sm focus:border-brand-ink outline-none text-on-surface-variant" type="text" value="OXF-WHT-M"/>
</div>
</div>
<button className="text-outline hover:text-error transition-colors p-2 shrink-0">
<span className="material-symbols-outlined text-[20px]">close</span>
</button>
</div>

<div className="flex items-center gap-4 p-3 rounded-lg border border-outline-variant/20 bg-brand-bg/30">
<div className="w-16 h-10 flex items-center justify-center bg-white border border-brand-ink rounded font-label-lg text-brand-ink shrink-0">
                                    L
                                </div>
<div className="flex-1 flex items-center gap-4">
<div className="relative w-32">
<span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-on-surface-variant uppercase">Qty</span>
<input className="w-full bg-white border-b border-outline-variant/30 pb-1 pt-1 pl-10 pr-2 text-sm focus:border-brand-ink outline-none" type="number" value="50"/>
</div>
<div className="relative w-32 hidden sm:block">
<span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-on-surface-variant uppercase">SKU</span>
<input className="w-full bg-white border-b border-outline-variant/30 pb-1 pt-1 pl-12 pr-2 text-sm focus:border-brand-ink outline-none text-on-surface-variant" type="text" value="OXF-WHT-L"/>
</div>
</div>
<button className="text-outline hover:text-error transition-colors p-2 shrink-0">
<span className="material-symbols-outlined text-[20px]">close</span>
</button>
</div>

<div className="flex items-center gap-4 p-3 rounded-lg border border-outline-variant/20 bg-brand-bg/30">
<div className="w-16 h-10 flex items-center justify-center bg-white border border-brand-ink rounded font-label-lg text-brand-ink shrink-0">
                                    XL
                                </div>
<div className="flex-1 flex items-center gap-4">
<div className="relative w-32">
<span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-on-surface-variant uppercase">Qty</span>
<input className="w-full bg-white border-b border-outline-variant/30 pb-1 pt-1 pl-10 pr-2 text-sm focus:border-brand-ink outline-none" type="number" value="15"/>
</div>
<div className="relative w-32 hidden sm:block">
<span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-on-surface-variant uppercase">SKU</span>
<input className="w-full bg-white border-b border-outline-variant/30 pb-1 pt-1 pl-12 pr-2 text-sm focus:border-brand-ink outline-none text-on-surface-variant" type="text" value="OXF-WHT-XL"/>
</div>
</div>
<button className="text-outline hover:text-error transition-colors p-2 shrink-0">
<span className="material-symbols-outlined text-[20px]">close</span>
</button>
</div>

<div className="flex items-center gap-4 p-3 rounded-lg border border-outline-variant/20 bg-brand-bg/30">
<div className="w-16 h-10 flex items-center justify-center bg-white border border-brand-ink rounded font-label-lg text-brand-ink shrink-0">
                                    XXL
                                </div>
<div className="flex-1 flex items-center gap-4">
<div className="relative w-32">
<span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-on-surface-variant uppercase">Qty</span>
<input className="w-full bg-white border-b border-outline-variant/30 pb-1 pt-1 pl-10 pr-2 text-sm focus:border-brand-ink outline-none" type="number" value="10"/>
</div>
<div className="relative w-32 hidden sm:block">
<span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-on-surface-variant uppercase">SKU</span>
<input className="w-full bg-white border-b border-outline-variant/30 pb-1 pt-1 pl-12 pr-2 text-sm focus:border-brand-ink outline-none text-on-surface-variant" type="text" value="OXF-WHT-XXL"/>
</div>
</div>
<button className="text-outline hover:text-error transition-colors p-2 shrink-0">
<span className="material-symbols-outlined text-[20px]">close</span>
</button>
</div>
</div>
<div className="mt-6 flex flex-col sm:flex-row items-center justify-between gap-4 pt-6 border-t border-outline-variant/10">
<button className="w-full sm:w-auto px-5 py-2 rounded-full border border-brand-ink text-brand-ink font-label-lg hover:bg-black/5 transition-colors flex items-center justify-center gap-2">
<span className="material-symbols-outlined text-[18px]">add</span>
                                ADD SIZE
                            </button>
<div className="flex items-center gap-3">
<label className="text-sm text-on-surface-variant font-label-lg">Alert when below:</label>
<input className="w-16 bg-white border border-outline-variant/30 rounded py-1 px-2 text-center text-sm focus:border-brand-accent outline-none" type="number" value="5"/>
</div>
</div>
</section>
</div>

<div className="lg:col-span-4 flex flex-col gap-8">

<section className="card-container">
<h3 className="font-label-lg text-brand-ink uppercase tracking-widest mb-6">Product Status</h3>
<div className="space-y-3">
<label className="flex items-center p-3 border border-brand-accent bg-brand-accent/5 rounded-lg cursor-pointer">
<input defaultChecked={true} className="w-4 h-4 text-brand-accent focus:ring-brand-accent border-outline-variant/50" name="status" type="radio"/>
<span className="ml-3 font-body-sm font-medium text-brand-ink flex-1">Active</span>
<span className="material-symbols-outlined text-brand-accent text-[18px]">check_circle</span>
</label>
<label className="flex items-center p-3 border border-outline-variant/20 rounded-lg hover:bg-brand-bg/50 cursor-pointer transition-colors">
<input className="w-4 h-4 text-brand-ink focus:ring-brand-ink border-outline-variant/50" name="status" type="radio"/>
<span className="ml-3 font-body-sm text-on-surface-variant flex-1">Draft</span>
</label>
<label className="flex items-center p-3 border border-outline-variant/20 rounded-lg hover:bg-brand-bg/50 cursor-pointer transition-colors">
<input className="w-4 h-4 text-brand-ink focus:ring-brand-ink border-outline-variant/50" name="status" type="radio"/>
<span className="ml-3 font-body-sm text-on-surface-variant flex-1">Archived</span>
</label>
</div>
</section>

<section className="card-container">
<h3 className="font-label-lg text-brand-ink uppercase tracking-widest mb-6">Inventory Specs</h3>
<div className="space-y-6">
<div>
<label className="input-label">Base SKU</label>
<input className="input-field font-mono text-sm" type="text" value="OXF-WHT"/>
<p className="text-[11px] text-on-surface-variant/60 mt-1">Used as prefix for variations</p>
</div>
<div className="pt-4 border-t border-outline-variant/10">
<div className="flex justify-between items-center mb-2">
<span className="text-sm text-on-surface-variant">Total Managed Stock</span>
<span className="font-label-lg text-brand-ink">120 Units</span>
</div>
<div className="w-full bg-brand-bg rounded-full h-1.5">
<div className="bg-brand-accent h-1.5 rounded-full" style={{"width": "75%"}}></div>
</div>
</div>
</div>
</section>

<section className="card-container">
<h3 className="font-label-lg text-brand-ink uppercase tracking-widest mb-6">Search Engine Listing</h3>
<div className="space-y-4">
<div>
<label className="input-label">Meta Title</label>
<input className="input-field" placeholder="Classic Oxford Button-Down | MEN'S WEAR" type="text"/>
<p className="text-[11px] text-on-surface-variant/60 mt-1 text-right">42/60 chars</p>
</div>
<div>
<label className="input-label">Meta Description</label>
<textarea className="input-field h-24 resize-none" placeholder="Shop the premium Classic Oxford Button-Down shirt..."></textarea>
<p className="text-[11px] text-on-surface-variant/60 mt-1 text-right">0/160 chars</p>
</div>
</div>
<div className="mt-6 p-4 bg-brand-bg rounded-lg border border-outline-variant/10">
<span className="text-[10px] uppercase tracking-wider text-on-surface-variant mb-1 block">Preview</span>
<div className="text-[#1a0dab] text-sm hover:underline cursor-pointer truncate">Classic Oxford Button-Down | MEN'S WEAR</div>
<div className="text-[#006621] text-[11px] truncate">https://menswear.com/products/classic-oxford</div>
<div className="text-on-surface-variant text-xs mt-1 line-clamp-2">Shop the premium Classic Oxford Button-Down shirt. Discover superior fit and timeless style for the modern gentleman.</div>
</div>
</section>
</div>
</div>
</div>
</main>
  );
}