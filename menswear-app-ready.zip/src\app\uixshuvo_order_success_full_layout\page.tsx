export default function UixshuvoOrderSuccessFullLayout() {
  return (
    <main className="flex-grow flex items-center justify-center px-margin-mobile md:px-margin-desktop py-stack-lg">
<div className="w-full max-w-2xl bg-surface-container-lowest rounded-[24px] p-stack-md md:p-stack-lg ambient-shadow flex flex-col items-center text-center">
<div className="w-20 h-20 bg-[#8FB0A4] rounded-full flex items-center justify-center mb-8">
<span className="material-symbols-outlined text-surface-container-lowest" style={{"fontSize": "40px","fontVariationSettings": "\'FILL\' 1"}}>check</span>
</div>
<h1 className="font-headline-lg text-headline-lg-mobile md:text-headline-lg uppercase text-primary mb-4 tracking-widest">
                Order Placed Successfully
            </h1>
<p className="font-body-md text-body-md text-on-surface-variant mb-6 max-w-md">
                Thank you! Your order <span className="font-bold text-primary">#MW-2481</span> is confirmed.
            </p>
<div className="bg-[#8FB0A4] text-surface-container-lowest px-4 py-2 rounded-full font-label-sm text-label-sm uppercase tracking-wider mb-stack-md">
                Arriving by Aug 22, 2026
            </div>
<div className="w-full bg-surface-container-low rounded-xl p-6 mb-stack-md">
<h2 className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider text-left mb-4 border-b border-surface-variant pb-2">Order Summary</h2>
<div className="space-y-4 mb-6">
<div className="flex items-center justify-between">
<div className="flex items-center gap-4">
<div className="w-12 h-16 bg-surface-variant rounded flex-shrink-0 bg-cover bg-center" data-alt="A meticulously styled flat lay of a sage green linen shirt on a minimalist concrete background. High-key lighting, editorial fashion photography style, crisp textures, soft airy aesthetic." style={{"backgroundImage": "url('https://lh3.googleusercontent.com/aida-public/AB6AXuD1LOGNIet8p6ZRKsE6YvRRXlOJQ8kCWqY1y1PFpuBLi0akY1Bs8sHoI-0wkcnmWkoHHx0LrcF8Ek2hHsZIpdgLbPZOmPeiUV0wR-JE0E90sK7tef4AwFgZvJv6DqCI3HGDrqFke3Run4eNTw0ttm6jMEIV_tHQ2g4TAAVmhMoxPZP9PTL1SQo-PKss3fhxInPtt8kBkptWTz-rmiZDaySmGMwjyEAUHB5UDViE5bfb_BEE_I_1oUd0BQ')"}}></div>
<span className="font-body-md text-body-md text-primary">Sage Linen Shirt</span>
</div>
<span className="font-body-md text-body-md text-primary">$85.00</span>
</div>
<div className="flex items-center justify-between">
<div className="flex items-center gap-4">
<img alt="Selvedge Jeans" className="w-12 h-16 object-cover rounded flex-shrink-0" src="https://lh3.googleusercontent.com/aida/AP1WRLusg0K3F_ypapeR-272hJjPMps24n77A4kcPO74u-PepPjQP4xrArAaPmx4HXF98zzF5aAmM4D8qoeN8BcnDKlMvYdJesslyusGwmRzHS2_FOKrlg15n79XDPqmRW-NwZ1653jIjsfJlU6zJANjLCafr_Qn9maNoxpNsi69yRpxdOB2cfe0am1n-TCXVZvvZl9fsxf9zZr0_wIiK0k4DEXruFKixWhYViVDldPeG2GGbsOc2Ag1mm-peK1b" />
<span className="font-body-md text-body-md text-primary">Selvedge Jeans</span>
</div>
<span className="font-body-md text-body-md text-primary">$145.00</span>
</div>
<div className="flex items-center justify-between">
<div className="flex items-center gap-4">
<div className="w-12 h-16 bg-surface-variant rounded flex-shrink-0 bg-cover bg-center" data-alt="A neatly folded premium heavyweight white t-shirt presented on a stark, minimalist lavender-white surface. High resolution, editorial lighting, focus on fabric texture and clean lines." style={{"backgroundImage": "url('https://lh3.googleusercontent.com/aida-public/AB6AXuBb9iEOuk-utbFUg_xPRO580W5dE3YHrtMzNw13qoUyBb04uN8iwifS0uCf1hq3UZwWti1mLIHQPHPbpmJp-Az51ancTuF13SS_yAlIDrPCFu0Y-6Uxr0DxorCuzAwONH5KWLtZqZyACBqX8RwRmaALtBxau66FRSK2-_niIDUqRFVq2dRcKJeNpXdO3VZU2hxDyjUleq9ImuRgT_h-xrUHKbSS3pRwYD9YyHvjqmU3bHoaxvRzIb8dsA')"}}></div>
<span className="font-body-md text-body-md text-primary">Heavyweight Tee</span>
</div>
<span className="font-body-md text-body-md text-primary">$45.00</span>
</div>
</div>
<div className="flex justify-between items-center border-t border-surface-variant pt-4">
<span className="font-body-lg text-body-lg text-primary">Total</span>
<span className="font-headline-md text-headline-md text-primary font-bold">$235.00</span>
</div>
</div>
<div className="flex flex-col sm:flex-row gap-4 w-full justify-center mb-8">
<button className="bg-[#141414] text-on-primary px-8 py-4 rounded-full font-label-sm text-label-sm uppercase tracking-wider flex items-center justify-center gap-2 hover:bg-black transition-colors">
                    TRACK ORDER
                    <span className="material-symbols-outlined" style={{"fontSize": "16px"}}>arrow_forward</span>
</button>
<button className="bg-transparent border border-[#141414] text-primary px-8 py-4 rounded-full font-label-sm text-label-sm uppercase tracking-wider hover:bg-surface-container transition-colors">
                    CONTINUE SHOPPING
                </button>
</div>
<p className="font-body-md text-sm text-[#6E6E75]">Confirmation email sent to support@menswear.com</p>
</div>
</main>
  );
}