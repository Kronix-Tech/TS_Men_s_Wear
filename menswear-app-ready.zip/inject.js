const fs = require('fs');
let file = fs.readFileSync('src/app/men_s_wear_shop_all/page.tsx', 'utf8');

// Find the grid start
const gridStart = '<div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-gutter">';
const nextDiv = '<div className="flex justify-center items-center gap-2 mt-8">';

const startIndex = file.indexOf(gridStart);
const endIndex = file.indexOf(nextDiv);

if (startIndex !== -1 && endIndex !== -1) {
  let newFile = file.substring(0, startIndex) + '<ShopProductGrid />\n' + file.substring(endIndex);
  
  // Add import statement at the top
  newFile = 'import ShopProductGrid from "@/components/ShopProductGrid";\n' + newFile;
  
  fs.writeFileSync('src/app/men_s_wear_shop_all/page.tsx', newFile);
  console.log('Successfully injected ShopProductGrid!');
} else {
  console.log('Could not find injection points.');
}
