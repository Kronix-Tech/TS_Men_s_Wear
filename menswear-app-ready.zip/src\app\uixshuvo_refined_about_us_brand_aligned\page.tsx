export default function UixshuvoRefinedAboutUsBrandAligned() {
  return (
    <main className="flex-grow">

<section className="max-w-container-max mx-auto px-margin-desktop py-stack-lg mt-12">
<div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">

<div className="flex flex-col items-start max-w-2xl">
<h1 className="display-serif text-5xl lg:text-[64px] leading-[1.1] tracking-[0.2em] text-primary mb-8 font-normal uppercase">
                        CRAFTING CONFIDENCE FOR THE MODERN MAN
                    </h1>
<p className="text-lg text-on-surface-variant leading-relaxed mb-10 max-w-xl font-light">
                        Rooted in the principles of quiet luxury, UIXSHUVO delivers premium menswear designed for effortless sophistication. We believe in minimal aesthetics, unparalleled craftsmanship, and pieces that endure beyond fleeting trends.
                    </p>
<a className="btn-outline text-sm tracking-widest uppercase rounded-full px-8 py-3 border-secondary text-secondary hover:bg-secondary hover:text-on-secondary transition-all duration-300" href="#">
                        OUR STORY
                    </a>
</div>

<div className="relative h-[600px] w-full hidden md:block">

<div className="absolute top-0 right-0 w-3/4 h-3/4 rounded-2xl overflow-hidden border border-sage/30 shadow-ambient z-10 hover:-translate-y-2 transition-transform duration-500">
<img className="w-full h-full object-cover" data-alt="A focused, modern tailor carefully measuring premium charcoal gray suiting fabric in a bright, minimalist atelier. Soft natural light illuminates the workspace, highlighting the texture of the wool. The atmosphere is quiet, artisanal, and highly refined, fitting a luxury menswear brand's light-mode aesthetic." src="https://lh3.googleusercontent.com/aida-public/AB6AXuDGsnwHhRzK6_6DknibMgUljCX3DKVbJYc-fboeUxhtgnjbHjXHUp9tByvocasjan8S6PiGY216jMp2cZFhseExC9UPcNTHoTs7OjJPYHIWMeC2f_ZApZWaLtY5rOo0YzEINtPoCIqG9kdJVOcZ048xKJE5M1YESEyYM0gvsmZ9hVs3i55SdtBEvYS7MEAQ_NCaLpgq7cwfzA0lOhAv8-n7mgbdcW39iXVMIPB6RWG3R87P9TQ21n0s8w" />
</div>

<div className="absolute bottom-10 left-0 w-1/2 h-2/5 rounded-2xl overflow-hidden border border-sage/30 shadow-ambient z-20 hover:-translate-y-2 transition-transform duration-500">
<img className="w-full h-full object-cover" data-alt="A macro close-up of luxurious, woven houndstooth fabric in muted tones of cream, light gray, and faint lavender. The delicate threads and high-quality weave are sharply in focus. The lighting is soft and diffused, creating a serene, textural image suitable for a high-end fashion brand's editorial layout." src="https://lh3.googleusercontent.com/aida-public/AB6AXuDNm3o9Zf9-9G4oYEOwYL18-AHh-2JYeo8eUsU7yGx50dNCKKbbQNPY9ZYCJ--iPc2JDny543-8_9n9UeRQMiKhzAgmimPZ_pjeI6AQMlvc1eG9uuiHH1qcoc9UOhDgLbYulfaOb5KU9pWJ0tQEnh-gBgh-E5Ea4bqsldiegkb7aZx8jPOefUeUVDjoAhHlzgJj5pmsejr8U8cHbc_7nlhZsKeBwNsE3_GGSPiNFZBQnirXI21mXenZQA" />
</div>

<div className="absolute bottom-0 right-10 w-2/5 h-1/2 rounded-2xl overflow-hidden border border-sage/30 shadow-ambient z-30 hover:-translate-y-2 transition-transform duration-500">
<img className="w-full h-full object-cover" data-alt="A sophisticated male model wearing a minimalist, perfectly tailored navy suit over a crisp white shirt, standing against a stark, light lavender-white background. His pose is relaxed yet confident. The lighting is editorial and high-key, emphasizing the clean lines and impeccable fit of the quiet luxury garments." src="https://lh3.googleusercontent.com/aida-public/AB6AXuB-tUUUF6TwJPqyw3_1fyGUCq0EQ2nH0JBhmysUCObg8R4rsQnsqIc4dl9PRvvfgbutxesPVS_0pG5DygBJrV2zOcLDvTTuKt_Z1yn3eBRDr8V0wl0Z_m-H8Oj0gtjUPUOUGftT_rINM6XBL3pP0i-tWnDamt1ZmnFTl0womtuH7EigTC4ZRNSnRm2e1wvP6M66gbUZ_CgqDL56BHla9x_Y6rAcum--uIAQEN4KmachamdboaqFV4ArLg" />
</div>
</div>
</div>
</section>

<section className="max-w-container-max mx-auto px-margin-desktop py-stack-md">
<div className="grid grid-cols-2 md:grid-cols-4 gap-6">

<div className="bg-white rounded-2xl p-8 flex flex-col items-center justify-center text-center shadow-ambient hover:-translate-y-1 transition-transform duration-300">
<span className="display-serif text-3xl text-primary mb-2">1200+</span>
<span className="text-xs uppercase tracking-widest text-on-surface-variant font-medium">Products</span>
</div>

<div className="bg-white rounded-2xl p-8 flex flex-col items-center justify-center text-center shadow-ambient hover:-translate-y-1 transition-transform duration-300">
<span className="display-serif text-3xl text-primary mb-2">50K+</span>
<span className="text-xs uppercase tracking-widest text-on-surface-variant font-medium">Happy Customers</span>
</div>

<div className="bg-white rounded-2xl p-8 flex flex-col items-center justify-center text-center shadow-ambient hover:-translate-y-1 transition-transform duration-300">
<span className="display-serif text-3xl text-primary mb-2">4.8</span>
<span className="text-xs uppercase tracking-widest text-on-surface-variant font-medium">Average Rating</span>
</div>

<div className="bg-white rounded-2xl p-8 flex flex-col items-center justify-center text-center shadow-ambient hover:-translate-y-1 transition-transform duration-300">
<span className="display-serif text-3xl text-primary mb-2">15</span>
<span className="text-xs uppercase tracking-widest text-on-surface-variant font-medium">Cities</span>
</div>
</div>
</section>

<section className="max-w-container-max mx-auto px-margin-desktop py-stack-lg mt-12 mb-20">
<div className="text-center mb-16">
<h2 className="display-serif text-4xl text-primary mb-4 tracking-[0.2em] font-normal uppercase">OUR FOUNDATION</h2>
<p className="text-on-surface-variant max-w-xl mx-auto font-light">The pillars that define our approach to modern menswear.</p>
</div>
<div className="grid grid-cols-1 md:grid-cols-3 gap-8">

<div className="bg-white rounded-2xl p-10 flex flex-col items-start shadow-ambient hover:-translate-y-2 transition-transform duration-300 border border-transparent hover:border-sage/20">
<div className="w-12 h-12 rounded-full bg-surface-container-high flex items-center justify-center mb-6 text-primary">
<span className="material-symbols-outlined text-2xl" style={{"fontVariationSettings": "\'wght\' 200"}}>diamond</span>
</div>
<h3 className="display-serif text-xl mb-3 text-primary">Premium Fabrics</h3>
<p className="text-sm text-on-surface-variant leading-relaxed font-light">Sourced globally from the finest mills. We prioritize durability and texture over mass production.</p>
</div>

<div className="bg-white rounded-2xl p-10 flex flex-col items-start shadow-ambient hover:-translate-y-2 transition-transform duration-300 border border-transparent hover:border-sage/20">
<div className="w-12 h-12 rounded-full bg-surface-container-high flex items-center justify-center mb-6 text-primary">
<span className="material-symbols-outlined text-2xl" style={{"fontVariationSettings": "\'wght\' 200"}}>balance</span>
</div>
<h3 className="display-serif text-xl mb-3 text-primary">Fair Pricing</h3>
<p className="text-sm text-on-surface-variant leading-relaxed font-light">Direct to consumer model eliminates unnecessary markups, offering true luxury value.</p>
</div>

<div className="bg-white rounded-2xl p-10 flex flex-col items-start shadow-ambient hover:-translate-y-2 transition-transform duration-300 border border-transparent hover:border-sage/20">
<div className="w-12 h-12 rounded-full bg-surface-container-high flex items-center justify-center mb-6 text-primary">
<span className="material-symbols-outlined text-2xl" style={{"fontVariationSettings": "\'wght\' 200"}}>eco</span>
</div>
<h3 className="display-serif text-xl mb-3 text-primary">Sustainable Practice</h3>
<p className="text-sm text-on-surface-variant leading-relaxed font-light">Mindful manufacturing with a focus on ethical labor and reducing our environmental footprint.</p>
</div>
</div>
</section>

<section className="max-w-container-max mx-auto px-margin-desktop mb-stack-lg">
<div className="bg-sage rounded-[32px] p-16 flex flex-col md:flex-row items-center justify-between shadow-ambient relative overflow-hidden">

<div className="z-10 text-center md:text-left mb-8 md:mb-0">
<h2 className="display-serif text-3xl md:text-4xl text-white tracking-widest max-w-2xl leading-tight">
                        JOIN THE MOVEMENT — SHOP NEW ARRIVALS
                    </h2>
</div>
<div className="z-10 shrink-0">
<a className="bg-primary text-on-primary rounded-full px-8 py-3 text-sm tracking-widest uppercase flex items-center gap-2 hover:opacity-80 transition-opacity shadow-lg shadow-black/10" href="#">SHOP NOW <span className="material-symbols-outlined">trending_flat</span></a>
</div>
</div>
</section>
</main>
  );
}