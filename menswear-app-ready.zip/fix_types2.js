const fs = require('fs');
const path = require('path');

function walk(dir) {
  const files = fs.readdirSync(dir);
  for (const file of files) {
    const fullPath = path.join(dir, file);
    if (fs.statSync(fullPath).isDirectory()) {
      walk(fullPath);
    } else if (fullPath.endsWith('.tsx') && !fullPath.includes('node_modules')) {
      let content = fs.readFileSync(fullPath, 'utf8');
      let originalContent = content;

      // Remove string event handlers
      content = content.replace(/\sonSubmit="[^"]*"/g, '');
      content = content.replace(/\sonClick="[^"]*"/g, '');
      content = content.replace(/\sonChange="[^"]*"/g, '');
      content = content.replace(/\sonSubmit='[^']*'/g, '');
      content = content.replace(/\sonClick='[^']*'/g, '');
      content = content.replace(/\sonChange='[^']*'/g, '');
      
      // Fix boolean string attributes
      content = content.replace(/\sreadonly="[^"]*"/gi, ' readOnly={true}');
      content = content.replace(/\sreadOnly="[^"]*"/gi, ' readOnly={true}');
      content = content.replace(/\sreadonly/gi, ' readOnly={true}'); // if just bare
      content = content.replace(/\srequired="[^"]*"/gi, ' required={true}');
      content = content.replace(/\schecked="[^"]*"/gi, ' defaultChecked={true}');
      content = content.replace(/\sdisabled="[^"]*"/gi, ' disabled={true}');
      content = content.replace(/\sselected="[^"]*"/gi, ''); // select needs defaultValue on parent
      
      if (content !== originalContent) {
        fs.writeFileSync(fullPath, content);
        console.log(`Fixed types in ${fullPath}`);
      }
    }
  }
}

walk('src/app');
