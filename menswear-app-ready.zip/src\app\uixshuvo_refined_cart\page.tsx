export default function UixshuvoRefinedCart() {
  return (
    <main className="max-w-container-max mx-auto px-margin-desktop py-stack-lg">

<div className="mb-12">
<nav aria-label="Breadcrumb" className="flex text-on-surface-variant font-label-sm text-label-sm uppercase mb-4">
<ol className="inline-flex items-center space-x-1 md:space-x-2">
<li className="inline-flex items-center">
<a className="hover:text-primary transition-colors" href="#">Home</a>
</li>
<li className="">
<div className="flex items-center">
<span className="mx-2">/</span>
<span aria-current="page" className="text-primary">Cart</span>
</div>
</li>
</ol>
</nav>
<h1 className="font-headline-lg text-headline-lg md:font-display-lg md:text-display-lg text-primary">YOUR CART (3)</h1>
</div>

<div className="grid grid-cols-1 lg:grid-cols-12 gap-gutter items-start">

<div className="lg:col-span-8 bg-surface-container-lowest rounded-24px p-8 shadow-ambient">

<div className="flex flex-col sm:flex-row items-start sm:items-center py-6 border-b border-surface-variant gap-6 last:border-0 last:pb-0">
<div className="w-24 h-32 flex-shrink-0 rounded-lg overflow-hidden bg-surface-container-low">
<img className="w-full h-full object-cover" data-alt="A clean, minimalist flat lay of a sage green linen button-up shirt on a white marble background. Soft, diffused daylight illuminates the natural texture of the fabric. High-end editorial fashion photography style with subtle shadows and a serene, bright mood. The composition is simple and sophisticated." src="https://lh3.googleusercontent.com/aida-public/AB6AXuA2SG8iNi6DRwBuylLhP89bndXqyiuVPMvw0bkZMdtFCdQorNzLF-r34mSBMc4_SVbuXMKuma5nRqlfC_6xjaFfhoTymhvNaRV5W17W6UQBKl3UKQRQUnsLrIUFyZnxlcGf-8LiOs1XVo6b9jEQB23JcwlEybSWVdzo8VzLwYJGnoLXBe1Hiib1IFpHP8V1afItyF-ly2qJyRGJWS_8C_00qKE8KverzF3_4fseubDijHCdR6PFIc1lBQ" />
</div>
<div className="flex-grow flex flex-col justify-between h-full space-y-2">
<div className="flex justify-between items-start w-full">
<div>
<h3 className="font-body-lg text-body-lg text-primary mb-1">Sage Linen Shirt</h3>
<div className="flex gap-2">
<span className="bg-surface-container-low text-on-surface-variant px-3 py-1 rounded-full font-label-sm text-label-sm uppercase">Size: L</span>
<span className="bg-surface-container-low text-on-surface-variant px-3 py-1 rounded-full font-label-sm text-label-sm uppercase">Color: White</span>
</div>
</div>
<button aria-label="Remove item" className="text-on-surface-variant hover:text-error transition-colors">
<span className="material-symbols-outlined">close</span>
</button>
</div>
<div className="flex justify-between items-end w-full mt-4">
<div className="flex items-center gap-4">
<span className="font-body-md text-body-md text-on-surface-variant">$85.00</span>
<div className="flex items-center border border-outline-variant rounded-full h-10 w-28 px-2 bg-surface-bright">
<button className="w-8 h-full flex items-center justify-center text-on-surface-variant hover:text-primary transition-colors">−</button>
<input className="w-full text-center border-0 bg-transparent p-0 font-body-md text-body-md text-primary focus:ring-0" max="99" min="1" type="number" value="1" />
<button className="w-8 h-full flex items-center justify-center text-on-surface-variant hover:text-primary transition-colors">+</button>
</div>
</div>
<div className="text-right">
<span className="font-body-lg text-body-lg font-medium text-primary block">$85.00</span>
<button className="font-label-sm text-label-sm uppercase text-on-surface-variant border-b border-transparent hover:border-on-surface-variant transition-colors mt-2 inline-block">Move to wishlist</button>
</div>
</div>
</div>
</div>

<div className="flex flex-col sm:flex-row items-start sm:items-center py-6 border-b border-surface-variant gap-6 last:border-0 last:pb-0">
<div className="w-24 h-32 flex-shrink-0 rounded-lg overflow-hidden bg-surface-container-low">
<img className="w-full h-full object-cover" data-alt="A meticulously folded pair of raw indigo selvedge denim jeans resting on a plain white surface. The rich, dark blue texture contrasts sharply with the bright background. High-quality fashion editorial style lighting, emphasizing the premium quality and stiff drape of the heavyweight denim. Minimalist and refined aesthetic." src="https://lh3.googleusercontent.com/aida-public/AB6AXuDpl69-tRWgyHtIS8fDgKaVi_wbQSVIlu_MXGlyKTGzqjIWQGP4viyrBbUedduTzb-HK6AFazhIG_7Px52ql2ZJ3akjm0mzw5t7VqEX5sWvTY6d86-31CoK0zx1q8QNlgTGMmuxHNmREntDh5vdzRm2a8RzMONodkmQ6hT6PNU884izm7nE4jaQ1-RD3aD-ef44V_94bGrqRpPBSoubln1i-yeQnMiE8lxApFAV3ZqJ9w86Btl2qGh1XA" />
</div>
<div className="flex-grow flex flex-col justify-between h-full space-y-2">
<div className="flex justify-between items-start w-full">
<div>
<h3 className="font-body-lg text-body-lg text-primary mb-1">Selvedge Jeans</h3>
<div className="flex gap-2">
<span className="bg-surface-container-low text-on-surface-variant px-3 py-1 rounded-full font-label-sm text-label-sm uppercase">Size: 32</span>
<span className="bg-surface-container-low text-on-surface-variant px-3 py-1 rounded-full font-label-sm text-label-sm uppercase">Color: Indigo</span>
</div>
</div>
<button aria-label="Remove item" className="text-on-surface-variant hover:text-error transition-colors">
<span className="material-symbols-outlined">close</span>
</button>
</div>
<div className="flex justify-between items-end w-full mt-4">
<div className="flex items-center gap-4">
<span className="font-body-md text-body-md text-on-surface-variant">$145.00</span>
<div className="flex items-center border border-outline-variant rounded-full h-10 w-28 px-2 bg-surface-bright">
<button className="w-8 h-full flex items-center justify-center text-on-surface-variant hover:text-primary transition-colors">−</button>
<input className="w-full text-center border-0 bg-transparent p-0 font-body-md text-body-md text-primary focus:ring-0" max="99" min="1" type="number" value="1" />
<button className="w-8 h-full flex items-center justify-center text-on-surface-variant hover:text-primary transition-colors">+</button>
</div>
</div>
<div className="text-right">
<span className="font-body-lg text-body-lg font-medium text-primary block">$145.00</span>
<button className="font-label-sm text-label-sm uppercase text-on-surface-variant border-b border-transparent hover:border-on-surface-variant transition-colors mt-2 inline-block">Move to wishlist</button>
</div>
</div>
</div>
</div>

<div className="flex flex-col sm:flex-row items-start sm:items-center py-6 border-b border-surface-variant gap-6 last:border-0 last:pb-0">
<div className="w-24 h-32 flex-shrink-0 rounded-lg overflow-hidden bg-surface-container-low">
<img className="w-full h-full object-cover" data-alt="A folded minimalist heavyweight grey cotton t-shirt shot from directly above on a pristine white backdrop. Crisp, bright studio lighting creates soft shadows. The image conveys a sense of high-end basics and understated luxury. Clean, balanced composition highlighting the thick knit of the fabric." src="https://lh3.googleusercontent.com/aida-public/AB6AXuCntgEmA-l7eqybehBLpYFElPbO39lFvkrH5n0qvhcNXhz4RZszX6Qx3bj_U2bBMeiHX315U96pVx_LzxO0o7syMJX2GNm5bhSHUlQILMLkqxHeIVgCCE5jM6iuneZeWpwRFjoGrhoapXFlrx9B2QDrwAMz6vehh3dQMe6jpxiPCUyYvmG_xg9dZR8NGN6Yd7-gtdZulZ_F5uGf5X8YzCjE2EV5NobXl08py5rty13HszBrFHLrilWq2w" />
</div>
<div className="flex-grow flex flex-col justify-between h-full space-y-2">
<div className="flex justify-between items-start w-full">
<div>
<h3 className="font-body-lg text-body-lg text-primary mb-1">Heavyweight Tee</h3>
<div className="flex gap-2">
<span className="bg-surface-container-low text-on-surface-variant px-3 py-1 rounded-full font-label-sm text-label-sm uppercase">Size: L</span>
<span className="bg-surface-container-low text-on-surface-variant px-3 py-1 rounded-full font-label-sm text-label-sm uppercase">Color: Grey</span>
</div>
</div>
<button aria-label="Remove item" className="text-on-surface-variant hover:text-error transition-colors">
<span className="material-symbols-outlined">close</span>
</button>
</div>
<div className="flex justify-between items-end w-full mt-4">
<div className="flex items-center gap-4">
<span className="font-body-md text-body-md text-on-surface-variant">$45.00</span>
<div className="flex items-center border border-outline-variant rounded-full h-10 w-28 px-2 bg-surface-bright">
<button className="w-8 h-full flex items-center justify-center text-on-surface-variant hover:text-primary transition-colors">−</button>
<input className="w-full text-center border-0 bg-transparent p-0 font-body-md text-body-md text-primary focus:ring-0" max="99" min="1" type="number" value="1" />
<button className="w-8 h-full flex items-center justify-center text-on-surface-variant hover:text-primary transition-colors">+</button>
</div>
</div>
<div className="text-right">
<span className="font-body-lg text-body-lg font-medium text-primary block">$45.00</span>
<button className="font-label-sm text-label-sm uppercase text-on-surface-variant border-b border-transparent hover:border-on-surface-variant transition-colors mt-2 inline-block">Move to wishlist</button>
</div>
</div>
</div>
</div>
</div>

<div className="lg:col-span-4 relative">
<div className="bg-surface-container-lowest rounded-24px p-8 shadow-ambient sticky top-32">
<div className="mb-8">
<label className="sr-only" htmlFor="coupon">Coupon Code</label>
<div className="relative flex items-center">
<input className="w-full rounded-full border border-outline-variant bg-surface-bright px-6 py-3 font-body-md text-body-md text-primary focus:border-ink focus:ring-0 placeholder:text-on-surface-variant/50" id="coupon" placeholder="Discount code" type="text" />
<button className="absolute right-2 px-4 py-1.5 rounded-full border border-ink text-ink font-label-sm text-label-sm uppercase hover:bg-ink hover:text-on-primary transition-colors">Apply</button>
</div>
</div>
<div className="space-y-4 mb-6">
<div className="flex justify-between items-center font-body-md text-body-md text-on-surface-variant">
<span className="">Subtotal</span>
<span className="">$275.00</span>
</div>
<div className="flex justify-between items-center font-body-md text-body-md text-secondary">
<span className="">Discount</span>
<span className="">-$40.00</span>
</div>
<div className="flex justify-between items-center font-body-md text-body-md text-on-surface-variant">
<span className="">Shipping</span>
<span className="text-secondary font-medium">FREE</span>
</div>
</div>
<hr className="border-t border-surface-variant mb-6" />
<div className="flex justify-between items-baseline mb-8">
<span className="font-body-lg text-body-lg text-primary font-medium">Total</span>
<span className="font-headline-md text-headline-md text-primary">$235.00</span>
</div>
<button className="w-full bg-ink text-on-primary rounded-full py-4 px-6 font-label-sm text-label-sm uppercase flex items-center justify-center gap-2 hover:opacity-90 transition-opacity mb-8">
                        PROCEED TO CHECKOUT
                        <span className="material-symbols-outlined text-[16px]">arrow_forward</span>
</button>
<div className="space-y-4">
<div className="flex items-center gap-3 text-on-surface-variant">
<span className="material-symbols-outlined text-[20px]">lock</span>
<span className="font-body-md text-body-md text-sm">Secure payment</span>
</div>
<div className="flex items-center gap-3 text-on-surface-variant">
<span className="material-symbols-outlined text-[20px]">restart_alt</span>
<span className="font-body-md text-body-md text-sm">Easy 7-day returns</span>
</div>
<div className="flex items-center gap-3 text-on-surface-variant">
<span className="material-symbols-outlined text-[20px]">local_shipping</span>
<span className="font-body-md text-body-md text-sm">COD available</span>
</div>
</div>
</div>
</div>
</div>

<section className="mt-stack-lg">
<h2 className="font-headline-md text-headline-md md:font-headline-lg md:text-headline-lg text-primary mb-8 text-center">COMPLETE THE LOOK</h2>
<div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-gutter">

<div className="group cursor-pointer">
<div className="bg-surface-container-lowest rounded-24px overflow-hidden aspect-[3/4] mb-4 relative">
<img className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 ease-out" data-alt="A crisp white Oxford button-down shirt neatly laid flat against a soft, light grey studio background. Clean, precise lighting highlighting the cotton texture and collar structure. High-end, minimalist menswear editorial aesthetic." src="https://lh3.googleusercontent.com/aida-public/AB6AXuBChpUhxmbVFBIhLAbrjJiPov4M7B1af67kBPvBuCbvFmLQZfWO8kMbh35P-ywikNBJXO3_8bimGoUcqUrCtHeQwArUtkTwimsbKFeKekDOBisn_MByci-yLI_VhCm24Fca962GAj1qxeM2R0ooTA3an998O24gJ0qmvlDpOAiFtaPuQob0mDNFX72W4j17xqn8VPr9SCXgF4DBf81vy2QWors7U2EXzsbagKj88j4ibBwMvVd0w_mpbQ" />
<button className="absolute bottom-4 right-4 w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-ambient text-ink opacity-0 group-hover:opacity-100 transition-opacity duration-300">
<span className="material-symbols-outlined filled">shopping_bag</span>
</button>
</div>
<div className="text-left">
<h4 className="font-body-lg text-body-lg text-primary mb-1">Oxford Shirt</h4>
<span className="font-body-md text-body-md text-on-surface-variant">$95.00</span>
</div>
</div>

<div className="group cursor-pointer">
<div className="bg-surface-container-lowest rounded-24px overflow-hidden aspect-[3/4] mb-4 relative">
<div className="absolute top-4 left-4 z-10">
<span className="bg-sage text-white px-3 py-1 rounded-full font-label-sm text-label-sm uppercase">NEW</span>
</div>
<img className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 ease-out" data-alt="A pair of relaxed-fit olive green cargo trousers photographed flat against a white background. Top-down view showing pocket details and structured fabric drape. Minimalist, modern utilitarian fashion aesthetic with bright, clear lighting." src="https://lh3.googleusercontent.com/aida-public/AB6AXuCfF6jlEgNAdrkZwC6PA37lhseynX3yv9icBPKLJ5OML0Qsy6pkQFyDorNW6Uk3rc-HsTUlBZKNkaYkIloHXlu-s4r5-E9ddd1xOzuPk2kL85gSvjSKf0bdRrA1XCaCdoFvlPfDsotbtnK8N944lWfyW9ZV90N-s5Y341wvhFqD2ARKspx7W0uQrdBWW9NVtOXY4ACWTYz4eRL5_sPPwG_91QDgEPbodrcINqvtQ9eHtozyYzGwI9BDmA" />
<button className="absolute bottom-4 right-4 w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-ambient text-ink opacity-0 group-hover:opacity-100 transition-opacity duration-300">
<span className="material-symbols-outlined filled">shopping_bag</span>
</button>
</div>
<div className="text-left">
<h4 className="font-body-lg text-body-lg text-primary mb-1">Cargo Trousers</h4>
<span className="font-body-md text-body-md text-on-surface-variant">$125.00</span>
</div>
</div>

<div className="group cursor-pointer">
<div className="bg-surface-container-lowest rounded-24px overflow-hidden aspect-[3/4] mb-4 relative">
<img className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 ease-out" data-alt="A luxurious camel wool overcoat laid flat on a pristine white background. The heavy texture of the wool and the tailored silhouette are highlighted by soft, directional studio lighting. Elegant, timeless menswear editorial photography style." src="https://lh3.googleusercontent.com/aida-public/AB6AXuAS2DyScJhRMKGh-MH1YXlm7vmrWNZ6pUvAuElLwLPRzTRe8wVD82-a0vBRicd02H46XlsTy16KxsPAutM_vIE96IWXtl8ZuBQ53aCzuIt50Dwz9BBG6zC1ZZSJHsYesEw7T2c8yOgWLbEWm_G9QmxNRZdNXCFEzLP-IM4xvRRKIWc3pEDd11fkj8Efjf8hNgnQ1ZHvF-ssdWFy2krkO8lZb9WZ_2P-2wjb6robEAvKt_y-rf6IvME8hA" />
<button className="absolute bottom-4 right-4 w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-ambient text-ink opacity-0 group-hover:opacity-100 transition-opacity duration-300">
<span className="material-symbols-outlined filled">shopping_bag</span>
</button>
</div>
<div className="text-left">
<h4 className="font-body-lg text-body-lg text-primary mb-1">Wool Overcoat</h4>
<span className="font-body-md text-body-md text-on-surface-variant">$350.00</span>
</div>
</div>

<div className="group cursor-pointer">
<div className="bg-surface-container-lowest rounded-24px overflow-hidden aspect-[3/4] mb-4 relative">
<img className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 ease-out" data-alt="A long-sleeve ribbed knit polo shirt in dark navy blue, neatly folded flat on a bright white surface. The close-up crop emphasizes the rich texture of the knit pattern. High-end, moody yet minimalist fashion photography with sharp detail." src="https://lh3.googleusercontent.com/aida-public/AB6AXuCLZ44pMFJwQRQpKqcxnLptm3AjAlTpyk5ID27J1WySGt6Qob8JY6O9No1WlEEK3br178AyLumn6Iu9ShpV32VNQF7X2txx1tEsSQpF3jNC4JBmDAq8GX7J-Vd8FgP3OsyU4ejtgrOdfrGrI6EssuzK0C5iX41Suh5w_MnDTUFaQtiTmP42cK3ccyd2ANZBee8vvSQfeXzcuTzCoXjeExHK96BbMvj1AKGIHliYWmVEfqGSMY-4twFFfA" />
<button className="absolute bottom-4 right-4 w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-ambient text-ink opacity-0 group-hover:opacity-100 transition-opacity duration-300">
<span className="material-symbols-outlined filled">shopping_bag</span>
</button>
</div>
<div className="text-left">
<h4 className="font-body-lg text-body-lg text-primary mb-1">Ribbed Knit Polo</h4>
<span className="font-body-md text-body-md text-on-surface-variant">$85.00</span>
</div>
</div>
</div>
</section>
</main>
  );
}