const fs = require('fs');
let file = fs.readFileSync('src/app/layout.tsx', 'utf8');

const target = '<a className="hover:opacity-70 transition-opacity duration-300" href="#"><span className="material-symbols-outlined">shopping_bag</span></a>';

if (file.includes(target)) {
  let newFile = file.replace(target, '<CartIcon />');
  newFile = 'import CartIcon from "@/components/CartIcon";\n' + newFile;
  fs.writeFileSync('src/app/layout.tsx', newFile);
  console.log('Successfully injected CartIcon into layout.tsx');
} else {
  console.log('Target string not found in layout.tsx');
}
