export default function UixshuvoRefinedSearchResultsWhiteShirt() {
  return (
    <main className="pt-[140px] pb-stack-lg px-margin-mobile md:px-margin-desktop max-w-container-max mx-auto">

<section className="max-w-3xl mx-auto text-center mb-stack-md">
<div className="relative w-full mb-6">
<input className="w-full bg-surface-container-lowest border-0 rounded-full py-4 pl-12 pr-12 text-center font-body-lg text-on-surface focus:ring-1 focus:ring-outline-variant ambient-shadow" placeholder="Search products..." type="text" value="white shirt" />
<span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-on-surface-variant">search</span>
<button className="absolute right-4 top-1/2 -translate-y-1/2 text-on-surface-variant hover:text-on-surface transition-colors">
<span className="material-symbols-outlined">close</span>
</button>
</div>
<div className="flex flex-wrap justify-center gap-3">
<button className="px-4 py-2 rounded-full bg-surface-container-low text-on-surface-variant font-label-sm text-label-sm hover:bg-surface-variant transition-colors">oxford shirt</button>
<button className="px-4 py-2 rounded-full bg-surface-container-low text-on-surface-variant font-label-sm text-label-sm hover:bg-surface-variant transition-colors">white linen shirt</button>
<button className="px-4 py-2 rounded-full bg-surface-container-low text-on-surface-variant font-label-sm text-label-sm hover:bg-surface-variant transition-colors">formal white shirt</button>
</div>
</section>

<div className="flex flex-col md:flex-row justify-between items-end mb-12 border-b border-surface-variant pb-6 gap-6">
<h1 className="font-headline-lg text-headline-lg text-primary uppercase">SEARCH RESULTS — 24 ITEMS FOR 'WHITE SHIRT'</h1>
<div className="flex items-center gap-4 w-full md:w-auto overflow-x-auto pb-2 md:pb-0 hide-scrollbar">
<div className="flex gap-2">
<button className="px-4 py-2 rounded-full border border-outline-variant text-on-surface font-label-sm text-label-sm hover:bg-surface-variant transition-colors whitespace-nowrap">Size <span className="material-symbols-outlined text-[14px] align-middle ml-1">expand_more</span></button>
<button className="px-4 py-2 rounded-full border border-outline-variant text-on-surface font-label-sm text-label-sm hover:bg-surface-variant transition-colors whitespace-nowrap">Color <span className="material-symbols-outlined text-[14px] align-middle ml-1">expand_more</span></button>
<button className="px-4 py-2 rounded-full border border-outline-variant text-on-surface font-label-sm text-label-sm hover:bg-surface-variant transition-colors whitespace-nowrap">Price <span className="material-symbols-outlined text-[14px] align-middle ml-1">expand_more</span></button>
<button className="px-4 py-2 rounded-full border border-outline-variant text-on-surface font-label-sm text-label-sm hover:bg-surface-variant transition-colors whitespace-nowrap">Fabric <span className="material-symbols-outlined text-[14px] align-middle ml-1">expand_more</span></button>
</div>
<div className="w-px h-6 bg-outline-variant hidden md:block"></div>
<button className="px-4 py-2 rounded-full border border-outline-variant text-on-surface font-label-sm text-label-sm hover:bg-surface-variant transition-colors whitespace-nowrap flex items-center">
                    Sort by: Relevance <span className="material-symbols-outlined text-[14px] align-middle ml-1">expand_more</span>
</button>
</div>
</div>

<div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-gutter mb-stack-lg">

<article className="group bg-surface-container-lowest rounded-[24px] overflow-hidden ambient-shadow hover-lift flex flex-col relative">
<div className="absolute top-4 left-4 z-10">
<span className="bg-sage text-white px-3 py-1 rounded-full font-label-sm text-label-sm uppercase">NEW</span>
</div>
<button className="absolute top-4 right-4 z-10 w-10 h-10 bg-white/80 backdrop-blur rounded-full flex items-center justify-center text-on-surface hover:text-error transition-colors shadow-sm">
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 0"}}>favorite</span>
</button>
<div className="relative w-full aspect-[3/4] overflow-hidden bg-muted-lilac">
<img alt="Premium Oxford" className="w-full h-full object-cover image-zoom" data-alt="Premium Oxford" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBa4B4d54R74yytypRH0cKOvetlh6laQ1SmFwUDF4eZPN11G__12vamIY1zjBba7CiFczW_p2xQKjt1m8eKEpW6-Wazu8Yk0bqPnIaMor8InS0FjupJWLwprMXSyCm9Ov645VqKedExNeLlTuuUHj7dxw3G2mFjINTo80t3E9_50hFF9hRtfSzGpkfT_l25DWBn3W3PEbUNYn3nHx1Q_GM5gNjc5ROnGlLdoEadO48oMPdouz_jPz7O_g" />
</div>
<div className="p-6 flex flex-col flex-grow text-left">
<p className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider mb-2">Shirts</p>
<h3 className="font-headline-md text-headline-md text-primary mb-2 line-clamp-1">Premium Oxford</h3>
<div className="flex items-center gap-1 mb-4">
<div className="flex text-[#D4AF37] text-[14px]">
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
</div>
<span className="text-xs text-on-surface-variant ml-1">(42)</span>
</div>
<div className="mt-auto flex items-center justify-between">
<div className="flex items-center gap-3">
<span className="font-body-lg text-body-lg text-primary font-medium">$85.00</span>
<span className="font-body-md text-body-md text-on-surface-variant line-through decoration-1">$110.00</span>
</div>
<button className="w-10 h-10 rounded-full bg-ink text-white flex items-center justify-center hover:opacity-80 transition-opacity">
<span className="material-symbols-outlined text-[20px]">add_shopping_cart</span>
</button>
</div>
</div>
</article>

<article className="group bg-surface-container-lowest rounded-[24px] overflow-hidden ambient-shadow hover-lift flex flex-col relative">
<div className="absolute top-4 left-4 z-10">
<span className="bg-sage text-white px-3 py-1 rounded-full font-label-sm text-label-sm uppercase">NEW</span>
</div>
<button className="absolute top-4 right-4 z-10 w-10 h-10 bg-white/80 backdrop-blur rounded-full flex items-center justify-center text-on-surface hover:text-error transition-colors shadow-sm">
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 0"}}>favorite</span>
</button>
<div className="relative w-full aspect-[3/4] overflow-hidden bg-muted-lilac">
<img alt="Relaxed Linen" className="w-full h-full object-cover image-zoom" data-alt="Relaxed Linen" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBHcoMhDru3m32NksiEtpJ0S3QrHd3HbcdBok91GcEy17GsI5W3c62uUO2sJ8NLot9DpXe0PnTwfRcK-rj2yb1VlSS-DJEJH0LbICPTV5o-qI6YaW4p0bkAKWpoyGGLj3vQKCvHMB2CJFWZk0oWbkTFn4RpAk4yYfwK8kr6YX6k6ZxDhyKQSrNFAUU1u27oGhoowQz57gaHRajwbeOkEvNSGAuLTgE1olm68DidWAdO8zll145QcsOWfA" />
</div>
<div className="p-6 flex flex-col flex-grow text-left">
<p className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider mb-2">Shirts</p>
<h3 className="font-headline-md text-headline-md text-primary mb-2 line-clamp-1">Relaxed Linen</h3>
<div className="flex items-center gap-1 mb-4">
<div className="flex text-[#D4AF37] text-[14px]">
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1"}}>star_half</span>
</div>
<span className="text-xs text-on-surface-variant ml-1">(18)</span>
</div>
<div className="mt-auto flex items-center justify-between">
<div className="flex items-center gap-3">
<span className="font-body-lg text-body-lg text-primary font-medium">$95.00</span>
</div>
<button className="w-10 h-10 rounded-full bg-ink text-white flex items-center justify-center hover:opacity-80 transition-opacity">
<span className="material-symbols-outlined text-[20px]">add_shopping_cart</span>
</button>
</div>
</div>
</article>

<article className="group bg-surface-container-lowest rounded-[24px] overflow-hidden ambient-shadow hover-lift flex flex-col relative">
<div className="absolute top-4 left-4 z-10">
<span className="bg-sage text-white px-3 py-1 rounded-full font-label-sm text-label-sm uppercase">NEW</span>
</div>
<button className="absolute top-4 right-4 z-10 w-10 h-10 bg-white/80 backdrop-blur rounded-full flex items-center justify-center text-on-surface hover:text-error transition-colors shadow-sm">
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 0"}}>favorite</span>
</button>
<div className="relative w-full aspect-[3/4] overflow-hidden bg-muted-lilac">
<img alt="Classic Dress Shirt" className="w-full h-full object-cover image-zoom" data-alt="Classic Dress Shirt" src="https://lh3.googleusercontent.com/aida-public/AB6AXuB4zpBbXHf6dOaD95ZOu5caPX5dzkWOnO09PQns7iFknqOsvD9VFOt_8u5pjVpISYtdfP5F0HPTKNc4lCKJ2IbEhSzlzGhdaAgmNauRvw17Xmo7W4ZNWpIBxQqUierDZBpdjctN9dSbasf9sVyuEja-AKsRXEIvCidFjJCFj4-4VZleESw3j2wzX6CTK_Sxf9NMAsNO_p8DeONDaen-vNSsV8A4rH2VU1qq9YjGnSSxzPJdkG1XtBAtTA" />
</div>
<div className="p-6 flex flex-col flex-grow text-left">
<p className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider mb-2">Formal</p>
<h3 className="font-headline-md text-headline-md text-primary mb-2 line-clamp-1">Classic Dress Shirt</h3>
<div className="flex items-center gap-1 mb-4">
<div className="flex text-[#D4AF37] text-[14px]">
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
</div>
<span className="text-xs text-on-surface-variant ml-1">(56)</span>
</div>
<div className="mt-auto flex items-center justify-between">
<div className="flex items-center gap-3">
<span className="font-body-lg text-body-lg text-primary font-medium">$120.00</span>
</div>
<button className="w-10 h-10 rounded-full bg-ink text-white flex items-center justify-center hover:opacity-80 transition-opacity">
<span className="material-symbols-outlined text-[20px]">add_shopping_cart</span>
</button>
</div>
</div>
</article>

<article className="group bg-surface-container-lowest rounded-[24px] overflow-hidden ambient-shadow hover-lift flex flex-col relative">
<div className="absolute top-4 left-4 z-10">
<span className="bg-sage text-white px-3 py-1 rounded-full font-label-sm text-label-sm uppercase">NEW</span>
</div>
<button className="absolute top-4 right-4 z-10 w-10 h-10 bg-white/80 backdrop-blur rounded-full flex items-center justify-center text-on-surface hover:text-error transition-colors shadow-sm">
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 0"}}>favorite</span>
</button>
<div className="relative w-full aspect-[3/4] overflow-hidden bg-muted-lilac">
<img alt="Grandad Collar" className="w-full h-full object-cover image-zoom" data-alt="Grandad Collar" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBtRKVzE0T-YUm5cI2VsBz2iVywh-Dh2ym8tOx7Fxk0DV9t2GVYvu2avqGLd02vS9nUpe8zpPM7GaTjB1v91OtijHXA9OrMeXViCUxkf0YUJcsAEW1OPkrhtIBhjRtRSJr8GjK4qv3H54ea3oaYxiAoJ9HbnzQCnqTE00lkbE7JNclXPLnPlKzyDk01FtxEEfsVzF0R6kkVWO4At0Re_F_S5jW3W0p-Apir8DZ5gdGRwxvJCWZ4gc7-sg" />
</div>
<div className="p-6 flex flex-col flex-grow text-left">
<p className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider mb-2">Casual</p>
<h3 className="font-headline-md text-headline-md text-primary mb-2 line-clamp-1">Grandad Collar</h3>
<div className="flex items-center gap-1 mb-4">
<div className="flex text-[#D4AF37] text-[14px]">
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
</div>
<span className="text-xs text-on-surface-variant ml-1">(12)</span>
</div>
<div className="mt-auto flex items-center justify-between">
<div className="flex items-center gap-3">
<span className="font-body-lg text-body-lg text-primary font-medium">$75.00</span>
<span className="font-body-md text-body-md text-on-surface-variant line-through decoration-1">$90.00</span>
</div>
<button className="w-10 h-10 rounded-full bg-ink text-white flex items-center justify-center hover:opacity-80 transition-opacity">
<span className="material-symbols-outlined text-[20px]">add_shopping_cart</span>
</button>
</div>
</div>
</article>

<article className="group bg-surface-container-lowest rounded-[24px] overflow-hidden ambient-shadow hover-lift flex flex-col relative">
<div className="absolute top-4 left-4 z-10">
<span className="bg-sage text-white px-3 py-1 rounded-full font-label-sm text-label-sm uppercase">NEW</span>
</div>
<button className="absolute top-4 right-4 z-10 w-10 h-10 bg-white/80 backdrop-blur rounded-full flex items-center justify-center text-on-surface hover:text-error transition-colors shadow-sm">
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 0"}}>favorite</span>
</button>
<div className="relative w-full aspect-[3/4] overflow-hidden bg-muted-lilac">
<img alt="Poplin Shirt" className="w-full h-full object-cover image-zoom" data-alt="Poplin Shirt" src="https://lh3.googleusercontent.com/aida-public/AB6AXuApuwEhuc8ukqmFRHEcyhwKtY5KqYIEepoUkgrsfR-5ACVJsnbJZlrWtsLhaiem9-cgGKdRQ7Cg1U8uuvNKTO5c1bAn8rfhqWkl9fMLt7VRnNgeyf6DJ6ZjPBOU4L3fRL_53l47pB6qgJIqxFRZwC-BnJL4jDAGWUXHu7QzjZe0nvGH9SJaA3pS1T1IlkacznF8hO8zG4zLA2iOWNL8UJwYWmoZ91Ut6Q4O7d9KmWQwFZSq2ijtTvgLPg" />
</div>
<div className="p-6 flex flex-col flex-grow text-left">
<p className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider mb-2">Shirts</p>
<h3 className="font-headline-md text-headline-md text-primary mb-2 line-clamp-1">Poplin Shirt</h3>
<div className="flex items-center gap-1 mb-4">
<div className="flex text-[#D4AF37] text-[14px]">
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1"}}>star_half</span>
</div>
<span className="text-xs text-on-surface-variant ml-1">(24)</span>
</div>
<div className="mt-auto flex items-center justify-between">
<div className="flex items-center gap-3">
<span className="font-body-lg text-body-lg text-primary font-medium">$80.00</span>
</div>
<button className="w-10 h-10 rounded-full bg-ink text-white flex items-center justify-center hover:opacity-80 transition-opacity">
<span className="material-symbols-outlined text-[20px]">add_shopping_cart</span>
</button>
</div>
</div>
</article>

<article className="group bg-surface-container-lowest rounded-[24px] overflow-hidden ambient-shadow hover-lift flex flex-col relative">
<div className="absolute top-4 left-4 z-10">
<span className="bg-sage text-white px-3 py-1 rounded-full font-label-sm text-label-sm uppercase">NEW</span>
</div>
<button className="absolute top-4 right-4 z-10 w-10 h-10 bg-white/80 backdrop-blur rounded-full flex items-center justify-center text-on-surface hover:text-error transition-colors shadow-sm">
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 0"}}>favorite</span>
</button>
<div className="relative w-full aspect-[3/4] overflow-hidden bg-muted-lilac">
<img alt="Cotton Tee" className="w-full h-full object-cover image-zoom" data-alt="Cotton Tee" src="https://lh3.googleusercontent.com/aida-public/AB6AXuA1hbGeAlP4VRXi9qw6PNSJUANTymZfvo9FOZOCJ7qrm1Q1fPb9CSv23IZr7LhR0whEkAOpWZCr8uSoegcjAGhnhukwECerGjxM2g2o2ml9tp98vEU7beSzylM9VxHDER3T8haxvoWZFEoH2Vvo12Dra4yG-tzrgkQXMV8WgjrF-V5QUf8jx5YBe8L4B6tHenIHbf8Js96KAGeH-BxgMfG_KXTAEhCUVQLsZyU30vPrm9bXqsM4_FLBXQ" />
</div>
<div className="p-6 flex flex-col flex-grow text-left">
<p className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider mb-2">Basics</p>
<h3 className="font-headline-md text-headline-md text-primary mb-2 line-clamp-1">Cotton Tee</h3>
<div className="flex items-center gap-1 mb-4">
<div className="flex text-[#D4AF37] text-[14px]">
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
</div>
<span className="text-xs text-on-surface-variant ml-1">(89)</span>
</div>
<div className="mt-auto flex items-center justify-between">
<div className="flex items-center gap-3">
<span className="font-body-lg text-body-lg text-primary font-medium">$45.00</span>
</div>
<button className="w-10 h-10 rounded-full bg-ink text-white flex items-center justify-center hover:opacity-80 transition-opacity">
<span className="material-symbols-outlined text-[20px]">add_shopping_cart</span>
</button>
</div>
</div>
</article>

<article className="group bg-surface-container-lowest rounded-[24px] overflow-hidden ambient-shadow hover-lift flex flex-col relative">
<div className="absolute top-4 left-4 z-10">
<span className="bg-sage text-white px-3 py-1 rounded-full font-label-sm text-label-sm uppercase">NEW</span>
</div>
<button className="absolute top-4 right-4 z-10 w-10 h-10 bg-white/80 backdrop-blur rounded-full flex items-center justify-center text-on-surface hover:text-error transition-colors shadow-sm">
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 0"}}>favorite</span>
</button>
<div className="relative w-full aspect-[3/4] overflow-hidden bg-muted-lilac">
<img alt="Polo Shirt" className="w-full h-full object-cover image-zoom" data-alt="Polo Shirt" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCz1PIBceTUby7zEwWHnldrpMp0NdAr-w8zcwyl3Ess-maFih4KQQ1PhEtcGJDW9JZeeikJLQXUj1zze6wTmxS_4q0zsE0R6Ncc4ax_QYInXfmeUgmYmJcTCl3J2or7dZ21tejmqYZMvbREvt4rWJXM2OkBTaVHpobS1y7FfR8TDUVHB4rVp3yHqr0ZkyvRT9I5RWfSQuKYViISDQtEpZDNmDN63h1fVLaXA4PHSEjmfSPp4iBXxsaGyw" />
</div>
<div className="p-6 flex flex-col flex-grow text-left">
<p className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider mb-2">Casual</p>
<h3 className="font-headline-md text-headline-md text-primary mb-2 line-clamp-1">Polo Shirt</h3>
<div className="flex items-center gap-1 mb-4">
<div className="flex text-[#D4AF37] text-[14px]">
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
</div>
<span className="text-xs text-on-surface-variant ml-1">(34)</span>
</div>
<div className="mt-auto flex items-center justify-between">
<div className="flex items-center gap-3">
<span className="font-body-lg text-body-lg text-primary font-medium">$65.00</span>
</div>
<button className="w-10 h-10 rounded-full bg-ink text-white flex items-center justify-center hover:opacity-80 transition-opacity">
<span className="material-symbols-outlined text-[20px]">add_shopping_cart</span>
</button>
</div>
</div>
</article>

<article className="group bg-surface-container-lowest rounded-[24px] overflow-hidden ambient-shadow hover-lift flex flex-col relative">
<div className="absolute top-4 left-4 z-10">
<span className="bg-sage text-white px-3 py-1 rounded-full font-label-sm text-label-sm uppercase">NEW</span>
</div>
<button className="absolute top-4 right-4 z-10 w-10 h-10 bg-white/80 backdrop-blur rounded-full flex items-center justify-center text-on-surface hover:text-error transition-colors shadow-sm">
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 0"}}>favorite</span>
</button>
<div className="relative w-full aspect-[3/4] overflow-hidden bg-muted-lilac">
<img alt="Henley Shirt" className="w-full h-full object-cover image-zoom" data-alt="Henley Shirt" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAdiTx2DhUVbkRqEqKBneFQnUkXgInghNFeC3g_bKZfUxXj2i-RSng-EUqbAC33edyQy2_hPoh3YociNGxjE4S9u55AlERmwoDXrhEOY8IdgBUFh07jcSs6XiFaHZEYUNeS-fc33gS6Xc2kWuCvP9-W6w86cW4BYCBLiTAVZ6HXYQBb8Zh877wSw_nodBQEumcAuqAu1fm6V3SS9stsRM4O-EeM2T5zOCYMq7zsXfM-08TJS_sn-RpkuQ" />
</div>
<div className="p-6 flex flex-col flex-grow text-left">
<p className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider mb-2">Casual</p>
<h3 className="font-headline-md text-headline-md text-primary mb-2 line-clamp-1">Henley Shirt</h3>
<div className="flex items-center gap-1 mb-4">
<div className="flex text-[#D4AF37] text-[14px]">
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1"}}>star</span>
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1"}}>star_half</span>
</div>
<span className="text-xs text-on-surface-variant ml-1">(21)</span>
</div>
<div className="mt-auto flex items-center justify-between">
<div className="flex items-center gap-3">
<span className="font-body-lg text-body-lg text-primary font-medium">$55.00</span>
</div>
<button className="w-10 h-10 rounded-full bg-ink text-white flex items-center justify-center hover:opacity-80 transition-opacity">
<span className="material-symbols-outlined text-[20px]">add_shopping_cart</span>
</button>
</div>
</div>
</article>
</div>

<div className="flex flex-col items-center justify-center space-y-6 mt-12">
<p className="font-body-md text-body-md text-on-surface-variant italic">No more results</p>
<button className="px-8 py-4 rounded-full border border-ink text-ink font-label-sm text-label-sm uppercase tracking-widest hover:bg-ink hover:text-white transition-all duration-300">
                VIEW ALL SHIRTS
            </button>
</div>
</main>
  );
}