const fs = require('fs');
const path = require('path');

function walk(dir) {
  const files = fs.readdirSync(dir);
  for (const file of files) {
    const fullPath = path.join(dir, file);
    if (fs.statSync(fullPath).isDirectory()) {
      walk(fullPath);
    } else if (fullPath.endsWith('.tsx') && !fullPath.includes('node_modules')) {
      let content = fs.readFileSync(fullPath, 'utf8');
      let originalContent = content;
      
      content = content.replace(/\sopen=""/g, ' open={true}');
      
      if (content !== originalContent) {
        fs.writeFileSync(fullPath, content);
        console.log(`Fixed open attribute in ${fullPath}`);
      }
    }
  }
}

walk('src/app');
