export default function SettingsMenSWear() {
  return (
    <main className="flex-1 ml-0 md:ml-64 flex flex-col h-screen overflow-hidden">

<header className="flex justify-between items-center h-16 px-lg sticky top-0 z-40 bg-surface dark:bg-surface-container-high transition-all duration-200">
<div className="flex items-center gap-md">
<button className="md:hidden text-on-surface-variant hover:text-primary transition-colors">
<span className="material-symbols-outlined">menu</span>
</button>
</div>
<div className="flex items-center gap-lg">
<button className="text-on-surface-variant hover:text-primary transition-colors relative">
<span className="material-symbols-outlined">notifications</span>
<span className="absolute top-1 right-1 w-2 h-2 bg-error rounded-full"></span>
</button>
<div className="w-8 h-8 rounded-full overflow-hidden border border-outline-variant">
<img alt="User Avatar" className="w-full h-full object-cover" data-alt="A small, professional circular avatar portrait of a man in a well-tailored dark suit against a crisp white background. High resolution, bright studio lighting, minimalist executive aesthetic." src="https://lh3.googleusercontent.com/aida-public/AB6AXuD0sG5hX7jSBwZ8u7F5TsxBLFI3VjL2WU9yTkDMHLSQU9wmVyT-l6KM2Cl36q7h5inEhTUYL3NtbcYN4ozca_UA3tQdULN_M-OHxDB4valDU9l4l3_bEPz5qXGsF-IO5Bq2PHyOXElQDPEUusON-yA75ukitHmWLGXn5LBDPkSB9zEhiF1OE14wwirNTNMXplObcJLvnraUxRWdXqojhapW3L-gpjRuCDvWoVAcRUUEfnrC0nawxmlY"/>
</div>
</div>
</header>

<div className="flex-1 overflow-y-auto px-margin-mobile md:px-margin-desktop py-xl">
<div className="max-w-container-max mx-auto">

<div className="mb-xl flex flex-col md:flex-row md:items-end justify-between gap-lg border-b border-surface-variant pb-md">
<div>
<h1 className="font-headline-lg text-headline-lg text-primary mb-md">SETTINGS</h1>
<div className="flex flex-wrap gap-sm">
<button className="px-lg py-sm rounded-full bg-primary text-on-primary font-label-lg text-label-lg transition-colors">Store</button>
<button className="px-lg py-sm rounded-full bg-surface-container-low text-on-surface-variant hover:bg-surface-container-high font-label-lg text-label-lg transition-colors border border-outline-variant">Shipping &amp; Payment</button>
<button className="px-lg py-sm rounded-full bg-surface-container-low text-on-surface-variant hover:bg-surface-container-high font-label-lg text-label-lg transition-colors border border-outline-variant">Staff &amp; Roles</button>
</div>
</div>
<button className="px-lg py-sm h-12 rounded-full bg-primary text-on-primary font-label-lg text-label-lg hover:bg-on-surface-variant transition-colors flex items-center justify-center gap-sm w-full md:w-auto">
                        SAVE CHANGES
                    </button>
</div>

<div className="grid grid-cols-1 lg:grid-cols-12 gap-lg">

<div className="lg:col-span-8 flex flex-col gap-lg">

<div className="bg-surface-container-lowest rounded-[24px] p-lg">
<h2 className="font-headline-md text-headline-md text-primary mb-lg">Store Information</h2>
<div className="grid grid-cols-1 md:grid-cols-2 gap-lg mb-lg">
<div className="flex flex-col gap-sm">
<label className="font-label-lg text-label-lg text-on-surface-variant uppercase tracking-widest">Store Name</label>
<input className="h-12 px-md rounded-lg border border-outline-variant/30 bg-surface-container-lowest focus:border-[#8FB0A4] focus:ring-0 font-body-md text-body-md text-primary transition-colors" type="text" value="MEN'S WEAR"/>
</div>
<div className="flex flex-col gap-sm">
<label className="font-label-lg text-label-lg text-on-surface-variant uppercase tracking-widest">Order ID Prefix</label>
<input className="h-12 px-md rounded-lg border border-outline-variant/30 bg-surface-container-lowest focus:border-[#8FB0A4] focus:ring-0 font-body-md text-body-md text-primary transition-colors" type="text" value="#MW-"/>
</div>
</div>
<div className="flex flex-col gap-sm mb-lg">
<label className="font-label-lg text-label-lg text-on-surface-variant uppercase tracking-widest">Store Logo</label>
<div className="border-2 border-dashed border-outline-variant/50 rounded-xl p-xl flex flex-col items-center justify-center bg-[#F5F4F8] hover:bg-surface-container-low transition-colors cursor-pointer">
<span className="material-symbols-outlined text-outline text-display-lg mb-sm">cloud_upload</span>
<p className="font-body-md text-body-md text-on-surface-variant">Drag and drop your logo here, or <span className="text-primary underline">browse</span></p>
<p className="font-body-sm text-body-sm text-outline mt-xs">PNG, JPG up to 5MB</p>
</div>
</div>
<div className="grid grid-cols-1 md:grid-cols-2 gap-lg mb-lg">
<div className="flex flex-col gap-sm">
<label className="font-label-lg text-label-lg text-on-surface-variant uppercase tracking-widest">Contact Email</label>
<input className="h-12 px-md rounded-lg border border-outline-variant/30 bg-surface-container-lowest focus:border-[#8FB0A4] focus:ring-0 font-body-md text-body-md text-primary transition-colors" type="email" value="contact@menswear.com"/>
</div>
<div className="flex flex-col gap-sm">
<label className="font-label-lg text-label-lg text-on-surface-variant uppercase tracking-widest">Phone Number</label>
<input className="h-12 px-md rounded-lg border border-outline-variant/30 bg-surface-container-lowest focus:border-[#8FB0A4] focus:ring-0 font-body-md text-body-md text-primary transition-colors" type="tel" value="+1 (555) 123-4567"/>
</div>
</div>
<div className="grid grid-cols-1 md:grid-cols-2 gap-lg">
<div className="flex flex-col gap-sm">
<label className="font-label-lg text-label-lg text-on-surface-variant uppercase tracking-widest">Store Address</label>
<input className="h-12 px-md rounded-lg border border-outline-variant/30 bg-surface-container-lowest focus:border-[#8FB0A4] focus:ring-0 font-body-md text-body-md text-primary transition-colors" type="text" value="123 Tailor Street, NY 10001"/>
</div>
<div className="flex flex-col gap-sm">
<label className="font-label-lg text-label-lg text-on-surface-variant uppercase tracking-widest">Currency</label>
<select className="h-12 px-md rounded-lg border border-outline-variant/30 bg-surface-container-lowest focus:border-[#8FB0A4] focus:ring-0 font-body-md text-body-md text-primary transition-colors appearance-none">
<option value="USD">USD ($)</option>
<option value="EUR">EUR (€)</option>
<option value="GBP">GBP (£)</option>
</select>
</div>
</div>
</div>
</div>

<div className="lg:col-span-4 flex flex-col gap-lg">

<div className="bg-surface-container-lowest rounded-[24px] p-lg">
<h2 className="font-headline-md text-headline-md text-primary mb-lg">Alert Preferences</h2>
<div className="flex flex-col gap-md">
<div className="flex items-center justify-between py-sm border-b border-surface-variant">
<span className="font-body-md text-body-md text-primary">New order alert</span>
<button aria-pressed="true" className="w-12 h-6 rounded-full bg-[#8FB0A4] relative transition-colors">
<span className="absolute right-1 top-1 w-4 h-4 rounded-full bg-surface-container-lowest shadow-sm"></span>
</button>
</div>
<div className="flex items-center justify-between py-sm border-b border-surface-variant">
<span className="font-body-md text-body-md text-primary">Low stock alert</span>
<button aria-pressed="true" className="w-12 h-6 rounded-full bg-[#8FB0A4] relative transition-colors">
<span className="absolute right-1 top-1 w-4 h-4 rounded-full bg-surface-container-lowest shadow-sm"></span>
</button>
</div>
<div className="flex items-center justify-between py-sm border-b border-surface-variant">
<span className="font-body-md text-body-md text-primary">Return request alert</span>
<button aria-pressed="true" className="w-12 h-6 rounded-full bg-[#8FB0A4] relative transition-colors">
<span className="absolute right-1 top-1 w-4 h-4 rounded-full bg-surface-container-lowest shadow-sm"></span>
</button>
</div>
<div className="flex items-center justify-between py-sm">
<span className="font-body-md text-body-md text-primary">Daily sales summary</span>
<button aria-pressed="false" className="w-12 h-6 rounded-full bg-surface-variant relative transition-colors">
<span className="absolute left-1 top-1 w-4 h-4 rounded-full bg-surface-container-lowest shadow-sm"></span>
</button>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</main>
  );
}