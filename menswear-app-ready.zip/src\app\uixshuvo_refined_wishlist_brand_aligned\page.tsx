export default function UixshuvoRefinedWishlistBrandAligned() {
  return (
    <main className="flex-grow pt-[120px] pb-stack-lg max-w-container-max mx-auto w-full px-margin-desktop flex flex-col items-center">

<div className="w-full mb-stack-md flex justify-start">
<nav aria-label="Breadcrumb">
<ol className="flex items-center space-x-2 text-label-sm font-label-sm text-on-surface-variant uppercase tracking-widest">
<li className=""><a className="hover:text-primary transition-colors" href="/">Home</a></li>
<li className=""><span className="text-outline-variant">/</span></li>
<li className=""><a className="hover:text-primary transition-colors" href="/account">Account</a></li>
<li className=""><span className="text-outline-variant">/</span></li>
<li aria-current="page" className="text-primary">Wishlist</li>
</ol>
</nav>
</div>

<div className="w-full flex justify-between items-end mb-stack-lg border-b border-outline-variant pb-6">
<h1 className="font-headline-lg text-headline-lg uppercase tracking-widest text-primary">MY WISHLIST (6)</h1>
<button className="px-6 py-3 rounded-full border border-primary text-primary font-body-md text-body-md hover:bg-surface-variant transition-colors duration-300 flex items-center gap-2">
<span className="">SHARE WISHLIST</span>
</button>
</div>

<div className="w-full bg-sage text-on-primary py-4 px-6 rounded-24 mb-stack-lg flex items-center justify-center gap-3">
<span className="material-symbols-outlined text-sm" style={{"fontVariationSettings": "\'FILL\' 0"}}>shopping_bag</span>
<p className="font-body-md text-body-md">Items in your wishlist are not reserved — checkout soon.</p>
</div>

<div className="w-full grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-gutter">

<div className="bg-surface-container-lowest rounded-24 overflow-hidden shadow-ambient hover-lift group relative flex flex-col">
<button className="absolute top-4 right-4 z-10 w-10 h-10 bg-surface-container-lowest rounded-full flex items-center justify-center shadow-sm text-primary hover:scale-110 transition-transform">
<span className="material-symbols-outlined text-[20px]" style={{"fontVariationSettings": "\'FILL\' 1","color": "#000000"}}>favorite</span>
</button>
<div className="relative w-full aspect-[4/5] overflow-hidden bg-surface-container-low">
<img className="w-full h-full object-cover img-zoom" data-alt="A pristine white men's Slim Fit Oxford Shirt perfectly folded on a soft, minimalist light grey surface. The lighting is bright and even, highlighting the subtle texture of the cotton fabric. The setting is clean and editorial, reflecting a modern, quiet luxury aesthetic with cool, airy undertones." src="https://lh3.googleusercontent.com/aida/AP1WRLtfdaW2daAoiyD_rytcUgGPIncw_CCQbkBGulvFxl5SMVxsY_HhyHQiza1LChOz91SOaEEHERaf9Qh-3QzuQGE5b6ubl8zVuqcvvLI0uxMI7DEmghRKkQj_q0sb6-yM_DJ9E0muZ5JemdBzJGeQJ7Z46KC_y6FrYN6jES5BEnpU0W55y7OutXNLkoAarPKdAGBq4RrqaqWujrLijy90tUMWOFkpj4yT9Nz3ItWACd22ATVRowgaTQhu7OHv" />
</div>
<div className="p-6 flex flex-col flex-grow">
<div className="flex justify-between items-start mb-2">
<div>
<h3 className="font-headline-md text-[20px] text-primary mb-1">Slim Fit Oxford Shirt</h3>
<p className="font-label-sm text-label-sm text-on-surface-variant uppercase">Shirts</p>
</div>
<span className="font-body-md text-body-md text-primary">$85.00</span>
</div>
<div className="mt-auto pt-6 flex justify-between items-center">
<button className="bg-primary text-on-primary px-6 py-2 rounded-full font-body-md text-sm flex items-center gap-2 hover:bg-inverse-surface transition-colors">
                            MOVE TO CART <span className="">→</span>
</button>
<button className="text-outline hover:text-error transition-colors p-2">
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1","color": "#000000"}}>close</span>
</button>
</div>
</div>
</div>

<div className="bg-surface-container-lowest rounded-24 overflow-hidden shadow-ambient hover-lift group relative flex flex-col">
<button className="absolute top-4 right-4 z-10 w-10 h-10 bg-surface-container-lowest rounded-full flex items-center justify-center shadow-sm text-primary hover:scale-110 transition-transform">
<span className="material-symbols-outlined text-[20px]" style={{"fontVariationSettings": "\'FILL\' 1","color": "#000000"}}>favorite</span>
</button>
<div className="relative w-full aspect-[4/5] overflow-hidden bg-surface-container-low">
<img className="w-full h-full object-cover img-zoom" data-alt="A meticulously folded pair of dark indigo men's Selvedge Jeans placed on a smooth concrete floor. The raw denim texture is detailed, showing subtle white weft threads. Soft, diffuse natural light creates gentle shadows, emphasizing a high-end, minimalist menswear editorial style." src="https://lh3.googleusercontent.com/aida/AP1WRLusg0K3F_ypapeR-272hJjPMps24n77A4kcPO74u-PepPjQP4xrArAaPmx4HXF98zzF5aAmM4D8qoeN8BcnDKlMvYdJesslyusGwmRzHS2_FOKrlg15n79XDPqmRW-NwZ1653jIjsfJlU6zJANjLCafr_Qn9maNoxpNsi69yRpxdOB2cfe0am1n-TCXVZvvZl9fsxf9zZr0_wIiK0k4DEXruFKixWhYViVDldPeG2GGbsOc2Ag1mm-peK1b" />
</div>
<div className="p-6 flex flex-col flex-grow">
<div className="flex justify-between items-start mb-2">
<div>
<h3 className="font-headline-md text-[20px] text-primary mb-1">Selvedge Jeans</h3>
<p className="font-label-sm text-label-sm text-on-surface-variant uppercase">Denim</p>
</div>
<span className="font-body-md text-body-md text-primary">$145.00</span>
</div>
<div className="mt-auto pt-6 flex justify-between items-center">
<button className="bg-primary text-on-primary px-6 py-2 rounded-full font-body-md text-sm flex items-center gap-2 hover:bg-inverse-surface transition-colors">
                            MOVE TO CART <span className="">→</span>
</button>
<button className="text-outline hover:text-error transition-colors p-2">
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1","color": "#000000"}}>close</span>
</button>
</div>
</div>
</div>

<div className="bg-surface-container-lowest rounded-24 overflow-hidden shadow-ambient hover-lift group relative flex flex-col">
<button className="absolute top-4 right-4 z-10 w-10 h-10 bg-surface-container-lowest rounded-full flex items-center justify-center shadow-sm text-primary hover:scale-110 transition-transform">
<span className="material-symbols-outlined text-[20px]" style={{"fontVariationSettings": "\'FILL\' 1","color": "#000000"}}>favorite</span>
</button>
<div className="relative w-full aspect-[4/5] overflow-hidden bg-surface-container-low">
<img className="w-full h-full object-cover img-zoom" data-alt="A handsome male model wearing a crisp, unbuttoned white Premium Linen Shirt and dark trousers, standing confidently against a textured, muted plaster wall. The aesthetic is 'quiet luxury', featuring soft, directional studio lighting that highlights the relaxed elegance of the linen fabric and the minimalist setting." src="https://lh3.googleusercontent.com/aida/AP1WRLt4w_P9PwVGDP0cjfsPUzrbWdNx23XkxGKetBWA0_IHbXPqPFU5Z3PQLKUTob4e6P6WrBUPQG1CXss4x5FmXZxXej-pFPWMVcvKM_HzT4KrprUvsV0rjvbol-p_tnnS1kck5joK3oYL0IzFc1V3OVQYLNJysdCmKzJVhEQ56lymxhZxZHBoH3c_V4JZdsSG2ICnMOjDz0KMyOkvyG9nJbivpUhHU5CoeEqb6-liKAJUi6uhta4z6VuL58xi" />
</div>
<div className="p-6 flex flex-col flex-grow">
<div className="flex justify-between items-start mb-2">
<div>
<h3 className="font-headline-md text-[20px] text-primary mb-1">Premium Linen Shirt</h3>
<p className="font-label-sm text-label-sm text-on-surface-variant uppercase">Shirts</p>
</div>
<span className="font-body-md text-body-md text-primary">$95.00</span>
</div>
<div className="mt-auto pt-6 flex justify-between items-center">
<button className="bg-primary text-on-primary px-6 py-2 rounded-full font-body-md text-sm flex items-center gap-2 hover:bg-inverse-surface transition-colors">
                            MOVE TO CART <span className="">→</span>
</button>
<button className="text-outline hover:text-error transition-colors p-2">
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1","color": "#000000"}}>close</span>
</button>
</div>
</div>
</div>

<div className="bg-surface-container-lowest rounded-24 overflow-hidden shadow-ambient hover-lift group relative flex flex-col">
<button className="absolute top-4 right-4 z-10 w-10 h-10 bg-surface-container-lowest rounded-full flex items-center justify-center shadow-sm text-primary hover:scale-110 transition-transform">
<span className="material-symbols-outlined text-[20px]" style={{"fontVariationSettings": "\'FILL\' 1","color": "#000000"}}>favorite</span>
</button>
<div className="relative w-full aspect-[4/5] overflow-hidden bg-surface-container-low">
<img className="w-full h-full object-cover img-zoom" data-alt="A close-up shot of tailored, dark charcoal grey Wool Trousers hanging neatly on a wooden hanger against a clean, off-white background. The lighting is soft and sophisticated, emphasizing the drape and high-quality weave of the wool fabric in a luxurious, minimalist style." src="https://lh3.googleusercontent.com/aida-public/AB6AXuAsuuHCtBQmU19rEwjn-quEoWekSmF6AqxXhji2wEXmlRqfkLSGBd8kKHrbHl-D2_0wfBtIQajehqpxIDcf2WF9I15wbzhYcxyDKFG03X26iZxmkt1I1w8bhSg26SK60x1cEOvjUYdCAk9DxBCM6k6fXvsOeBJUYonS8JhtGiCCwaBm63SOvxszVNNBFXMSrFN8-HnYLv-XZMU1ZK4cCVRNfhqxNfs9PcAMURs3dMBNhwUVmFU229efvw" />
</div>
<div className="p-6 flex flex-col flex-grow">
<div className="flex justify-between items-start mb-2">
<div>
<h3 className="font-headline-md text-[20px] text-primary mb-1">Wool Trousers</h3>
<p className="font-label-sm text-label-sm text-on-surface-variant uppercase">Pants</p>
</div>
<span className="font-body-md text-body-md text-primary">$120.00</span>
</div>
<div className="mt-auto pt-6 flex justify-between items-center">
<button className="bg-primary text-on-primary px-6 py-2 rounded-full font-body-md text-sm flex items-center gap-2 hover:bg-inverse-surface transition-colors">
                            MOVE TO CART <span className="">→</span>
</button>
<button className="text-outline hover:text-error transition-colors p-2">
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1","color": "#000000"}}>close</span>
</button>
</div>
</div>
</div>

<div className="bg-surface-container-lowest rounded-24 overflow-hidden shadow-ambient hover-lift group relative flex flex-col">
<button className="absolute top-4 right-4 z-10 w-10 h-10 bg-surface-container-lowest rounded-full flex items-center justify-center shadow-sm text-primary hover:scale-110 transition-transform">
<span className="material-symbols-outlined text-[20px]" style={{"fontVariationSettings": "\'FILL\' 1","color": "#000000"}}>favorite</span>
</button>
<div className="relative w-full aspect-[4/5] overflow-hidden bg-surface-container-low">
<img className="w-full h-full object-cover img-zoom" data-alt="A stylish flat-lay of a fine-gauge knit polo shirt in a muted sage green color, placed on a pristine white marble surface. Next to it are a pair of vintage sunglasses. The lighting is crisp and modern, creating a refined, affluent menswear vibe." src="https://lh3.googleusercontent.com/aida-public/AB6AXuBZAJLwJd4p2ZsrrNcedaLKSL_fMNgbSmptTp9P5otmxqzAwxZ3LL3GQLAYZPgqz36kAPOWLy4E-ubRKiIj2PJ5EORD2XCn9aBJrdZsCuoCuVtLidpLNq4wU26dp5KYAQlaop9VDgCVPpepqh6Ea3AK6uR5I10ELvuIE68ThD2-eiO-VTrs33DzyFeCdqx-vUQrso1IAKR4khjDb8BrfAhTiaXHq7i3SehE07-TmcERI4mGRG_CQNqM9w" />
</div>
<div className="p-6 flex flex-col flex-grow">
<div className="flex justify-between items-start mb-2">
<div>
<h3 className="font-headline-md text-[20px] text-primary mb-1">Knit Polo</h3>
<p className="font-label-sm text-label-sm text-on-surface-variant uppercase">Knitwear</p>
</div>
<span className="font-body-md text-body-md text-primary">$75.00</span>
</div>
<div className="mt-auto pt-6 flex justify-between items-center">
<button className="bg-primary text-on-primary px-6 py-2 rounded-full font-body-md text-sm flex items-center gap-2 hover:bg-inverse-surface transition-colors">
                            MOVE TO CART <span className="">→</span>
</button>
<button className="text-outline hover:text-error transition-colors p-2">
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1","color": "#000000"}}>close</span>
</button>
</div>
</div>
</div>

<div className="bg-surface-container-lowest rounded-24 overflow-hidden shadow-ambient hover-lift group relative flex flex-col">
<button className="absolute top-4 right-4 z-10 w-10 h-10 bg-surface-container-lowest rounded-full flex items-center justify-center shadow-sm text-primary hover:scale-110 transition-transform">
<span className="material-symbols-outlined text-[20px]" style={{"fontVariationSettings": "\'FILL\' 1","color": "#000000"}}>favorite</span>
</button>
<div className="absolute top-4 left-4 z-10 bg-lavender-white text-primary px-3 py-1 rounded-full font-label-sm text-label-sm uppercase">
                    Sale
                </div>
<div className="relative w-full aspect-[4/5] overflow-hidden bg-surface-container-low">
<img className="w-full h-full object-cover img-zoom" data-alt="A sophisticated male model walking through an abstract, minimalist, light-filled architectural space wearing a timeless camel-colored Classic Overcoat over a monochrome outfit. The scene embodies high-end luxury fashion photography with strong compositional lines and soft, airy atmosphere." src="https://lh3.googleusercontent.com/aida-public/AB6AXuAg3BFbhKA8rWOATI8-Xo7BLrzDM1Ji7uq-1TWj6Q6Iaz0kjlESnpbAk6JbQ_U2Z7oMqQo_EchqhDT3sEIY67zJ-N2XjGA5d147VdYzwpvo2KW7nwGfpB6ZDFirIHx50H_Co3hsnz_N8zpPgkHtjMUsnlqF70c7mm4j2aLr7u5RVedaHocugPyg7zEddemuvq_7PRqPneXQI9mDxT7cUMdcV24yXnsdf8qMRqdOWXeaDLCj48kh799oEg" />
</div>
<div className="p-6 flex flex-col flex-grow">
<div className="flex justify-between items-start mb-2">
<div>
<h3 className="font-headline-md text-[20px] text-primary mb-1">Classic Overcoat</h3>
<p className="font-label-sm text-label-sm text-on-surface-variant uppercase">Outerwear</p>
</div>
<div className="flex flex-col items-end"><span className="font-body-md text-body-md" style={{"color": "#141414"}}>$240.00</span>
<span className="font-body-md text-sm line-through" style={{"color": "#8FB0A4"}}>$320.00</span></div>
</div>
<div className="mt-auto pt-6 flex justify-between items-center">
<button className="bg-primary text-on-primary px-6 py-2 rounded-full font-body-md text-sm flex items-center gap-2 hover:bg-inverse-surface transition-colors">
                            MOVE TO CART <span className="">→</span>
</button>
<button className="text-outline hover:text-error transition-colors p-2">
<span className="material-symbols-outlined" style={{"fontVariationSettings": "\'FILL\' 1","color": "#000000"}}>close</span>
</button>
</div>
</div>
</div>
</div>
</main>
  );
}