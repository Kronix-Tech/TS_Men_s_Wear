import CartIcon from "@/components/CartIcon";
import type { Metadata } from "next";
import { Inter, Italiana } from "next/font/google";
import "./globals.css";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
});

const italiana = Italiana({
  variable: "--font-italiana",
  weight: "400",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "UIXSHUVO - Fashion",
  description: "Minimalist Men's Wear",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <head>
        <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet" />
      </head>
      <body className={`${inter.variable} ${italiana.variable} font-body-md text-body-md selection:bg-brand-sage selection:text-white flex flex-col min-h-screen`}>
        {/* TopNavBar */}
        <header className="bg-surface dark:bg-surface sticky top-0 z-50 px-margin-desktop py-unit max-w-container-max mx-auto bg-surface/90 backdrop-blur-md transition-all duration-300 ease-in-out w-full">
          <div className="grid grid-cols-12 items-center w-full">
            <nav className="col-span-5 flex items-center gap-6">
              <a className="text-on-surface-variant hover:text-primary transition-colors font-body-md text-label-sm uppercase tracking-widest" href="#">New Arrivals</a>
              <a className="text-on-surface-variant hover:text-primary transition-colors font-body-md text-label-sm uppercase tracking-widest" href="#">Shop All</a>
              <a className="text-on-surface-variant hover:text-primary transition-colors font-body-md text-label-sm uppercase tracking-widest" href="#">Collections</a>
              <a className="text-on-surface-variant hover:text-primary transition-colors font-body-md text-label-sm uppercase tracking-widest" href="#">Blog</a>
              <a className="text-on-surface-variant hover:text-primary transition-colors font-body-md text-label-sm uppercase tracking-widest" href="#">Contact</a>
            </nav>
            <div className="col-span-2 flex justify-center">
              <a className="font-display-lg text-headline-lg text-primary dark:text-on-primary tracking-tighter hover:opacity-70 transition-opacity duration-300" href="#">MEN'S WEAR</a>
            </div>
            <div className="col-span-5 flex items-center justify-end gap-6 text-primary dark:text-on-primary">
              <button className="hover:opacity-70 transition-opacity duration-300"><span className="material-symbols-outlined">search</span></button>
              <a className="hover:opacity-70 transition-opacity duration-300" href="#"><span className="material-symbols-outlined">favorite</span></a>
              <CartIcon />
              <a className="hover:opacity-70 transition-opacity duration-300" href="#"><span className="material-symbols-outlined">person</span></a>
            </div>
          </div>
        </header>
        
        {children}

        {/* Newsletter & Footer */}
        <footer className="w-full px-margin-desktop pt-stack-lg pb-12 flex flex-col gap-12 max-w-container-max mx-auto bg-brand-lilac/30 rounded-t-[3rem] mt-auto">
          {/* Newsletter Band inside footer */}
          <div className="flex flex-col md:flex-row justify-between items-center bg-white p-8 md:p-12 rounded-[2rem] editorial-shadow mb-8">
            <div className="mb-6 md:mb-0 max-w-md text-center md:text-left">
              <h3 className="font-display-lg text-headline-md uppercase tracking-widest text-brand-ink mb-2">Join the Club</h3>
              <p className="font-body-md text-on-surface-variant">Sign up for early access to new arrivals, sales, and exclusive content.</p>
            </div>
            <div className="w-full md:w-auto flex flex-col sm:flex-row gap-4">
              <input className="px-6 py-4 rounded-full border border-surface-variant bg-surface w-full sm:w-80 font-body-md focus:outline-none focus:border-brand-sage" placeholder="Enter your email address" type="email" />
              <button className="px-8 py-4 bg-brand-ink text-white rounded-full font-bold hover:bg-brand-ink/80 transition-colors uppercase tracking-widest text-sm whitespace-nowrap">
                Subscribe
              </button>
            </div>
          </div>
          {/* 4 Column Footer */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12 lg:gap-8">
            <div className="lg:col-span-2 flex flex-col gap-6">
              <a className="font-display-lg text-headline-lg text-primary uppercase" href="#">MEN'S WEAR</a>
              <p className="font-body-md text-on-surface-variant max-w-sm">Curated fashion for the modern individual. Elevate your everyday style with our premium collections.</p>
              <div className="flex gap-4 mt-2">
                <a className="w-10 h-10 bg-white rounded-full flex items-center justify-center hover:bg-brand-ink hover:text-white transition-colors editorial-shadow text-brand-ink" href="#">
                  <span className="material-symbols-outlined text-sm">share</span>
                </a>
                <a className="w-10 h-10 bg-white rounded-full flex items-center justify-center hover:bg-brand-ink hover:text-white transition-colors editorial-shadow text-brand-ink" href="mailto:support@menswear.com">
                  <span className="material-symbols-outlined text-sm">mail</span>
                </a>
                <a className="w-10 h-10 bg-white rounded-full flex items-center justify-center hover:bg-brand-ink hover:text-white transition-colors editorial-shadow text-brand-ink" href="#">
                  <span className="material-symbols-outlined text-sm">link</span>
                </a>
              </div>
            </div>
            <div className="flex flex-col gap-4">
              <h4 className="font-display-lg text-body-lg uppercase tracking-widest font-bold text-brand-ink mb-2">Shop</h4>
              <a className="font-body-md text-on-surface-variant hover:text-primary transition-colors duration-200" href="#">New Arrivals</a>
              <a className="font-body-md text-on-surface-variant hover:text-primary transition-colors duration-200" href="#">Best Sellers</a>
              <a className="font-body-md text-on-surface-variant hover:text-primary transition-colors duration-200" href="#">Clothing</a>
              <a className="font-body-md text-on-surface-variant hover:text-primary transition-colors duration-200" href="#">Accessories</a>
            </div>
            <div className="flex flex-col gap-4">
              <h4 className="font-display-lg text-body-lg uppercase tracking-widest font-bold text-brand-ink mb-2">Company</h4>
              <a className="font-body-md text-on-surface-variant hover:text-primary transition-colors duration-200" href="#">About Us</a>
              <a className="font-body-md text-on-surface-variant hover:text-primary transition-colors duration-200" href="#">Careers</a>
              <a className="font-body-md text-on-surface-variant hover:text-primary transition-colors duration-200" href="#">Stores</a>
              <a className="font-body-md text-on-surface-variant hover:text-primary transition-colors duration-200" href="#">Journal</a>
            </div>
            <div className="flex flex-col gap-4">
              <h4 className="font-display-lg text-body-lg uppercase tracking-widest font-bold text-brand-ink mb-2">Help &amp; Legal</h4>
              <a className="font-body-md text-on-surface-variant hover:text-primary transition-colors duration-200" href="#">Contact Us</a>
              <a className="font-body-md text-on-surface-variant hover:text-primary transition-colors duration-200" href="#">Shipping &amp; Returns</a>
              <a className="font-body-md text-on-surface-variant hover:text-primary transition-colors duration-200" href="#">Privacy Policy</a>
              <a className="font-body-md text-on-surface-variant hover:text-primary transition-colors duration-200" href="#">Terms of Service</a>
            </div>
          </div>
          <div className="text-center font-body-md text-body-md text-on-surface-variant pt-8 border-t border-surface-variant/50 mt-4">© 2026 MEN'S WEAR. All rights reserved.</div>
        </footer>
      </body>
    </html>
  );
}
