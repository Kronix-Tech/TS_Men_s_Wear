export default function UixshuvoRefined404ErrorPageBrandAligned() {
  return (
    <main className="flex-grow relative flex items-center justify-center py-stack-lg px-margin-mobile md:px-margin-desktop w-full max-w-container-max mx-auto overflow-hidden">

<div className="absolute top-10 left-[-5%] md:left-[5%] lg:left-[15%] w-48 md:w-64 rotate-[-6deg] z-0 opacity-40 hover:opacity-80 transition-opacity duration-500 hidden sm:block">
<div className="bg-surface-container-lowest p-3 pb-8 rounded-lg polaroid">
<img alt="White Shirt" className="w-full h-auto object-cover rounded-sm aspect-square bg-surface-variant" src="https://lh3.googleusercontent.com/aida/AP1WRLtfdaW2daAoiyD_rytcUgGPIncw_CCQbkBGulvFxl5SMVxsY_HhyHQiza1LChOz91SOaEEHERaf9Qh-3QzuQGE5b6ubl8zVuqcvvLI0uxMI7DEmghRKkQj_q0sb6-yM_DJ9E0muZ5JemdBzJGeQJ7Z46KC_y6FrYN6jES5BEnpU0W55y7OutXNLkoAarPKdAGBq4RrqaqWujrLijy90tUMWOFkpj4yT9Nz3ItWACd22ATVRowgaTQhu7OHv" />
</div>
</div>

<div className="absolute bottom-10 right-[-5%] md:right-[5%] lg:right-[15%] w-48 md:w-64 rotate-[8deg] z-0 opacity-40 hover:opacity-80 transition-opacity duration-500 hidden sm:block">
<div className="bg-surface-container-lowest p-3 pb-8 rounded-lg polaroid">
<img alt="Denim Jeans" className="w-full h-auto object-cover rounded-sm aspect-square bg-surface-variant" src="https://lh3.googleusercontent.com/aida/AP1WRLusg0K3F_ypapeR-272hJjPMps24n77A4kcPO74u-PepPjQP4xrArAaPmx4HXF98zzF5aAmM4D8qoeN8BcnDKlMvYdJesslyusGwmRzHS2_FOKrlg15n79XDPqmRW-NwZ1653jIjsfJlU6zJANjLCafr_Qn9maNoxpNsi69yRpxdOB2cfe0am1n-TCXVZvvZl9fsxf9zZr0_wIiK0k4DEXruFKixWhYViVDldPeG2GGbsOc2Ag1mm-peK1b" />
</div>
</div>

<div className="absolute top-20 right-[-10%] md:right-[2%] lg:right-[5%] w-40 md:w-56 rotate-[12deg] z-0 opacity-30 hover:opacity-70 transition-opacity duration-500 hidden lg:block">
<div className="bg-surface-container-lowest p-3 pb-8 rounded-lg polaroid">
<img alt="Camel Overcoat" className="w-full h-auto object-cover rounded-sm aspect-[3/4] bg-surface-variant object-top" src="https://lh3.googleusercontent.com/aida/AP1WRLu_Ohz_aNHT2GXRUXPCNc0ta_04CMe6Lwf4sAhWZLi-hJI7PShlBj7_TZtmJ2Q1URuiASLsCQeTaa9tYXdUGp09feW_ayBNlBjwoYPwMSL3Bt6tJSEDL8Zbwxf5j5EP702176l6J5hDMLAZVjvDhC8mbqUxZgnn2TxjvyXVQx5Ff9svUgbPu2_eOTdNtsVLigh7ndmzQjmkQTYLM_wAkCOteV-R0zDChJ9cJbCytsUjIrCQwxXc86wsVwrK" />
</div>
</div>

<div className="relative z-10 text-center max-w-2xl mx-auto flex flex-col items-center glass-panel p-8 md:p-16 rounded-[32px]">

<div className="relative inline-block mb-6">
<h1 className="font-display-lg text-display-lg text-[120px] md:text-[180px] leading-none text-primary font-bold tracking-tighter">
                    404
                </h1>

<div className="absolute bottom-4 md:bottom-8 right-[-10px] md:right-[-20px] w-6 h-6 md:w-8 md:h-8 rounded-full bg-[#8FB0A4]"></div>
</div>

<h2 className="font-headline-md text-headline-md md:font-headline-lg md:text-headline-lg text-primary mb-4 font-medium uppercase tracking-widest">
                This Page Seems To Be Missing
            </h2>

<p className="font-body-lg text-body-lg text-on-surface-variant mb-12 max-w-md">
                The style you're looking for isn't here, but plenty more is waiting to be discovered.
            </p>

<div className="flex flex-col sm:flex-row gap-4 mb-12 w-full justify-center">

<a className="inline-flex items-center justify-center px-8 py-4 bg-[#141414] text-white rounded-full font-body-md text-body-md font-medium hover:bg-surface-tint transition-colors group" href="/">
                    BACK TO HOME 
                    <span className="ml-2 transform group-hover:translate-x-1 transition-transform">→</span>
</a>

<a className="inline-flex items-center justify-center px-8 py-4 bg-transparent border border-[#141414] text-primary rounded-full font-body-md text-body-md font-medium hover:bg-surface-variant transition-colors" href="/new">
                    SHOP NEW ARRIVALS
                </a>
</div>

<div className="w-full max-w-md relative">
<span className="absolute inset-y-0 left-4 flex items-center text-outline">
<span className="material-symbols-outlined text-[20px]">search</span>
</span>
<input className="w-full pl-12 pr-4 py-4 bg-[#E7E5EE] border-none rounded-full font-body-md text-body-md text-on-surface placeholder-on-surface-variant focus:ring-2 focus:ring-primary outline-none transition-shadow" placeholder="Search for products, collections..." type="text" />
</div>
</div>
</main>
  );
}