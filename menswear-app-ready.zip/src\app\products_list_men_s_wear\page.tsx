export default function ProductsListMenSWear() {
  return (
    <main className="flex-1 ml-0 md:ml-[240px] flex flex-col min-h-screen">

<header className="docked full-width top-0 bg-background z-10 sticky top-0 bg-opacity-90 backdrop-blur-md">
<div className="flex justify-between items-center px-margin-mobile md:px-margin-desktop py-md w-full h-[72px]"><button className="md:hidden p-2 text-on-surface-variant hover:bg-surface-container rounded-full transition-colors"><span className="material-symbols-outlined">menu</span></button><div className="hidden md:flex flex-1"><div className="relative w-full max-w-md ml-auto mr-4"><span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-muted-text text-[20px]">search</span><input type="text" placeholder="Search..." className="w-full bg-surface-container-low border border-transparent rounded-full pl-10 pr-4 py-2 text-body-sm focus:outline-none focus:border-sage-accent transition-colors" /></div></div><div className="flex items-center gap-2"><button className="p-2 text-on-surface-variant hover:bg-surface-container rounded-full transition-colors relative"><span className="material-symbols-outlined">notifications</span><span className="absolute top-2 right-2 w-2 h-2 bg-error rounded-full"></span></button><button className="p-2 text-on-surface-variant hover:bg-surface-container rounded-full transition-colors"><span className="material-symbols-outlined">account_circle</span></button></div></div>
</header>

<div className="px-margin-mobile md:px-margin-desktop py-xl flex-1 max-w-container-max mx-auto w-full">

<div className="flex flex-col sm:flex-row sm:items-center justify-between mb-xxl gap-6">
<div>
<h2 className="font-headline-lg text-headline-lg text-ink tracking-tight mb-2">PRODUCTS</h2>
<p className="font-body-md text-body-md text-muted-text">Manage your inventory, pricing, and product details.</p>
</div>
<button className="bg-ink text-surface-container-lowest font-label-lg text-label-lg rounded-full px-8 py-3 h-[48px] inline-flex items-center justify-center gap-2 hover:bg-opacity-90 transition-all hover:shadow-[0px_4px_20px_rgba(20,20,20,0.08)]">
                    ADD PRODUCT <span className="material-symbols-outlined text-[18px]">arrow_forward</span>
</button>
</div>

<div className="flex flex-col md:flex-row gap-4 mb-lg">
<div className="relative flex-1 max-w-md">
<span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-muted-text">search</span>
<input className="w-full bg-surface-container-lowest border border-outline-variant/30 rounded-lg pl-12 pr-4 py-3 font-body-sm text-body-sm focus:outline-none focus:border-sage-accent focus:ring-1 focus:ring-sage-accent transition-colors placeholder:text-muted-text" placeholder="Search by name or SKU" type="text" />
</div>
<div className="flex gap-4 flex-wrap">
<div className="relative">
<select className="appearance-none bg-surface-container-lowest border border-outline-variant/30 rounded-lg pl-4 pr-10 py-3 font-body-sm text-body-sm focus:outline-none focus:border-sage-accent focus:ring-1 focus:ring-sage-accent transition-colors cursor-pointer min-w-[140px]">
<option value="">Category</option>
<option value="denim">Denim</option>
<option value="knitwear">Knitwear</option>
<option value="shirting">Shirting</option>
<option value="outerwear">Outerwear</option>
<option value="tailoring">Tailoring</option>
</select>
<span className="material-symbols-outlined absolute right-3 top-1/2 -translate-y-1/2 text-muted-text pointer-events-none text-[20px]">expand_more</span>
</div>
<div className="relative">
<select className="appearance-none bg-surface-container-lowest border border-outline-variant/30 rounded-lg pl-4 pr-10 py-3 font-body-sm text-body-sm focus:outline-none focus:border-sage-accent focus:ring-1 focus:ring-sage-accent transition-colors cursor-pointer min-w-[140px]">
<option value="">Status</option>
<option value="active">Active</option>
<option value="draft">Draft</option>
</select>
<span className="material-symbols-outlined absolute right-3 top-1/2 -translate-y-1/2 text-muted-text pointer-events-none text-[20px]">expand_more</span>
</div>
<div className="relative">
<select className="appearance-none bg-surface-container-lowest border border-outline-variant/30 rounded-lg pl-4 pr-10 py-3 font-body-sm text-body-sm focus:outline-none focus:border-sage-accent focus:ring-1 focus:ring-sage-accent transition-colors cursor-pointer min-w-[140px]">
<option value="">Stock</option>
<option value="in_stock">In Stock</option>
<option value="low_stock">Low Stock</option>
<option value="out_of_stock">Out of Stock</option>
</select>
<span className="material-symbols-outlined absolute right-3 top-1/2 -translate-y-1/2 text-muted-text pointer-events-none text-[20px]">expand_more</span>
</div>
</div>
</div>

<div className="bg-surface-container-lowest rounded-[24px] overflow-hidden mb-lg">
<div className="overflow-x-auto custom-scrollbar">
<table className="w-full text-left border-collapse min-w-[1000px]">
<thead>
<tr className="border-b border-ink/5">
<th className="py-4 pl-lg pr-4 w-12"><input aria-label="Select all products" type="checkbox" /></th>
<th className="py-4 px-4 font-label-lg text-label-lg text-muted-text uppercase tracking-wider font-normal">Product</th>
<th className="py-4 px-4 font-label-lg text-label-lg text-muted-text uppercase tracking-wider font-normal">SKU</th>
<th className="py-4 px-4 font-label-lg text-label-lg text-muted-text uppercase tracking-wider font-normal">Category</th>
<th className="py-4 px-4 font-label-lg text-label-lg text-muted-text uppercase tracking-wider font-normal">Price</th>
<th className="py-4 px-4 font-label-lg text-label-lg text-muted-text uppercase tracking-wider font-normal">Stock</th>
<th className="py-4 px-4 font-label-lg text-label-lg text-muted-text uppercase tracking-wider font-normal">Status</th>
<th className="py-4 pr-lg pl-4 font-label-lg text-label-lg text-muted-text uppercase tracking-wider font-normal text-right">Actions</th>
</tr>
</thead>
<tbody className="divide-y divide-ink/5">

<tr className="hover:bg-surface-container-low transition-colors group cursor-pointer">
<td className="py-4 pl-lg pr-4"><input aria-label="Select Selvedge Jeans" type="checkbox" /></td>
<td className="py-4 px-4">
<div className="flex items-center gap-4">
<div className="w-12 h-16 bg-surface-container-high rounded border border-ink/5 overflow-hidden flex-shrink-0">
<img className="w-full h-full object-cover" data-alt="A meticulously folded pair of dark indigo raw selvedge denim jeans resting on a clean white surface. The lighting is studio quality, highlighting the texture of the heavyweight denim and the subtle contrast stitching. Minimalist, premium e-commerce product photography style. High resolution." src="https://lh3.googleusercontent.com/aida-public/AB6AXuCDENdHNnz6Cbr5eSUOjROBoUnIV0CVf-QxWlQkwsOfvoe0byeGhx19VmYBotr9rMush0A3vwFBpdHDv7mg20B467zB38cwkfrfR4CsBJM9ldU0xZnIQcfhLE2AyaqzF6hoeiaGJvjj1GtTqQVRL0qwZhmnNKQb89E1HtvP0JTWZdxSjJa5dLItTZtu4xuZHfngqvQ2qMzLut4L_rAuUuOYPs-G729ChkkUgOLI-yseYFrB4IJszv48" />
</div>
<span className="font-body-md text-body-md text-ink font-medium">Selvedge Jeans</span>
</div>
</td>
<td className="py-4 px-4 font-body-sm text-body-sm text-muted-text">DNM-001</td>
<td className="py-4 px-4 font-body-sm text-body-sm text-muted-text">Jeans</td>
<td className="py-4 px-4 font-body-md text-body-md text-ink">$185.00</td>
<td className="py-4 px-4">
<div className="flex items-center gap-2 mb-1">
<span className="font-body-md text-body-md font-medium">42</span>
<span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-secondary-container text-on-secondary-container uppercase tracking-wide">In Stock</span>
</div>
</td>
<td className="py-4 px-4">
<span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-lavender-white text-ink border border-ink/10">Active</span>
</td>
<td className="py-4 pr-lg pl-4 text-right group-hover:opacity-100 transition-opacity"><div className="flex items-center justify-end gap-2"><button className="p-2 hover:bg-surface-variant/20 rounded-full text-on-surface-variant transition-colors" title="Edit"><span className="material-symbols-outlined text-[18px]">edit</span></button><button className="p-2 hover:bg-surface-variant/20 rounded-full text-on-surface-variant transition-colors" title="Duplicate"><span className="material-symbols-outlined text-[18px]">content_copy</span></button><button className="p-2 hover:bg-error/10 text-error transition-colors" title="Delete"><span className="material-symbols-outlined text-[18px]">delete</span></button></div></td>
</tr>

<tr className="hover:bg-surface-container-low transition-colors group cursor-pointer bg-surface-container-low/30">
<td className="py-4 pl-lg pr-4"><input aria-label="Select Merino Wool Sweater" type="checkbox" /></td>
<td className="py-4 px-4">
<div className="flex items-center gap-4">
<div className="w-12 h-16 bg-surface-container-high rounded border border-ink/5 overflow-hidden flex-shrink-0">
<img className="w-full h-full object-cover" data-alt="A fine gauge merino wool crewneck sweater in a soft heather grey color, neatly folded flat. The soft natural lighting emphasizes the smooth texture and drape of the knitwear. Set against a pure white, shadowless background for a premium editorial aesthetic." src="https://lh3.googleusercontent.com/aida-public/AB6AXuAGokBT9JewV5nhRTKRVoK1Fm4xwIz-R9-JhpE7Shstjb_0K5FqN0Ul96XZNJ8LH4XH-cbO1OWbBRek-OY7CfMc6BYGAxacmEywn5modOrSs_d8odi9h9GIGbscIf-1qrHQnJwxaV_nUtc1tsOt2bQmzWBBiWCrfJIUyv1bH9vjsRnEPd5KwSvYZDdwFETXfJCeYUyFBYiFzcnsbB1TRiW7bL-tF4SPQEUprYmhhDjnvbvuI41Mmnoh" />
</div>
<span className="font-body-md text-body-md text-ink font-medium">Merino Wool Sweater</span>
</div>
</td>
<td className="py-4 px-4 font-body-sm text-body-sm text-muted-text">KNT-042</td>
<td className="py-4 px-4 font-body-sm text-body-sm text-muted-text">Winter Wear</td>
<td className="py-4 px-4 font-body-md text-body-md text-ink">$145.00</td>
<td className="py-4 px-4">
<div className="flex items-center gap-2 mb-1.5">
<span className="font-body-md text-body-md font-medium text-amber-600">8</span>
<span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-amber-100 text-amber-800 uppercase tracking-wide">Low</span>
</div>
<div className="flex gap-2 text-[11px] text-muted-text font-mono">
<span className="">S:2</span> <span className="text-error font-medium">M:0</span> <span className="">L:6</span>
</div>
</td>
<td className="py-4 px-4">
<span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-lavender-white text-ink border border-ink/10">Active</span>
</td>
<td className="py-4 pr-lg pl-4 text-right group-hover:opacity-100 transition-opacity"><div className="flex items-center justify-end gap-2"><button className="p-2 hover:bg-surface-variant/20 rounded-full text-on-surface-variant transition-colors" title="Edit"><span className="material-symbols-outlined text-[18px]">edit</span></button><button className="p-2 hover:bg-surface-variant/20 rounded-full text-on-surface-variant transition-colors" title="Duplicate"><span className="material-symbols-outlined text-[18px]">content_copy</span></button><button className="p-2 hover:bg-error/10 text-error transition-colors" title="Delete"><span className="material-symbols-outlined text-[18px]">delete</span></button></div></td>
</tr>

<tr className="hover:bg-surface-container-low transition-colors group cursor-pointer">
<td className="py-4 pl-lg pr-4"><input aria-label="Select Oxford Cotton Shirt" type="checkbox" /></td>
<td className="py-4 px-4">
<div className="flex items-center gap-4">
<div className="w-12 h-16 bg-surface-container-high rounded border border-ink/5 overflow-hidden flex-shrink-0">
<img className="w-full h-full object-cover" data-alt="A crisp, classic light blue Oxford cotton button-down shirt. The collar is perfectly rolled, and the textured weave of the fabric is visible. Clean, flat-lay photography on a sterile white background to evoke a sense of quiet luxury and timeless menswear." src="https://lh3.googleusercontent.com/aida-public/AB6AXuD9Qbk-vR2e1iwEsitEJnXEq9cM2QQA_L1XC-ecjEZqs9c8hNT5oh70MgDITyM2b6WECMbyK-KVxKUskuYW_O53ELJyADYUOK8Y1sIkSeQqf55QtzyChmMBqbR8sJjjnFk4So8UAj4JrsBWzwQCDqqoW9qsyXDjFX7gN8suif2Dy7blNJNrjmEhzE0vpDEeCnHtBqKfRWr5AtLypmnppma-fPU4FuL5O4PmltpY-wmcnPbhHcekM-kZ" />
</div>
<span className="font-body-md text-body-md text-ink font-medium">Oxford Cotton Shirt</span>
</div>
</td>
<td className="py-4 px-4 font-body-sm text-body-sm text-muted-text">SHT-018</td>
<td className="py-4 px-4 font-body-sm text-body-sm text-muted-text">Shirts</td>
<td className="py-4 px-4 font-body-md text-body-md text-ink">$95.00</td>
<td className="py-4 px-4">
<div className="flex items-center gap-2">
<span className="font-body-md text-body-md font-medium">65</span>
<span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-secondary-container text-on-secondary-container uppercase tracking-wide">In Stock</span>
</div>
</td>
<td className="py-4 px-4">
<span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-lavender-white text-ink border border-ink/10">Active</span>
</td>
<td className="py-4 pr-lg pl-4 text-right group-hover:opacity-100 transition-opacity"><div className="flex items-center justify-end gap-2"><button className="p-2 hover:bg-surface-variant/20 rounded-full text-on-surface-variant transition-colors" title="Edit"><span className="material-symbols-outlined text-[18px]">edit</span></button><button className="p-2 hover:bg-surface-variant/20 rounded-full text-on-surface-variant transition-colors" title="Duplicate"><span className="material-symbols-outlined text-[18px]">content_copy</span></button><button className="p-2 hover:bg-error/10 text-error transition-colors" title="Delete"><span className="material-symbols-outlined text-[18px]">delete</span></button></div></td>
</tr>

<tr className="hover:bg-surface-container-low transition-colors group cursor-pointer opacity-70">
<td className="py-4 pl-lg pr-4"><input aria-label="Select Tailored Trousers" type="checkbox" /></td>
<td className="py-4 px-4">
<div className="flex items-center gap-4">
<div className="w-12 h-16 bg-surface-container-high rounded border border-ink/5 overflow-hidden flex-shrink-0">
<img className="w-full h-full object-cover grayscale" data-alt="A pair of impeccably tailored charcoal grey wool trousers, displaying sharp front creases. The garment is laid out symmetrically against a bright white backdrop. The mood is sophisticated and minimal, emphasizing the drape and quality of the suiting fabric." src="https://lh3.googleusercontent.com/aida-public/AB6AXuBMbPIkDUCcYuzFivxByMBBI1NyT-tWpu6BL74-s_MfVAB-UAouuEb2FUNhMDhOo_Vv2AIZRwL88rxq99tpNpsaY1dpiFSLmpEyKdjdfIXdU3y1SkDKGKhc0Rhr4nEJtxFoP70pJuNMc9Nug2QqaT0jD8d18HjJe6HZTgn00dzNt1J3iKn5ODDzsR5ebAcp-vEuO2l8mwJzSZTOTbfBZ5yMzwZF4m0aEa74stw2-5oRwEOGgbgBo2yH" />
</div>
<span className="font-body-md text-body-md text-ink font-medium">Tailored Trousers</span>
</div>
</td>
<td className="py-4 px-4 font-body-sm text-body-sm text-muted-text">TR-004</td>
<td className="py-4 px-4 font-body-sm text-body-sm text-muted-text">Trousers</td>
<td className="py-4 px-4 font-body-md text-body-md text-ink">$210.00</td>
<td className="py-4 px-4">
<div className="flex items-center gap-2">
<span className="font-body-md text-body-md font-medium text-error">0</span>
<span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-surface-dim text-on-surface-variant uppercase tracking-wide">Out</span>
</div>
</td>
<td className="py-4 px-4">
<span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-surface-dim text-on-surface-variant border border-transparent">Draft</span>
</td>
<td className="py-4 pr-lg pl-4 text-right group-hover:opacity-100 transition-opacity"><div className="flex items-center justify-end gap-2"><button className="p-2 hover:bg-surface-variant/20 rounded-full text-on-surface-variant transition-colors" title="Edit"><span className="material-symbols-outlined text-[18px]">edit</span></button><button className="p-2 hover:bg-surface-variant/20 rounded-full text-on-surface-variant transition-colors" title="Duplicate"><span className="material-symbols-outlined text-[18px]">content_copy</span></button><button className="p-2 hover:bg-error/10 text-error transition-colors" title="Delete"><span className="material-symbols-outlined text-[18px]">delete</span></button></div></td>
</tr>

<tr className="hover:bg-surface-container-low transition-colors group cursor-pointer">
<td className="py-4 pl-lg pr-4"><input aria-label="Select Cashmere Overcoat" type="checkbox" /></td>
<td className="py-4 px-4">
<div className="flex items-center gap-4">
<div className="w-12 h-16 bg-surface-container-high rounded border border-ink/5 overflow-hidden flex-shrink-0">
<img className="w-full h-full object-cover" data-alt="A luxurious camel-colored cashmere overcoat for men. The coat is shown open slightly to reveal the smooth lining, laid flat against a pristine white studio background. The lighting is soft and diffused, highlighting the rich, plush texture of the premium cashmere fabric. Elegant and timeless." src="https://lh3.googleusercontent.com/aida-public/AB6AXuD1g1QY7t4vn56xXZnrgXRO883zu8SN-fp8E23e0c0svLTx4N1ZAHxkfNSga3Uhk4JHF7xfg_-OI8rF1EYp5jClqpkpXxAXeZgxTeugV1pVpbaqmP3nvrIgHE-SKxFqdGKvF0EaAFc8-lNu9YuE-2qzGU1ofGOXc-FtoXZoeadGF9hZ7NxUb43SOrqqqTfQl3XkBpTpVDhgsmPXpQBMTjjD95KaQom9mIKO7M-Pkjauy_z__qXheWQo" />
</div>
<span className="font-body-md text-body-md text-ink font-medium">Cashmere Overcoat</span>
</div>
</td>
<td className="py-4 px-4 font-body-sm text-body-sm text-muted-text">OW-099</td>
<td className="py-4 px-4 font-body-sm text-body-sm text-muted-text">Winter Wear</td>
<td className="py-4 px-4 font-body-md text-body-md text-ink">$850.00</td>
<td className="py-4 px-4">
<div className="flex items-center gap-2">
<span className="font-body-md text-body-md font-medium">12</span>
<span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-secondary-container text-on-secondary-container uppercase tracking-wide">In Stock</span>
</div>
</td>
<td className="py-4 px-4">
<span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-lavender-white text-ink border border-ink/10">Active</span>
</td>
<td className="py-4 pr-lg pl-4 text-right group-hover:opacity-100 transition-opacity"><div className="flex items-center justify-end gap-2"><button className="p-2 hover:bg-surface-variant/20 rounded-full text-on-surface-variant transition-colors" title="Edit"><span className="material-symbols-outlined text-[18px]">edit</span></button><button className="p-2 hover:bg-surface-variant/20 rounded-full text-on-surface-variant transition-colors" title="Duplicate"><span className="material-symbols-outlined text-[18px]">content_copy</span></button><button className="p-2 hover:bg-error/10 text-error transition-colors" title="Delete"><span className="material-symbols-outlined text-[18px]">delete</span></button></div></td>
</tr>

<tr className="hover:bg-surface-container-low transition-colors group cursor-pointer">
<td className="py-4 pl-lg pr-4"><input aria-label="Select Linen Blend Blazer" type="checkbox" /></td>
<td className="py-4 px-4">
<div className="flex items-center gap-4">
<div className="w-12 h-16 bg-surface-container-high rounded border border-ink/5 overflow-hidden flex-shrink-0">
<img className="w-full h-full object-cover" data-alt="An unstructured, single-breasted men's blazer made of a beige linen blend. The garment is photographed in a minimalist style against a white background, allowing the natural slub texture of the linen to be visible. The aesthetic is relaxed but refined, perfect for spring/summer tailoring." src="https://lh3.googleusercontent.com/aida-public/AB6AXuDnj58FLdhEDUCR45DCpVg1joUrmT0Q5pTDvziALEyq00CXknhH4lChoYUIZhXn2m8EnQ8DaW06kthSdeu-NzYIFgsLWAsDrr3ZsWdoWRLSB6R1Bv_cBb50zAyq8axpLD3ZIMknwZin6pEDPo7Nzs_Rm3Wnxzsv4W7rZCIoRaRsuGNG5-neBITFsWvKe4f-0-a6GaiFhaqwuDpCYjqVpzZ8FsOnlhlzw7v2QTrnqoYwGigLTSv7Ieg3" />
</div>
<span className="font-body-md text-body-md text-ink font-medium">Linen Blend Blazer</span>
</div>
</td>
<td className="py-4 px-4 font-body-sm text-body-sm text-muted-text">TR-021</td>
<td className="py-4 px-4 font-body-sm text-body-sm text-muted-text">Formal Wear</td>
<td className="py-4 px-4 font-body-md text-body-md text-ink">$340.00</td>
<td className="py-4 px-4">
<div className="flex items-center gap-2">
<span className="font-body-md text-body-md font-medium">24</span>
<span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-secondary-container text-on-secondary-container uppercase tracking-wide">In Stock</span>
</div>
</td>
<td className="py-4 px-4">
<span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-lavender-white text-ink border border-ink/10">Active</span>
</td>
<td className="py-4 pr-lg pl-4 text-right group-hover:opacity-100 transition-opacity"><div className="flex items-center justify-end gap-2"><button className="p-2 hover:bg-surface-variant/20 rounded-full text-on-surface-variant transition-colors" title="Edit"><span className="material-symbols-outlined text-[18px]">edit</span></button><button className="p-2 hover:bg-surface-variant/20 rounded-full text-on-surface-variant transition-colors" title="Duplicate"><span className="material-symbols-outlined text-[18px]">content_copy</span></button><button className="p-2 hover:bg-error/10 text-error transition-colors" title="Delete"><span className="material-symbols-outlined text-[18px]">delete</span></button></div></td>
</tr>
</tbody>
</table>
</div>
</div>

<div className="flex flex-col sm:flex-row items-center justify-between gap-4 mt-6">
<button className="border border-ink text-ink font-label-lg text-label-lg rounded-full px-6 py-2.5 hover:bg-surface-container-high transition-colors inline-flex items-center gap-2">
<span className="material-symbols-outlined text-[18px]">download</span> Export CSV
                </button>
<div className="flex items-center gap-1">
<button className="w-10 h-10 rounded-full flex items-center justify-center text-muted-text hover:bg-surface-container-high transition-colors disabled:opacity-50" disabled={true}>
<span className="material-symbols-outlined">chevron_left</span>
</button>
<button className="w-10 h-10 rounded-full flex items-center justify-center bg-ink text-surface-container-lowest font-body-sm font-medium">1</button>
<button className="w-10 h-10 rounded-full flex items-center justify-center text-ink hover:bg-surface-container-high font-body-sm transition-colors">2</button>
<button className="w-10 h-10 rounded-full flex items-center justify-center text-ink hover:bg-surface-container-high font-body-sm transition-colors">3</button>
<span className="px-1 text-muted-text">...</span>
<button className="w-10 h-10 rounded-full flex items-center justify-center text-ink hover:bg-surface-container-high font-body-sm transition-colors">12</button>
<button className="w-10 h-10 rounded-full flex items-center justify-center text-ink hover:bg-surface-container-high transition-colors">
<span className="material-symbols-outlined">chevron_right</span>
</button>
</div>
</div>
</div>
</main>
  );
}