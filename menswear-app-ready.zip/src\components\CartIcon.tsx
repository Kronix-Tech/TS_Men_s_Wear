'use client';

import { useCartStore } from '@/lib/store';
import Link from 'next/link';
import { useEffect, useState } from 'react';

export default function CartIcon() {
  const [mounted, setMounted] = useState(false);
  const totalItems = useCartStore(state => state.totalItems());

  useEffect(() => {
    setMounted(true);
  }, []);

  return (
    <Link href="/uixshuvo_refined_cart" className="relative hover:opacity-70 transition-opacity duration-300">
      <span className="material-symbols-outlined">shopping_bag</span>
      {mounted && totalItems > 0 && (
        <span className="absolute -top-1.5 -right-1.5 bg-red-500 text-white text-[10px] w-4 h-4 rounded-full flex items-center justify-center font-bold">
          {totalItems}
        </span>
      )}
    </Link>
  );
}
