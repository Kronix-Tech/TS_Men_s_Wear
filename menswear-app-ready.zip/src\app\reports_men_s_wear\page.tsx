export default function ReportsMenSWear() {
  return (
    <main className="ml-64 pt-24 px-margin-desktop pb-xxl max-w-container-max mx-auto">

<div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-xl gap-lg">
<div>
<h2 className="font-headline-lg text-headline-lg text-primary tracking-tight">REPORTS</h2>
<p className="font-body-md text-body-md text-on-surface-variant mt-sm">Comprehensive performance overview.</p>
</div>
<div className="flex items-center gap-md">
<div className="flex items-center gap-sm bg-surface-container-lowest border border-outline-variant/30 rounded-full px-md py-sm text-body-sm">
<span className="material-symbols-outlined text-[18px] text-on-surface-variant">calendar_today</span>
<span className="font-label-sm text-label-sm tracking-wide">Aug 01 – Aug 31, 2026</span>
</div>
<button className="border border-primary text-primary px-lg py-sm rounded-full font-label-sm text-label-sm uppercase tracking-wider hover:bg-surface-container-low transition-colors">
                    Export PDF
                </button>
</div>
</div>

<section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-gutter mb-xxl">

<div className="bg-surface-container-lowest rounded-[24px] p-lg card-no-shadow">
<p className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider mb-sm">Total Revenue</p>
<div className="flex items-baseline gap-sm mb-sm">
<span className="font-headline-lg text-headline-lg text-primary">$12,480</span>
<span className="text-body-sm text-[#46655a] flex items-center"><span className="material-symbols-outlined text-[14px]">trending_up</span> +8.4%</span>
</div>
</div>

<div className="bg-surface-container-lowest rounded-[24px] p-lg card-no-shadow">
<p className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider mb-sm">Total Orders</p>
<div className="flex items-baseline gap-sm mb-sm">
<span className="font-headline-lg text-headline-lg text-primary">156</span>
<span className="text-body-sm text-[#46655a] flex items-center"><span className="material-symbols-outlined text-[14px]">trending_up</span> +2.1%</span>
</div>
</div>

<div className="bg-surface-container-lowest rounded-[24px] p-lg card-no-shadow">
<p className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider mb-sm">Conversion Rate</p>
<div className="flex items-baseline gap-sm mb-sm">
<span className="font-headline-lg text-headline-lg text-primary">3.2%</span>
<span className="text-body-sm text-on-surface-variant flex items-center"><span className="material-symbols-outlined text-[14px]">trending_flat</span> 0.0%</span>
</div>
</div>

<div className="bg-surface-container-lowest rounded-[24px] p-lg card-no-shadow">
<p className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider mb-sm">Return Rate</p>
<div className="flex items-baseline gap-sm mb-sm">
<span className="font-headline-lg text-headline-lg text-primary">2.1%</span>
<span className="text-body-sm text-error flex items-center"><span className="material-symbols-outlined text-[14px]">trending_up</span> +0.4%</span>
</div>
</div>
</section>

<section className="grid grid-cols-1 lg:grid-cols-3 gap-gutter mb-xxl">

<div className="lg:col-span-2 bg-surface-container-lowest rounded-[24px] p-lg card-no-shadow flex flex-col">
<div className="flex justify-between items-center mb-xl">
<h3 className="font-headline-md text-headline-md text-primary">Monthly Revenue</h3>
<span className="material-symbols-outlined text-on-surface-variant cursor-pointer">more_horiz</span>
</div>

<div className="flex-1 flex items-end justify-between gap-sm mt-auto h-48 border-b border-outline-variant/30 pb-sm">
<div className="w-full chart-bar rounded-t-sm" style={{"height": "40%"}}></div>
<div className="w-full chart-bar-alt rounded-t-sm" style={{"height": "35%"}}></div>
<div className="w-full chart-bar rounded-t-sm" style={{"height": "60%"}}></div>
<div className="w-full chart-bar-alt rounded-t-sm" style={{"height": "50%"}}></div>
<div className="w-full chart-bar rounded-t-sm" style={{"height": "80%"}}></div>
<div className="w-full chart-bar-alt rounded-t-sm" style={{"height": "70%"}}></div>
<div className="w-full chart-bar rounded-t-sm" style={{"height": "90%"}}></div>
<div className="w-full chart-bar-alt rounded-t-sm" style={{"height": "85%"}}></div>
<div className="w-full chart-bar rounded-t-sm" style={{"height": "100%"}}></div>
<div className="w-full chart-bar-alt rounded-t-sm" style={{"height": "60%"}}></div>
<div className="w-full chart-bar rounded-t-sm" style={{"height": "75%"}}></div>
<div className="w-full chart-bar-alt rounded-t-sm" style={{"height": "95%"}}></div>
</div>
<div className="flex justify-between mt-sm text-label-sm text-on-surface-variant">
<span className="">Aug 1</span>
<span className="">Aug 15</span>
<span className="">Aug 31</span>
</div>
</div>

<div className="bg-surface-container-lowest rounded-[24px] p-lg card-no-shadow flex flex-col">
<div className="flex justify-between items-center mb-xl">
<h3 className="font-headline-md text-headline-md text-primary">Top Categories</h3>
<span className="material-symbols-outlined text-on-surface-variant cursor-pointer">more_horiz</span>
</div>

<div className="flex-1 flex flex-col items-center justify-center">
<div className="w-32 h-32 rounded-full border-[16px] border-[#8FB0A4] border-r-surface-variant border-b-surface-variant mb-xl relative">
<div className="absolute inset-0 flex items-center justify-center">
<span className="font-label-lg text-label-lg text-primary">100%</span>
</div>
</div>
<div className="w-full space-y-sm">
<div className="flex justify-between items-center text-body-sm">
<div className="flex items-center gap-sm"><span className="w-3 h-3 rounded-full bg-[#8FB0A4]"></span> Suits</div>
<span className="font-medium">45%</span>
</div>
<div className="flex justify-between items-center text-body-sm">
<div className="flex items-center gap-sm"><span className="w-3 h-3 rounded-full bg-surface-variant"></span> Shirts</div>
<span className="font-medium">35%</span>
</div>
<div className="flex justify-between items-center text-body-sm">
<div className="flex items-center gap-sm"><span className="w-3 h-3 rounded-full border border-outline-variant/50"></span> Denim</div>
<span className="font-medium">20%</span>
</div>
</div>
</div>
</div>
</section>

<section className="grid grid-cols-1 lg:grid-cols-2 gap-gutter">

<div className="bg-surface-container-lowest rounded-[24px] p-lg card-no-shadow flex flex-col">
<h3 className="font-headline-md text-headline-md text-primary mb-lg">Top Products</h3>
<div className="overflow-x-auto">
<table className="w-full text-left border-collapse">
<thead>
<tr>
<th className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider py-sm table-border-bottom">Product Name</th>
<th className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider py-sm table-border-bottom text-right">Units Sold</th>
<th className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider py-sm table-border-bottom text-right">Revenue</th>
</tr>
</thead>
<tbody className="text-body-sm">
<tr>
<td className="py-md table-border-bottom text-primary font-medium">Wool Blend Blazer</td>
<td className="py-md table-border-bottom text-on-surface-variant text-right">42</td>
<td className="py-md table-border-bottom text-primary text-right">$12,400</td>
</tr>
<tr>
<td className="py-md table-border-bottom text-primary font-medium">Oxford Cotton Shirt</td>
<td className="py-md table-border-bottom text-on-surface-variant text-right">89</td>
<td className="py-md table-border-bottom text-primary text-right">$7,800</td>
</tr>
<tr>
<td className="py-md table-border-bottom text-primary font-medium">Slim Fit Chinos</td>
<td className="py-md table-border-bottom text-on-surface-variant text-right">65</td>
<td className="py-md table-border-bottom text-primary text-right">$5,200</td>
</tr>
<tr>
<td className="py-md table-border-bottom text-primary font-medium">Heavyweight Tee</td>
<td className="py-md table-border-bottom text-on-surface-variant text-right">34</td>
<td className="py-md table-border-bottom text-primary text-right">$2,800</td>
</tr>
<tr>
<td className="py-md table-border-bottom text-primary font-medium">Linen Blend Blazer</td>
<td className="py-md table-border-bottom text-on-surface-variant text-right">18</td>
<td className="py-md table-border-bottom text-primary text-right">$4,500</td>
</tr>
</tbody>
</table>
</div>
<div className="mt-lg flex justify-end">
<button className="font-label-sm text-label-sm text-primary uppercase tracking-wider hover:underline underline-offset-4 decoration-primary/30">Export CSV</button>
</div>
</div>

<div className="bg-surface-container-lowest rounded-[24px] p-lg card-no-shadow flex flex-col">
<h3 className="font-headline-md text-headline-md text-primary mb-lg">Top Customers</h3>
<div className="overflow-x-auto">
<table className="w-full text-left border-collapse">
<thead>
<tr>
<th className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider py-sm table-border-bottom">Customer Name</th>
<th className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider py-sm table-border-bottom text-right">Orders</th>
<th className="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider py-sm table-border-bottom text-right">Total Spent</th>
</tr>
</thead>
<tbody className="text-body-sm">
<tr>
<td className="py-md table-border-bottom flex items-center gap-sm">
<div className="w-8 h-8 rounded-full bg-surface-variant flex items-center justify-center text-label-sm font-semibold">JD</div>
<span className="text-primary font-medium">Jameson Davis</span>
</td>
<td className="py-md table-border-bottom text-on-surface-variant text-right">12</td>
<td className="py-md table-border-bottom text-primary text-right">$3,450</td>
</tr>
<tr>
<td className="py-md table-border-bottom flex items-center gap-sm">
<div className="w-8 h-8 rounded-full bg-surface-variant flex items-center justify-center text-label-sm font-semibold">MP</div>
<span className="text-primary font-medium">Michael Pierce</span>
</td>
<td className="py-md table-border-bottom text-on-surface-variant text-right">8</td>
<td className="py-md table-border-bottom text-primary text-right">$2,100</td>
</tr>
<tr>
<td className="py-md table-border-bottom flex items-center gap-sm">
<div className="w-8 h-8 rounded-full bg-surface-variant flex items-center justify-center text-label-sm font-semibold">AR</div>
<span className="text-primary font-medium">Arthur Reed</span>
</td>
<td className="py-md table-border-bottom text-on-surface-variant text-right">6</td>
<td className="py-md table-border-bottom text-primary text-right">$1,850</td>
</tr>
<tr>
<td className="py-md table-border-bottom flex items-center gap-sm">
<div className="w-8 h-8 rounded-full bg-surface-variant flex items-center justify-center text-label-sm font-semibold">TH</div>
<span className="text-primary font-medium">Thomas Hayes</span>
</td>
<td className="py-md table-border-bottom text-on-surface-variant text-right">5</td>
<td className="py-md table-border-bottom text-primary text-right">$1,600</td>
</tr>
<tr>
<td className="py-md table-border-bottom flex items-center gap-sm">
<div className="w-8 h-8 rounded-full bg-surface-variant flex items-center justify-center text-label-sm font-semibold">WL</div>
<span className="text-primary font-medium">William Vance</span>
</td>
<td className="py-md table-border-bottom text-on-surface-variant text-right">4</td>
<td className="py-md table-border-bottom text-primary text-right">$1,200</td>
</tr>
</tbody>
</table>
</div>
<div className="mt-lg flex justify-end">
<button className="font-label-sm text-label-sm text-primary uppercase tracking-wider hover:underline underline-offset-4 decoration-primary/30">Export CSV</button>
</div>
</div>
</section>
</main>
  );
}