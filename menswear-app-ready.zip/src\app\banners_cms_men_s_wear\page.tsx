export default function BannersCmsMenSWear() {
  return (
    <main className="flex-1 md:ml-64 flex flex-col min-h-screen">

<header className="flex justify-between items-center h-16 px-xl bg-surface border-b border-on-surface/5 sticky top-0 z-10">
<div className="flex items-center w-full max-w-md bg-surface-container-low rounded-full px-md py-sm border border-outline-variant/30 focus-within:border-primary/50 transition-colors">
<span className="material-symbols-outlined text-on-surface-variant mr-sm">search</span>
<input className="bg-transparent border-none focus:ring-0 text-body-md text-on-surface w-full p-0" placeholder="Search..." type="text" />
</div>
<div className="flex items-center space-x-md">
<button className="text-on-surface-variant hover:text-primary transition-all scale-95 active:scale-90"><span className="material-symbols-outlined">notifications</span></button>
<button className="text-on-surface-variant hover:text-primary transition-all scale-95 active:scale-90"><span className="material-symbols-outlined">settings</span></button>
<img alt="Administrator Profile" className="w-10 h-10 rounded-full object-cover border border-outline-variant/20 ml-sm" data-alt="A professional portrait of a confident male in his late 30s wearing a tailored charcoal grey suit, white shirt, and navy silk tie. The lighting is soft and studio-quality, emphasizing a modern corporate aesthetic against a muted light grey background." src="https://lh3.googleusercontent.com/aida-public/AB6AXuBdzZEp-m6N4L_Wml7NrLpd5xk-la9QKqHSYZkDSzki11eUEYg71BoJeWABgHRqq35QO5LOW0hrScEyBH0vTX3VaV6QkgqFTEe3KBUi_MhXMtqXs6nOfILMdpUqnOeroB7nVM72tmCyDqExps6PglXXfEhbGueqr8KhAExpSuXcRlxD3iBLWAlZewiRAAwTJXadmSWNDPwkjunqE-SqDISltaQdAaMX1WK5n40EjRcYlD_4tIcyGhlf" />
</div>
</header>

<div className="p-margin-mobile md:p-margin-desktop max-w-container-max mx-auto w-full">
<div className="flex items-center justify-between mb-xxl">
<h2 className="font-headline-lg text-headline-lg text-primary tracking-tight">BANNERS &amp; CMS</h2>
<p className="font-body-md text-body-md text-on-surface-variant">Manage your storefront content</p>
</div>
<div className="space-y-xl">

<div className="bg-surface-container-lowest rounded-xl border border-outline-variant/20 overflow-hidden">
<div className="p-lg flex justify-between items-center border-b border-outline-variant/10 bg-surface">
<h3 className="font-headline-md text-headline-md text-primary">Hero Banner</h3>
<div className="flex items-center space-x-md">
<label className="relative inline-flex items-center cursor-pointer">
<input defaultChecked={true} className="sr-only peer" type="checkbox" value="" />
<div className="w-11 h-6 bg-surface-variant peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
<span className="ml-sm font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider">Active</span>
</label>
<button className="bg-primary text-on-primary rounded-full px-lg py-sm font-label-lg text-label-lg hover:bg-primary/90 transition-colors">SAVE</button>
</div>
</div>
<div className="p-lg grid grid-cols-1 lg:grid-cols-2 gap-xl">
<div className="space-y-md">
<div className="relative w-full h-64 rounded-lg overflow-hidden border border-outline-variant/20">
<img className="w-full h-full object-cover" data-alt="A wide-angle, cinematic photograph of a male model walking through a sunlit, modern architectural space. He is wearing a sharp, tailored navy double-breasted suit. The lighting is high-key, creating soft, long shadows and a sophisticated, luxurious atmosphere typical of high-end menswear campaigns." src="https://lh3.googleusercontent.com/aida-public/AB6AXuDB0XNwRzgWwyp_4YFfO9AhcRpVSZ_LUPCdCjI1WPCHzZdUZ8YMb9KulqoLUZLUK1-tZ9gxgbYp8-eXPqfwL93DydhzC78jrb3d5CKe2xaWMBnHAFkZJ_7B5UnVqP5KcL7-WufPpLdr7b6xItrmn0anAQshLhxtGlJ2EVz5oikVVYPy4PcixkRBCtknJHvOGP_YYFfLD4TR60zZmD5qGaMZbrkXvCXkbMwckAoZQT5nUHHV-LGmKg95" />
<div className="absolute inset-0 flex items-center justify-center bg-primary/10 opacity-0 hover:opacity-100 transition-opacity">
<button className="bg-surface-container-lowest text-primary border border-primary rounded-full px-md py-sm font-label-sm text-label-sm flex items-center shadow-sm"><span className="material-symbols-outlined text-[18px] mr-xs">image</span>Replace Image</button>
</div>
</div>
</div>
<div className="space-y-lg">
<div>
<label className="block font-label-lg text-label-lg text-on-surface-variant mb-sm uppercase tracking-wider">Heading Text</label>
<textarea className="w-full bg-surface-container-lowest border border-outline-variant/30 rounded-lg p-md font-headline-md text-headline-md text-primary focus:border-[#8FB0A4] focus:ring-0 transition-colors resize-none h-32">DIVE INTO A WORLD OF ENDLESS FASHION POSSIBILITIES</textarea>
</div>
<div>
<label className="block font-label-lg text-label-lg text-on-surface-variant mb-sm uppercase tracking-wider">Link Destination</label>
<select className="w-full bg-surface-container-lowest border border-outline-variant/30 rounded-lg p-md font-body-md text-on-surface focus:border-[#8FB0A4] focus:ring-0 transition-colors appearance-none">
<option>New Arrivals Collection</option>
<option>Summer Lookbook</option>
<option>All Products</option>
</select>
</div>
</div>
</div>
</div>

<div className="bg-surface-container-lowest rounded-xl border border-outline-variant/20 overflow-hidden">
<div className="p-lg flex justify-between items-center border-b border-outline-variant/10 bg-surface">
<h3 className="font-headline-md text-headline-md text-primary">Featured Collection</h3>
<div className="flex items-center space-x-md">
<label className="relative inline-flex items-center cursor-pointer">
<input defaultChecked={true} className="sr-only peer" type="checkbox" value="" />
<div className="w-11 h-6 bg-surface-variant peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
<span className="ml-sm font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider">Active</span>
</label>
<button className="bg-primary text-on-primary rounded-full px-lg py-sm font-label-lg text-label-lg hover:bg-primary/90 transition-colors">SAVE</button>
</div>
</div>
<div className="p-lg">
<label className="block font-label-lg text-label-lg text-on-surface-variant mb-sm uppercase tracking-wider">Featured Products</label>
<div className="flex flex-wrap gap-md items-center bg-surface p-md rounded-lg border border-outline-variant/20">
<div className="bg-surface-variant text-on-surface flex items-center rounded-full px-sm py-xs font-body-sm">
<span className="mr-sm ml-xs">Camel Overcoat</span>
<button className="text-on-surface-variant hover:text-error transition-colors"><span className="material-symbols-outlined text-[16px]">close</span></button>
</div>
<div className="bg-surface-variant text-on-surface flex items-center rounded-full px-sm py-xs font-body-sm">
<span className="mr-sm ml-xs">Selvedge Jeans</span>
<button className="text-on-surface-variant hover:text-error transition-colors"><span className="material-symbols-outlined text-[16px]">close</span></button>
</div>
<div className="bg-surface-variant text-on-surface flex items-center rounded-full px-sm py-xs font-body-sm">
<span className="mr-sm ml-xs">Oxford Cotton Shirt</span>
<button className="text-on-surface-variant hover:text-error transition-colors"><span className="material-symbols-outlined text-[16px]">close</span></button>
</div>
<button className="border border-primary text-primary rounded-full px-md py-xs font-label-sm text-label-sm hover:bg-primary/5 transition-colors flex items-center">
<span className="material-symbols-outlined text-[16px] mr-xs">add</span> Add Products
                            </button>
</div>
</div>
</div>

<div className="bg-surface-container-lowest rounded-xl border border-outline-variant/20 overflow-hidden">
<div className="p-lg flex justify-between items-center border-b border-outline-variant/10 bg-surface">
<h3 className="font-headline-md text-headline-md text-primary">Promo Banner</h3>
<div className="flex items-center space-x-md">
<label className="relative inline-flex items-center cursor-pointer">
<input className="sr-only peer" type="checkbox" value="" />
<div className="w-11 h-6 bg-surface-variant peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
<span className="ml-sm font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider">Inactive</span>
</label>
<button className="bg-primary text-on-primary rounded-full px-lg py-sm font-label-lg text-label-lg hover:bg-primary/90 transition-colors">SAVE</button>
</div>
</div>
<div className="p-lg grid grid-cols-1 md:grid-cols-2 gap-xl">
<div>
<label className="block font-label-lg text-label-lg text-on-surface-variant mb-sm uppercase tracking-wider">Promo Text</label>
<input className="w-full bg-surface-container-lowest border border-outline-variant/30 rounded-lg p-md font-body-md text-primary focus:border-[#8FB0A4] focus:ring-0 transition-colors" type="text" value="FLAT 40% OFF ON FORMAL WEAR" />
</div>
<div className="flex space-x-lg">
<div className="flex-1">
<label className="block font-label-lg text-label-lg text-on-surface-variant mb-sm uppercase tracking-wider">Link</label>
<input className="w-full bg-surface-container-lowest border border-outline-variant/30 rounded-lg p-md font-body-md text-on-surface focus:border-[#8FB0A4] focus:ring-0 transition-colors" type="text" value="/sale/formal" />
</div>
<div>
<label className="block font-label-lg text-label-lg text-on-surface-variant mb-sm uppercase tracking-wider">Color</label>
<div className="w-12 h-12 rounded-lg border border-outline-variant/30 bg-[#8FB0A4] cursor-pointer shadow-inner"></div>
</div>
</div>
</div>
</div>

<div className="bg-surface-container-lowest rounded-xl border border-outline-variant/20 overflow-hidden">
<div className="p-lg flex justify-between items-center border-b border-outline-variant/10 bg-surface">
<h3 className="font-headline-md text-headline-md text-primary">Announcement Bar</h3>
<div className="flex items-center space-x-md">
<label className="relative inline-flex items-center cursor-pointer">
<input defaultChecked={true} className="sr-only peer" type="checkbox" value="" />
<div className="w-11 h-6 bg-surface-variant peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
<span className="ml-sm font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider">Active</span>
</label>
<button className="bg-primary text-on-primary rounded-full px-lg py-sm font-label-lg text-label-lg hover:bg-primary/90 transition-colors">SAVE</button>
</div>
</div>
<div className="p-lg">
<label className="block font-label-lg text-label-lg text-on-surface-variant mb-sm uppercase tracking-wider">Bar Text</label>
<input className="w-full bg-surface-container-lowest border border-outline-variant/30 rounded-lg p-md font-body-md text-center text-primary focus:border-[#8FB0A4] focus:ring-0 transition-colors" type="text" value="Free shipping on orders over $50" />
</div>
</div>

<div className="bg-surface-container-lowest rounded-xl border border-outline-variant/20 overflow-hidden">
<div className="p-lg flex justify-between items-center border-b border-outline-variant/10 bg-surface">
<h3 className="font-headline-md text-headline-md text-primary">Static Pages</h3>
</div>
<div className="p-0">
<ul className="divide-y divide-primary/5">
<li className="flex items-center justify-between p-lg hover:bg-surface/50 transition-colors">
<span className="font-body-md text-on-surface">About Us</span>
<button className="border border-primary text-primary rounded-full px-md py-sm font-label-sm text-label-sm hover:bg-primary/5 transition-colors">Edit Content</button>
</li>
<li className="flex items-center justify-between p-lg hover:bg-surface/50 transition-colors">
<span className="font-body-md text-on-surface">FAQ</span>
<button className="border border-primary text-primary rounded-full px-md py-sm font-label-sm text-label-sm hover:bg-primary/5 transition-colors">Edit Content</button>
</li>
<li className="flex items-center justify-between p-lg hover:bg-surface/50 transition-colors">
<span className="font-body-md text-on-surface">Size Guide</span>
<button className="border border-primary text-primary rounded-full px-md py-sm font-label-sm text-label-sm hover:bg-primary/5 transition-colors">Edit Content</button>
</li>
<li className="flex items-center justify-between p-lg hover:bg-surface/50 transition-colors">
<span className="font-body-md text-on-surface">Shipping &amp; Returns</span>
<button className="border border-primary text-primary rounded-full px-md py-sm font-label-sm text-label-sm hover:bg-primary/5 transition-colors">Edit Content</button>
</li>
</ul>
</div>
</div>
</div>
</div>
</main>
  );
}