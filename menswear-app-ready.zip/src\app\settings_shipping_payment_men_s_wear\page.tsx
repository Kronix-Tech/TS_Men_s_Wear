export default function SettingsShippingPaymentMenSWear() {
  return (
    <main className="flex-1 p-margin-desktop bg-inverse-on-surface">
<div className="max-w-container-max mx-auto">

<div className="mb-xxl">
<h2 className="text-display-lg font-display-lg text-primary mb-lg uppercase tracking-tight">Settings</h2>
<div className="flex gap-sm border-b border-outline-variant/20 pb-xs">
<button className="px-md py-sm rounded-full text-label-lg font-label-lg text-on-surface-variant hover:bg-surface-container transition-colors uppercase tracking-wide">Store</button>
<button className="px-md py-sm rounded-full text-label-lg font-label-lg bg-primary text-on-primary font-semibold uppercase tracking-wide transition-all">Shipping &amp; Payment</button>
<button className="px-md py-sm rounded-full text-label-lg font-label-lg text-on-surface-variant hover:bg-surface-container transition-colors uppercase tracking-wide">Staff &amp; Roles</button>
</div>
</div>

<div className="grid grid-cols-12 gap-gutter">

<div className="col-span-12 md:col-span-7 flex flex-col gap-lg">

<section className="bg-surface-container-lowest rounded-card p-lg">
<div className="flex items-center gap-sm mb-lg">
<span className="material-symbols-outlined text-primary" data-icon="local_shipping">local_shipping</span>
<h3 className="text-headline-md font-headline-md text-primary">Shipping Methods</h3>
</div>
<div className="flex flex-col gap-0">

<div className="flex items-center justify-between py-md divider">
<div>
<div className="flex items-center gap-sm">
<p className="text-body-lg font-body-lg text-primary font-medium">Standard</p>
<span className="bg-surface-container px-xs py-xs rounded text-label-sm font-label-sm text-on-surface-variant">3–5 days</span>
</div>
<p className="text-body-md font-body-md text-on-surface-variant mt-xs">$5.00 Base Rate</p>
</div>
<div className="flex items-center gap-md">
<p className="text-label-sm font-label-sm text-primary uppercase tracking-wide">Free over $50</p>
<div className="relative inline-block w-12 mr-2 align-middle select-none transition duration-200 ease-in">
<input defaultChecked={true} className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer" id="toggle1" name="toggle1" type="checkbox" />
<label className="toggle-label block overflow-hidden h-6 rounded-full bg-gray-300 cursor-pointer" htmlFor="toggle1"></label>
</div>
<button className="text-on-surface-variant hover:text-primary transition-colors"><span className="material-symbols-outlined" data-icon="more_vert">more_vert</span></button>
</div>
</div>

<div className="flex items-center justify-between py-md divider">
<div>
<div className="flex items-center gap-sm">
<p className="text-body-lg font-body-lg text-primary font-medium">Express</p>
<span className="bg-surface-container px-xs py-xs rounded text-label-sm font-label-sm text-on-surface-variant">1–2 days</span>
</div>
<p className="text-body-md font-body-md text-on-surface-variant mt-xs">$9.99 Base Rate</p>
</div>
<div className="flex items-center gap-md">
<div className="relative inline-block w-12 mr-2 align-middle select-none transition duration-200 ease-in">
<input defaultChecked={true} className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer" id="toggle2" name="toggle2" type="checkbox" />
<label className="toggle-label block overflow-hidden h-6 rounded-full bg-gray-300 cursor-pointer" htmlFor="toggle2"></label>
</div>
<button className="text-on-surface-variant hover:text-primary transition-colors"><span className="material-symbols-outlined" data-icon="more_vert">more_vert</span></button>
</div>
</div>
</div>
<button className="mt-md px-lg py-sm rounded-full border border-primary text-primary text-label-lg font-label-lg hover:bg-surface-container-low transition-colors uppercase tracking-wide">+ Add Method</button>
<div className="mt-xl pt-lg border-t border-outline-variant/10">
<div className="flex items-center justify-between mb-md">
<div>
<p className="text-body-lg font-body-lg text-primary font-medium">Cash on Delivery (COD)</p>
<p className="text-body-md font-body-md text-on-surface-variant mt-xs">Allow customers to pay upon receipt.</p>
</div>
<div className="relative inline-block w-12 mr-2 align-middle select-none transition duration-200 ease-in">
<input defaultChecked={true} className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer" id="toggle3" name="toggle3" type="checkbox" />
<label className="toggle-label block overflow-hidden h-6 rounded-full bg-gray-300 cursor-pointer" htmlFor="toggle3"></label>
</div>
</div>
<div className="w-1/2">
<label className="block text-label-lg font-label-lg text-on-surface-variant uppercase tracking-wide mb-xs">Additional Fee</label>
<div className="relative">
<span className="absolute inset-y-0 left-0 flex items-center pl-sm text-on-surface-variant font-body-md">$</span>
<input className="w-full pl-lg pr-sm py-sm rounded-lg bg-surface-container-lowest input-border text-body-md font-body-md text-primary form-input focus:outline-none focus:ring-0" type="text" value="2.00" />
</div>
</div>
</div>
</section>

<section className="bg-surface-container-lowest rounded-card p-lg">
<div className="flex items-center gap-sm mb-lg">
<span className="material-symbols-outlined text-primary" data-icon="receipt_long">receipt_long</span>
<h3 className="text-headline-md font-headline-md text-primary">Tax Configuration</h3>
</div>
<div className="grid grid-cols-2 gap-md items-end">
<div>
<label className="block text-label-lg font-label-lg text-on-surface-variant uppercase tracking-wide mb-xs">Default Tax Rate</label>
<div className="relative">
<input className="w-full px-sm py-sm rounded-lg bg-surface-container-lowest input-border text-body-md font-body-md text-primary form-input focus:outline-none focus:ring-0" type="text" value="18" />
<span className="absolute inset-y-0 right-0 flex items-center pr-sm text-on-surface-variant font-body-md">%</span>
</div>
</div>
<div className="flex items-center justify-end h-full pb-sm">
<div className="flex items-center gap-sm">
<p className="text-body-md font-body-md text-primary">Prices include tax</p>
<div className="relative inline-block w-12 align-middle select-none transition duration-200 ease-in">
<input defaultChecked={true} className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer" id="toggle4" name="toggle4" type="checkbox" />
<label className="toggle-label block overflow-hidden h-6 rounded-full bg-gray-300 cursor-pointer" htmlFor="toggle4"></label>
</div>
</div>
</div>
</div>
</section>
</div>

<div className="col-span-12 md:col-span-5 flex flex-col h-full">
<section className="bg-surface-container-lowest rounded-card p-lg flex-1">
<div className="flex items-center gap-sm mb-lg">
<span className="material-symbols-outlined text-primary" data-icon="account_balance_wallet">account_balance_wallet</span>
<h3 className="text-headline-md font-headline-md text-primary">Payment Gateways</h3>
</div>
<p className="text-body-md font-body-md text-on-surface-variant mb-md">Manage active payment methods available at checkout.</p>
<div className="flex flex-col gap-0">

<div className="flex items-center justify-between py-md divider">
<div className="flex items-center gap-sm">
<div className="relative inline-block w-12 align-middle select-none transition duration-200 ease-in">
<input defaultChecked={true} className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer" id="toggle_upi" name="toggle_upi" type="checkbox" />
<label className="toggle-label block overflow-hidden h-6 rounded-full bg-gray-300 cursor-pointer" htmlFor="toggle_upi"></label>
</div>
<p className="text-body-lg font-body-lg text-primary font-medium ml-xs">UPI</p>
</div>
<button className="px-md py-xs rounded-full border border-primary text-primary text-label-sm font-label-sm hover:bg-surface-container-low transition-colors uppercase tracking-wide">API Keys</button>
</div>

<div className="flex items-center justify-between py-md divider">
<div className="flex items-center gap-sm">
<div className="relative inline-block w-12 align-middle select-none transition duration-200 ease-in">
<input defaultChecked={true} className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer" id="toggle_cards" name="toggle_cards" type="checkbox" />
<label className="toggle-label block overflow-hidden h-6 rounded-full bg-gray-300 cursor-pointer" htmlFor="toggle_cards"></label>
</div>
<p className="text-body-lg font-body-lg text-primary font-medium ml-xs">Credit/Debit Card</p>
</div>
<button className="px-md py-xs rounded-full border border-primary text-primary text-label-sm font-label-sm hover:bg-surface-container-low transition-colors uppercase tracking-wide">API Keys</button>
</div>

<div className="flex items-center justify-between py-md divider">
<div className="flex items-center gap-sm">
<div className="relative inline-block w-12 align-middle select-none transition duration-200 ease-in">
<input defaultChecked={true} className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer" id="toggle_nb" name="toggle_nb" type="checkbox" />
<label className="toggle-label block overflow-hidden h-6 rounded-full bg-gray-300 cursor-pointer" htmlFor="toggle_nb"></label>
</div>
<p className="text-body-lg font-body-lg text-primary font-medium ml-xs">Net Banking</p>
</div>
<button className="px-md py-xs rounded-full border border-primary text-primary text-label-sm font-label-sm hover:bg-surface-container-low transition-colors uppercase tracking-wide">API Keys</button>
</div>

<div className="flex items-center justify-between py-md">
<div className="flex items-center gap-sm">
<div className="relative inline-block w-12 align-middle select-none transition duration-200 ease-in">
<input defaultChecked={true} className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer" id="toggle_wallets" name="toggle_wallets" type="checkbox" />
<label className="toggle-label block overflow-hidden h-6 rounded-full bg-gray-300 cursor-pointer" htmlFor="toggle_wallets"></label>
</div>
<p className="text-body-lg font-body-lg text-primary font-medium ml-xs">Wallets</p>
</div>
<button className="px-md py-xs rounded-full border border-primary text-primary text-label-sm font-label-sm hover:bg-surface-container-low transition-colors uppercase tracking-wide">API Keys</button>
</div>
</div>
</section>
</div>
</div>

<div className="mt-xl flex justify-end gap-md pb-xxl">
<button className="px-lg py-sm rounded-full border border-primary text-primary text-label-lg font-label-lg hover:bg-surface-container-low transition-colors uppercase tracking-wide h-12">Cancel</button>
<button className="px-xl py-sm rounded-full bg-primary text-on-primary text-label-lg font-label-lg hover:bg-primary-fixed-variant transition-colors uppercase tracking-wide h-12 flex items-center gap-xs">Save Changes <span className="material-symbols-outlined text-[18px]" data-icon="arrow_forward">arrow_forward</span></button>
</div>
</div>
</main>
  );
}