export default function ReviewsMenSWear() {
  return (
    <main className="flex-1 flex flex-col h-full bg-[#f5f4f8] relative overflow-hidden">

<header className="flex justify-between items-center w-full px-xl h-20 sticky top-0 z-40 bg-surface/80 backdrop-blur-md border-b border-outline-variant/30 shrink-0">
<div className="flex-1 flex items-center">

<div className="relative w-96 group">
<span className="material-symbols-outlined absolute left-sm top-1/2 -translate-y-1/2 text-outline group-focus-within:text-primary transition-colors">search</span>
<input className="w-full bg-surface-container-low border border-outline-variant/50 text-body-md text-on-surface rounded-lg pl-xl pr-md py-sm focus:outline-none focus:border-secondary focus:ring-1 focus:ring-secondary transition-all" placeholder="Search reviews, products, customers..." type="text" />
</div>
</div>
<div className="flex items-center gap-lg">
<button className="w-10 h-10 rounded-full flex items-center justify-center text-on-surface-variant hover:text-secondary hover:bg-surface-container-highest transition-colors relative">
<span className="material-symbols-outlined">notifications</span>
<span className="absolute top-2 right-2 w-2 h-2 bg-error rounded-full"></span>
</button>
<div className="w-10 h-10 rounded-full overflow-hidden border border-outline-variant/30 cursor-pointer hover:scale-95 transition-transform">
<img alt="Administrator Avatar" className="w-full h-full object-cover" data-alt="A professional headshot of a male admin in his 30s, wearing a tailored navy blazer over a crisp white shirt, minimalist bright background, soft studio lighting, sharp focus, high-end corporate aesthetic." src="https://lh3.googleusercontent.com/aida-public/AB6AXuCCEF1VWCwAU4Yn7pLrLmeQU00sWY0Z899UoUpWPDZSqICYrGIrPMz5SIVI7wVpe_YuecxHDuyodZlv_c-hBA49TEAowjkNPEVTa79ayfzQSDkcesIBMwKU6NZy6jfQnNCbt3daidN5TuSV7FYXiFfMjSkYRE4SrwhZcec7K7lvNP8w2JnpcpghOEMuG5G9HeLZeHI1IyQINZWyKpxyI4itRsX9UhBwCIcVKoWMsMvx6DVfsWhlrC-h" />
</div>
</div>
</header>

<div className="flex-1 overflow-y-auto p-xl custom-scrollbar">
<div className="max-w-[1280px] mx-auto space-y-xl pb-xxl">

<div className="flex flex-col md:flex-row md:items-end justify-between gap-lg">
<div>
<h2 className="font-headline-lg text-headline-lg font-bold text-primary tracking-tight">REVIEWS</h2>
<p className="font-body-md text-on-surface-variant mt-sm">Manage customer feedback and product ratings.</p>
</div>

<div className="flex flex-wrap gap-sm">
<button className="px-md py-sm rounded-full font-label-lg text-label-lg bg-[#fff8e1] text-[#b45309] border border-[#fef08a] hover:bg-[#ffedd5] transition-colors flex items-center gap-xs">
<span className="">Pending</span>
<span className="bg-[#b45309]/10 text-[#b45309] px-2 py-0.5 rounded-full text-xs">5</span>
</button>
<button className="px-md py-sm rounded-full font-label-lg text-label-lg bg-secondary-fixed/20 text-secondary border border-secondary-container hover:bg-secondary-fixed/40 transition-colors flex items-center gap-xs">
<span className="">Approved</span>
<span className="bg-secondary/10 text-secondary px-2 py-0.5 rounded-full text-xs">128</span>
</button>
<button className="px-md py-sm rounded-full font-label-lg text-label-lg bg-surface-container-high text-on-surface-variant border border-outline-variant/30 hover:bg-surface-container-highest transition-colors flex items-center gap-xs">
<span className="">Rejected</span>
<span className="bg-surface-tint/10 text-surface-tint px-2 py-0.5 rounded-full text-xs">8</span>
</button>
</div>
</div>

<div className="grid grid-cols-1 lg:grid-cols-12 gap-gutter">

<div className="lg:col-span-8 bg-surface-container-lowest rounded-[24px] border border-outline-variant/20 overflow-hidden flex flex-col">
<div className="p-lg border-b border-outline-variant/20 flex justify-between items-center bg-surface-container-lowest sticky top-0 z-10">
<h3 className="font-label-lg text-label-lg text-primary uppercase tracking-wider">Recent Reviews</h3>
<button className="text-on-surface-variant hover:text-primary transition-colors">
<span className="material-symbols-outlined text-xl">filter_list</span>
</button>
</div>
<div className="overflow-x-auto flex-1 custom-scrollbar">
<table className="w-full text-left border-collapse min-w-[800px]">
<thead>
<tr className="border-b border-outline-variant/20 text-on-surface-variant bg-surface/50">
<th className="py-md px-lg font-label-sm text-label-sm uppercase tracking-wider font-medium">Product</th>
<th className="py-md px-lg font-label-sm text-label-sm uppercase tracking-wider font-medium">Customer</th>
<th className="py-md px-lg font-label-sm text-label-sm uppercase tracking-wider font-medium w-32">Rating</th>
<th className="py-md px-lg font-label-sm text-label-sm uppercase tracking-wider font-medium">Comment</th>
<th className="py-md px-lg font-label-sm text-label-sm uppercase tracking-wider font-medium">Date</th>
<th className="py-md px-lg font-label-sm text-label-sm uppercase tracking-wider font-medium">Status</th>
<th className="py-md px-lg font-label-sm text-label-sm uppercase tracking-wider font-medium text-right">Actions</th>
</tr>
</thead>
<tbody className="divide-y divide-outline-variant/10 text-body-sm text-on-surface">

<tr className="table-row-hover transition-colors group">
<td className="py-md px-lg">
<div className="flex items-center gap-md">
<div className="w-10 h-10 rounded-md overflow-hidden bg-surface-container shrink-0 border border-black/5">
<img alt="Selvedge Denim Jeans" className="w-full h-full object-cover" data-alt="Close up flat lay of raw selvedge denim jeans on a white marble surface, soft natural lighting, high-end menswear product photography." src="https://lh3.googleusercontent.com/aida-public/AB6AXuCKPC4XHebf9GBgLEOuTZivSS7BkoTLok9F6Lk7bVlOEhTycs2T_U_YltNEWmcdhXsjMojrRRkGd5ty2MWkbBRxtVxsGH7fbkK-IZrFDaVFl0nKmKzm_xQuFBELgY24zpOewvWonPo_CmHCoUZA0AY_3OoXmTwLDH5Ivm718e-5RR2pQJ2ZSE3XwjvH_z48dPK4m1H2HwATUOWuK6zKCI2MQVoMXkTWjE8cL53GdbbKkylwHpiqGfHX" />
</div>
<span className="font-medium text-primary line-clamp-1">Selvedge Jeans</span>
</div>
</td>
<td className="py-md px-lg whitespace-nowrap text-on-surface-variant">James Wilson</td>
<td className="py-md px-lg">
<div className="flex text-[#f59e0b] text-sm">
<span className="material-symbols-outlined icon-fill !text-base">star</span>
<span className="material-symbols-outlined icon-fill !text-base">star</span>
<span className="material-symbols-outlined icon-fill !text-base">star</span>
<span className="material-symbols-outlined icon-fill !text-base">star</span>
<span className="material-symbols-outlined icon-fill !text-base">star</span>
</div>
</td>
<td className="py-md px-lg">
<p className="truncate max-w-[200px] text-on-surface-variant group-hover:text-primary transition-colors" title="Excellent fit and premium fabric. The break-in period is tough but worth it.">Excellent fit and premium fabric...</p>
</td>
<td className="py-md px-lg whitespace-nowrap text-on-surface-variant">Aug 22, 2026</td>
<td className="py-md px-lg">
<span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-[#fff8e1] text-[#b45309] border border-[#fef08a]">Pending</span>
</td>
<td className="py-md px-lg text-right">
<div className="flex items-center justify-end gap-sm opacity-0 group-hover:opacity-100 transition-opacity">
<button className="w-8 h-8 rounded-full flex items-center justify-center text-secondary hover:bg-secondary/10 transition-colors" title="Approve">
<span className="material-symbols-outlined text-lg">check</span>
</button>
<button className="w-8 h-8 rounded-full flex items-center justify-center text-error hover:bg-error/10 transition-colors" title="Reject">
<span className="material-symbols-outlined text-lg">close</span>
</button>
<button className="w-8 h-8 rounded-full flex items-center justify-center text-on-surface-variant hover:bg-surface-container-high transition-colors" title="Reply">
<span className="material-symbols-outlined text-lg">chat_bubble</span>
</button>
</div>
</td>
</tr>

<tr className="table-row-hover transition-colors group">
<td className="py-md px-lg">
<div className="flex items-center gap-md">
<div className="w-10 h-10 rounded-md overflow-hidden bg-surface-container shrink-0 border border-black/5">
<img alt="Oxford Cotton Shirt" className="w-full h-full object-cover" data-alt="Neatly folded crisp white oxford cotton shirt on a pale grey background, soft directional lighting highlighting the texture, premium menswear aesthetic." src="https://lh3.googleusercontent.com/aida-public/AB6AXuAsk2_eaL9y-9kxlZKHmkMzh1xtXCtErzK7qaR_9xKkjCzuubjf7kbrCsnk9LyCaCIkONqZADCK2Bnk2-xswx0rm0QlLacTEN4abWfWDEFSfNDIT5z-qRShCIB5njDli4sguqi7jr43pMfe4Ve_gkm9ZxtlHpRzcuKU68IBQLBFDCo8tExBzv4pPf_tbBcWKvpvKIvBigIDTC0nsJWj98eDkfHDX1FnetAfd_gLubcIRXrQhJXCH7dL" />
</div>
<span className="font-medium text-primary line-clamp-1">Oxford Shirt</span>
</div>
</td>
<td className="py-md px-lg whitespace-nowrap text-on-surface-variant">Robert Chen</td>
<td className="py-md px-lg">
<div className="flex text-[#f59e0b] text-sm">
<span className="material-symbols-outlined icon-fill !text-base">star</span>
<span className="material-symbols-outlined icon-fill !text-base">star</span>
<span className="material-symbols-outlined icon-fill !text-base">star</span>
<span className="material-symbols-outlined icon-fill !text-base">star</span>
<span className="material-symbols-outlined text-outline !text-base">star</span>
</div>
</td>
<td className="py-md px-lg">
<p className="truncate max-w-[200px] text-on-surface-variant group-hover:text-primary transition-colors" title="A classic staple. Collar stays crisp after multiple washes.">A classic staple. Collar stays...</p>
</td>
<td className="py-md px-lg whitespace-nowrap text-on-surface-variant">Aug 15, 2026</td>
<td className="py-md px-lg">
<span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-secondary-fixed/30 text-secondary border border-secondary-container">Approved</span>
</td>
<td className="py-md px-lg text-right"><div className="flex items-center justify-end gap-sm opacity-0 group-hover:opacity-100 transition-opacity"><button className="w-8 h-8 rounded-full flex items-center justify-center text-secondary hover:bg-secondary/10 transition-colors" title="Approve"><span className="material-symbols-outlined text-lg">check</span></button><button className="w-8 h-8 rounded-full flex items-center justify-center text-error hover:bg-error/10 transition-colors" title="Reject"><span className="material-symbols-outlined text-lg">close</span></button><button className="w-8 h-8 rounded-full flex items-center justify-center text-on-surface-variant hover:bg-surface-container-high transition-colors" title="Reply"><span className="material-symbols-outlined text-lg">chat_bubble</span></button></div></td>
</tr>

<tr className="table-row-hover transition-colors group opacity-60 hover:opacity-100"><td className="py-md px-lg"><div className="flex items-center gap-md"><div className="w-10 h-10 rounded-md overflow-hidden bg-surface-container shrink-0 border border-black/5"><img alt="Linen Blend Blazer" className="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCXNXib0A20_IzIqLB7EeNmVP1POlALsA_kpClYqX_4dthwMR-LX2s8GLnAxGyaXKcVE5i8080hgDETsc0NZ1rsbxibgpgrNYr3QRCPIMIGBCVD1jzE_WY9rzCZdituNupF8UCLKAb49K5xrI0TOcZSsN-cup4NZ9pfP5iq_66MfOvWOSQXolyFrdZFLgYNoGiAPxAIfLsfvqyi9-UMZ_BN0wiktX70fHExxhnsabxA-1jcjQnvt4fU" /></div><span className="font-medium text-primary line-clamp-1">Linen Blend Blazer</span></div></td><td className="py-md px-lg whitespace-nowrap text-on-surface-variant">Michael T.</td><td className="py-md px-lg"><div className="flex text-[#f59e0b] text-sm"><span className="material-symbols-outlined icon-fill !text-base">star</span><span className="material-symbols-outlined text-outline !text-base">star</span><span className="material-symbols-outlined text-outline !text-base">star</span><span className="material-symbols-outlined text-outline !text-base">star</span><span className="material-symbols-outlined text-outline !text-base">star</span></div></td><td className="py-md px-lg"><p className="truncate max-w-[200px] text-on-surface-variant group-hover:text-primary transition-colors" title="Spam text: Buy crypto here link.com">Spam text: Buy crypto here...</p></td><td className="py-md px-lg whitespace-nowrap text-on-surface-variant">Aug 10, 2026</td><td className="py-md px-lg"><span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-surface-container-highest text-surface-tint border border-outline-variant/30">Rejected</span></td><td className="py-md px-lg text-right"><div className="flex items-center justify-end gap-sm opacity-0 group-hover:opacity-100 transition-opacity"><button className="w-8 h-8 rounded-full flex items-center justify-center text-secondary hover:bg-secondary/10 transition-colors" title="Approve"><span className="material-symbols-outlined text-lg">check</span></button><button className="w-8 h-8 rounded-full flex items-center justify-center text-error hover:bg-error/10 transition-colors" title="Reject"><span className="material-symbols-outlined text-lg">close</span></button><button className="w-8 h-8 rounded-full flex items-center justify-center text-on-surface-variant hover:bg-surface-container-high transition-colors" title="Reply"><span className="material-symbols-outlined text-lg">chat_bubble</span></button></div></td></tr>

<tr className="table-row-hover transition-colors group"><td className="py-md px-lg"><div className="flex items-center gap-md"><div className="w-10 h-10 rounded-md overflow-hidden bg-surface-container shrink-0 border border-black/5"><img alt="Wool Trousers" className="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuC7GEb3S6r29UzcnwB9bTeqG0TmSyvBxy581NJEAKgUF6y_f1Rb0i28PVdUMnogS4oJn_LoWfho4vNJutuvFWfLaJQd3SCdtkhlfsQ_EuBdNAOkiJIJx5n7LkT8qlwynC3FYyj5balap07hInrSGkUrKWJuzKy3ReDckkxvAtkrywvyNWTPTyhLOqRJ_b_HQHYT_vR7B0-L4cHVltqqaOs68H_SKqj7yOMJzkeLjSJR18vOsccQomsK" /></div><span className="font-medium text-primary line-clamp-1">Wool Trousers</span></div></td><td className="py-md px-lg whitespace-nowrap text-on-surface-variant">David K.</td><td className="py-md px-lg"><div className="flex text-[#f59e0b] text-sm"><span className="material-symbols-outlined icon-fill !text-base">star</span><span className="material-symbols-outlined icon-fill !text-base">star</span><span className="material-symbols-outlined icon-fill !text-base">star</span><span className="material-symbols-outlined icon-fill !text-base">star</span><span className="material-symbols-outlined icon-fill !text-base">star</span></div></td><td className="py-md px-lg"><p className="truncate max-w-[200px] text-on-surface-variant group-hover:text-primary transition-colors" title="Incredibly comfortable out of the box. The patina develops beautifully over time.">Incredibly comfortable out...</p></td><td className="py-md px-lg whitespace-nowrap text-on-surface-variant">Aug 05, 2026</td><td className="py-md px-lg"><span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-secondary-fixed/30 text-secondary border border-secondary-container">Approved</span></td><td className="py-md px-lg text-right"><div className="flex items-center justify-end gap-sm opacity-0 group-hover:opacity-100 transition-opacity"><button className="w-8 h-8 rounded-full flex items-center justify-center text-secondary hover:bg-secondary/10 transition-colors" title="Approve"><span className="material-symbols-outlined text-lg">check</span></button><button className="w-8 h-8 rounded-full flex items-center justify-center text-error hover:bg-error/10 transition-colors" title="Reject"><span className="material-symbols-outlined text-lg">close</span></button><button className="w-8 h-8 rounded-full flex items-center justify-center text-on-surface-variant hover:bg-surface-container-high transition-colors" title="Reply"><span className="material-symbols-outlined text-lg">chat_bubble</span></button></div></td></tr>
</tbody>
</table>
</div>

<div className="p-md border-t border-outline-variant/20 bg-surface-container-lowest flex justify-between items-center mt-auto">
<span className="text-body-sm text-on-surface-variant">Showing 1-4 of 141 reviews</span>

<div className="flex gap-1">
<button className="w-8 h-8 rounded-full flex items-center justify-center text-on-surface-variant hover:bg-surface-container-low transition-colors" disabled={true}>
<span className="material-symbols-outlined text-sm">chevron_left</span>
</button>
<button className="w-8 h-8 rounded-full flex items-center justify-center bg-primary text-on-primary font-medium text-sm">1</button>
<button className="w-8 h-8 rounded-full flex items-center justify-center text-on-surface-variant hover:bg-surface-container-low transition-colors font-medium text-sm">2</button>
<button className="w-8 h-8 rounded-full flex items-center justify-center text-on-surface-variant hover:bg-surface-container-low transition-colors font-medium text-sm">3</button>
<button className="w-8 h-8 rounded-full flex items-center justify-center text-on-surface-variant hover:bg-surface-container-low transition-colors">
<span className="material-symbols-outlined text-sm">chevron_right</span>
</button>
</div>
</div>
</div>

<div className="lg:col-span-4 flex flex-col gap-gutter">

<div className="bg-surface-container-lowest rounded-[24px] border border-outline-variant/20 p-lg shadow-[0_4px_20px_rgba(20,20,20,0.02)]">
<h3 className="font-label-lg text-label-lg text-primary uppercase tracking-wider mb-lg">Rating Overview</h3>
<div className="flex items-center gap-lg mb-xl">
<div className="text-center">
<div className="font-headline-lg text-display-lg text-primary font-bold leading-none mb-sm">4.8</div>
<div className="flex text-[#f59e0b] text-sm mb-1 justify-center">
<span className="material-symbols-outlined icon-fill">star</span>
<span className="material-symbols-outlined icon-fill">star</span>
<span className="material-symbols-outlined icon-fill">star</span>
<span className="material-symbols-outlined icon-fill">star</span>
<span className="material-symbols-outlined icon-fill">star_half</span>
</div>
<div className="text-body-sm text-on-surface-variant">141 Total</div>
</div>

<div className="flex-1 space-y-2">
<div className="flex items-center gap-2 text-xs text-on-surface-variant">
<span className="w-2">5</span>
<span className="material-symbols-outlined text-[10px] text-[#f59e0b] icon-fill">star</span>
<div className="flex-1 h-1.5 bg-surface-container rounded-full overflow-hidden">
<div className="h-full bg-secondary rounded-full" style={{"width": "85%"}}></div>
</div>
<span className="w-6 text-right">120</span>
</div>
<div className="flex items-center gap-2 text-xs text-on-surface-variant">
<span className="w-2">4</span>
<span className="material-symbols-outlined text-[10px] text-[#f59e0b] icon-fill">star</span>
<div className="flex-1 h-1.5 bg-surface-container rounded-full overflow-hidden">
<div className="h-full bg-secondary/80 rounded-full" style={{"width": "10%"}}></div>
</div>
<span className="w-6 text-right">15</span>
</div>
<div className="flex items-center gap-2 text-xs text-on-surface-variant">
<span className="w-2">3</span>
<span className="material-symbols-outlined text-[10px] text-[#f59e0b] icon-fill">star</span>
<div className="flex-1 h-1.5 bg-surface-container rounded-full overflow-hidden">
<div className="h-full bg-secondary/60 rounded-full" style={{"width": "2%"}}></div>
</div>
<span className="w-6 text-right">3</span>
</div>
<div className="flex items-center gap-2 text-xs text-on-surface-variant">
<span className="w-2">2</span>
<span className="material-symbols-outlined text-[10px] text-[#f59e0b] icon-fill">star</span>
<div className="flex-1 h-1.5 bg-surface-container rounded-full overflow-hidden">
<div className="h-full bg-surface-tint/50 rounded-full" style={{"width": "1%"}}></div>
</div>
<span className="w-6 text-right">1</span>
</div>
<div className="flex items-center gap-2 text-xs text-on-surface-variant">
<span className="w-2">1</span>
<span className="material-symbols-outlined text-[10px] text-[#f59e0b] icon-fill">star</span>
<div className="flex-1 h-1.5 bg-surface-container rounded-full overflow-hidden">
<div className="h-full bg-error/50 rounded-full" style={{"width": "1%"}}></div>
</div>
<span className="w-6 text-right">2</span>
</div>
</div>
</div>
</div>

<div className="bg-surface-container-low rounded-[24px] border border-outline-variant/20 p-lg flex flex-col items-start relative overflow-hidden">

<div className="absolute -right-10 -top-10 w-32 h-32 bg-secondary-fixed opacity-20 rounded-full blur-2xl"></div>
<h3 className="font-label-lg text-label-lg text-primary mb-sm">Export Data</h3>
<p className="text-body-sm text-on-surface-variant mb-lg relative z-10">Download full review history for sentiment analysis or reporting.</p>
<button className="mt-auto px-lg py-sm rounded-full border border-primary text-primary font-label-lg text-label-lg hover:bg-primary/5 transition-colors flex items-center gap-sm w-full justify-center">
<span className="material-symbols-outlined text-lg">download</span>
                                    Export CSV
                                </button>
</div>
</div>
</div>
</div>
</div>
</main>
  );
}