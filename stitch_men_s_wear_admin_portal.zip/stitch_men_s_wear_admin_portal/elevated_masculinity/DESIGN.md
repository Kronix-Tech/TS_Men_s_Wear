---
name: Elevated Masculinity
colors:
  surface: '#faf8ff'
  surface-dim: '#dad9e1'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f2fb'
  surface-container: '#eeedf5'
  surface-container-high: '#e9e7ef'
  surface-container-highest: '#e3e1e9'
  on-surface: '#1a1b21'
  on-surface-variant: '#444748'
  inverse-surface: '#2f3036'
  inverse-on-surface: '#f1f0f8'
  outline: '#747878'
  outline-variant: '#c4c7c7'
  surface-tint: '#5f5e5e'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1c1b1b'
  on-primary-container: '#858383'
  inverse-primary: '#c8c6c5'
  secondary: '#46655a'
  on-secondary: '#ffffff'
  secondary-container: '#c5e7da'
  on-secondary-container: '#4a695f'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#1a1c1e'
  on-tertiary-container: '#838387'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e5e2e1'
  primary-fixed-dim: '#c8c6c5'
  on-primary-fixed: '#1c1b1b'
  on-primary-fixed-variant: '#474646'
  secondary-fixed: '#c8eadd'
  secondary-fixed-dim: '#accec1'
  on-secondary-fixed: '#002019'
  on-secondary-fixed-variant: '#2e4d43'
  tertiary-fixed: '#e3e2e6'
  tertiary-fixed-dim: '#c6c6ca'
  on-tertiary-fixed: '#1a1c1e'
  on-tertiary-fixed-variant: '#46474a'
  background: '#faf8ff'
  on-background: '#1a1b21'
  surface-variant: '#e3e1e9'
typography:
  display-lg:
    fontFamily: EB Garamond
    fontSize: 48px
    fontWeight: '500'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: EB Garamond
    fontSize: 36px
    fontWeight: '500'
    lineHeight: 42px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: EB Garamond
    fontSize: 32px
    fontWeight: '500'
    lineHeight: 40px
  headline-md:
    fontFamily: EB Garamond
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 40px
  xxl: 64px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 40px
---

## Brand & Style
The design system embodies a sophisticated, modern, and clean aesthetic tailored for a premium men's e-commerce experience. It bridges the gap between traditional tailoring and contemporary minimalism, utilizing a "Quiet Luxury" approach. The interface relies on generous whitespace, subtle tonal shifts, and a blend of classic editorial typography with high-utility functional type. 

The emotional response should be one of calm confidence, reliability, and effortless style. The visual language avoids aggressive marketing tactics, opting instead for a curated, boutique atmosphere that respects the user's attention and emphasizes product quality over visual noise.

## Colors
The palette is grounded in a muted, organic spectrum. The primary "Ink" color (#141414) provides strong structural definition and authoritative text contrast. The "Sage Green" (#8FB0A4) serves as a soft, sophisticated accent for highlights, indicators, and subtle brand moments. 

The background uses a "Lavender-White" (#F5F4F8) to provide a warmer, more premium feel than a clinical pure white, while cards and interactive surfaces use a crisp white to create a clear layer of separation. Muted text employs a cool grey (#6E6E75) to maintain hierarchy without sacrificing legibility.

## Typography
This design system utilizes a high-contrast typographic pairing. **EB Garamond** (representing the requested serif aesthetic) is used for headlines and editorial moments, bringing a sense of heritage and timelessness. It should be set with slightly tighter letter-spacing for large displays.

**Inter** handles all functional and body copy. Its neutral, systematic nature ensures clarity in product descriptions, navigation, and data-heavy interfaces. Labels use a slightly heavier weight and increased tracking for a modern, architectural feel. For mobile, display sizes are scaled down to ensure they remain within the viewport without excessive wrapping.

## Layout & Spacing
The layout follows a strict 12-column grid for desktop and a 4-column grid for mobile. Spacing is built on a 4px base unit to ensure rhythmic consistency.

- **Desktop:** 12 columns, 24px gutters, 40px side margins. Max container width of 1280px to maintain comfortable line lengths for text.
- **Tablet:** 8 columns, 24px gutters, 32px side margins.
- **Mobile:** 4 columns, 16px gutters, 16px side margins.

Content is organized using "Content Blocks" with vertical spacing of 64px (xxl) between major sections to emphasize the clean, minimalist aesthetic. Padding inside cards should strictly follow the 24px (lg) unit to match the corner radius.

## Elevation & Depth
The design system avoids heavy shadows, instead using **Tonal Layering** and **Low-Contrast Outlines** to define hierarchy.

1.  **Level 0 (Base):** The Lavender-White background (#F5F4F8).
2.  **Level 1 (Cards/Surfaces):** Pure white (#FFFFFF) containers. These do not use shadows; depth is achieved solely through the color contrast against the background.
3.  **Level 2 (Interactive):** Elements that require focus (like active inputs or dropdowns) use a subtle, extra-diffused shadow: `0px 4px 20px rgba(20, 20, 20, 0.04)`.
4.  **Level 3 (Overlays):** Modals and drawers use a soft backdrop blur (8px) with a 20% opacity dark overlay to maintain focus while preserving the sense of environment.

## Shapes
The shape language is a mix of high-radius containers and sleek functional elements. 
- **Product Cards:** Use a generous 24px corner radius, creating a soft, approachable frame for photography.
- **Buttons:** Fully pill-shaped (999px) to differentiate interactive triggers from structural containers.
- **Inputs & Smaller UI:** Use a more restrained 8px radius to maintain a sense of precision and modern structure.
- **Icons:** Should be stroke-based (1.5px width) with slightly rounded terminals to match the typography.

## Components
### Buttons
- **Primary:** Solid #141414 background, white text, pill-shaped. Height: 48px or 56px.
- **Secondary:** 1px stroke (#141414), transparent background, pill-shaped. 
- **Tertiary:** No border, #141414 text with a subtle underline on hover.

### Cards
- **Product Card:** White background, 24px radius, no shadow. Image should have a slight 0.5px inner stroke (#000000 0.05) to define edges on light photos.
- **Info Card:** Lavender-White background inside white surfaces for nested hierarchy.

### Input Fields
- **Text Input:** 8px radius, white background, 1px border (#6E6E75 at 30% opacity). On focus, border becomes #8FB0A4 (Sage Green).
- **Labels:** Use `label-lg` (uppercase, tracked out) positioned above the field.

### Selection Controls
- **Checkboxes/Radios:** Use #141414 for active states.
- **Chips/Filters:** Pill-shaped, #F5F4F8 background for inactive, #8FB0A4 for active state.

### Lists & Navigation
- **Navigation:** Clean, high-contrast text with `label-lg` styling.
- **Lists:** Separated by 1px horizontal dividers using #141414 at 5% opacity.